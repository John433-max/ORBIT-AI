import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tinylm.train import multi_seed_qk_norm, train_ablation


def test_train_loss_drops():
    r = train_ablation(qk_norm=False, steps=20, lr=1e-2, batch=8, seq=16, seed=0)
    assert r.losses[-1] < r.losses[0] * 1.05 or r.losses[-1] < r.losses[0]
    assert r.final_ppl > 1.0
    assert len(r.logit_curve) >= 2


def test_multi_seed_qk_records_logits():
    out = multi_seed_qk_norm(seeds=(0, 1), steps=8, lr=2e-2, batch=4, seq=12, n_layer=2, n_embd=16)
    assert len(out["off_curves"]) == 2
    assert out["mean_on_logit_end"] > 0
    assert out["mean_off_logit_end"] > 0
