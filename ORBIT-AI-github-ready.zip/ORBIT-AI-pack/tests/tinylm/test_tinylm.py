import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tinylm.config import TinyLMConfig
from tinylm.eval_harness import max_qk_logit_numpy, nll_numpy, nll_torch, synthetic_copy_batch
from tinylm.generate import generate_numpy, generate_torch
from tinylm.numpy_model import TinyLMNumPy
from tinylm.rope import rope_inv_freq, yarn_attn_scale
from tinylm.torch_model import TinyLMTorch


def _cfg(**kw):
    base = dict(vocab_size=32, n_layer=2, n_embd=16, n_head=4, block_size=24)
    base.update(kw)
    return TinyLMConfig(**base)


def test_forward_shapes():
    m = TinyLMNumPy.from_config(_cfg(), seed=1)
    x = np.zeros((2, 5), dtype=np.int64)
    logits, caches = m.forward(x)
    assert logits.shape == (2, 5, 32)
    assert len(caches) == 2
    assert caches[0][0].shape[-2] == 5


def test_kv_cache_matches_full():
    m = TinyLMNumPy.from_config(_cfg(qk_norm=True, attn_logit_softcap=20.0), seed=2)
    prompt = np.arange(6, dtype=np.int64)[None, :]
    full, _ = m.forward(np.concatenate([prompt, np.array([[3]])], axis=1))
    logits, caches = m.forward(prompt)
    step, _ = m.forward(np.array([[3]], dtype=np.int64), kv_caches=caches)
    assert np.allclose(full[:, -1], step[:, -1], atol=1e-4, rtol=1e-4)


def test_greedy_cache_matches_full():
    m = TinyLMNumPy.from_config(_cfg(), seed=3)
    prompt = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a = generate_numpy(m, prompt, n_new=6, use_cache=True)
    b = generate_numpy(m, prompt, n_new=6, use_cache=False)
    assert np.array_equal(a, b)


def test_torch_numpy_parity():
    cfg = _cfg(qk_norm=True, residual_init_scale=True, attn_logit_softcap=30.0)
    np_m = TinyLMNumPy.from_config(cfg, seed=7)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[5, 6, 7, 1, 0]], dtype=np.int64)
    n_logits, _ = np_m.forward(x)
    with torch.no_grad():
        t_logits, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_logits, t_logits.numpy(), atol=2e-5, rtol=2e-5)


def test_torch_cache_matches_full():
    cfg = _cfg(qk_norm=False)
    m = TinyLMTorch.from_config(cfg)
    x = torch.tensor([[2, 4, 6, 1]])
    with torch.no_grad():
        full, _ = m.forward(torch.cat([x, torch.tensor([[9]])], dim=1))
        _, caches = m.forward(x)
        step, _ = m.forward(torch.tensor([[9]]), kv_caches=caches)
    assert torch.allclose(full[:, -1], step[:, -1], atol=1e-5)


def test_greedy_torch_cache():
    cfg = _cfg()
    m = TinyLMTorch.from_config(cfg)
    prompt = torch.tensor([[1, 2, 3]])
    a = generate_torch(m, prompt, 5, use_cache=True)
    b = generate_torch(m, prompt, 5, use_cache=False)
    assert torch.equal(a, b)


def test_residual_scale_shrinks_proj():
    on = TinyLMNumPy.from_config(_cfg(residual_init_scale=True, n_layer=8), seed=0)
    off = TinyLMNumPy.from_config(_cfg(residual_init_scale=False, n_layer=8), seed=0)
    assert np.linalg.norm(on.layers[0]["wo"]) < np.linalg.norm(off.layers[0]["wo"]) * 0.6


def test_qk_norm_bounds_logits_vs_scaled_qk():
    cfg = _cfg(qk_norm=False)
    m = TinyLMNumPy.from_config(cfg, seed=4)
    tokens = synthetic_copy_batch(32, 1, 12, seed=1)
    base = max_qk_logit_numpy(m, tokens)
    # inflate Q/K
    m.layers[0]["wq"] *= 20
    m.layers[0]["wk"] *= 20
    blown = max_qk_logit_numpy(m, tokens)
    m.config.qk_norm = True
    bounded = max_qk_logit_numpy(m, tokens)
    assert blown > base
    # QK-Norm keeps logits O(1) even after 20x Q/K weight blow-up
    assert bounded < 8.0
    assert bounded < blown


def test_eval_nll_finite():
    cfg = _cfg()
    np_m = TinyLMNumPy.from_config(cfg, seed=1)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    tokens = synthetic_copy_batch(32, 4, 10, seed=2)
    a = nll_numpy(np_m, tokens)
    b = nll_torch(t_m, torch.from_numpy(tokens))
    assert np.isfinite(a.nll) and np.isfinite(b.nll)
    assert abs(a.nll - b.nll) < 1e-4


def test_prealloc_cache_matches_concat_numpy():
    m = TinyLMNumPy.from_config(_cfg(qk_norm=True), seed=9)
    prompt = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a = generate_numpy(m, prompt, n_new=5, use_cache=True, prealloc=True)
    b = generate_numpy(m, prompt, n_new=5, use_cache=True, prealloc=False)
    c = generate_numpy(m, prompt, n_new=5, use_cache=False)
    assert np.array_equal(a, b)
    assert np.array_equal(a, c)


def test_prealloc_cache_matches_concat_torch():
    cfg = _cfg(qk_norm=True)
    m = TinyLMTorch.from_config(cfg)
    prompt = torch.tensor([[1, 2, 3, 4]])
    a = generate_torch(m, prompt, 5, use_cache=True, prealloc=True)
    b = generate_torch(m, prompt, 5, use_cache=True, prealloc=False)
    c = generate_torch(m, prompt, 5, use_cache=False)
    assert torch.equal(a, b)
    assert torch.equal(a, c)


def test_from_config_roundtrip():
    c = _cfg(qk_norm=True)
    d = c.to_dict()
    c2 = TinyLMConfig.from_dict(d)
    assert c2.qk_norm is True
    assert TinyLMTorch.from_config(c2).config.n_embd == 16


def test_stable_preset_enables_qk_norm():
    c = TinyLMConfig.preset("stable", vocab_size=32, n_layer=2, n_embd=16, n_head=4, block_size=24)
    assert c.qk_norm is True
    assert c.attn_logit_softcap == 30.0
    assert c.residual_init_scale is True


def test_context_overflow_raises():
    m = TinyLMNumPy.from_config(_cfg(block_size=8), seed=0)
    x = np.zeros((1, 9), dtype=np.int64)
    try:
        m.forward(x)
        assert False, "expected ValueError"
    except ValueError as e:
        assert "block_size" in str(e)


def test_rope_preset():
    c = TinyLMConfig.preset("rope", vocab_size=32, n_layer=2, n_embd=16, n_head=4, block_size=24)
    assert c.use_rope is True
    assert c.qk_norm is True


def test_rope_cache_matches_full_numpy():
    m = TinyLMNumPy.from_config(_cfg(use_rope=True, qk_norm=True), seed=5)
    prompt = np.arange(6, dtype=np.int64)[None, :]
    full, _ = m.forward(np.concatenate([prompt, np.array([[3]])], axis=1))
    logits, caches = m.forward(prompt)
    step, _ = m.forward(np.array([[3]], dtype=np.int64), kv_caches=caches)
    assert np.allclose(full[:, -1], step[:, -1], atol=1e-4, rtol=1e-4)


def test_rope_numpy_torch_parity():
    cfg = _cfg(use_rope=True, qk_norm=True, residual_init_scale=True)
    np_m = TinyLMNumPy.from_config(cfg, seed=13)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[5, 6, 7, 1, 0]], dtype=np.int64)
    n_logits, _ = np_m.forward(x)
    with torch.no_grad():
        t_logits, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_logits, t_logits.numpy(), atol=2e-5, rtol=2e-5)


def test_rope_greedy_cache_matches_full():
    m = TinyLMNumPy.from_config(_cfg(use_rope=True), seed=8)
    prompt = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a = generate_numpy(m, prompt, n_new=6, use_cache=True)
    b = generate_numpy(m, prompt, n_new=6, use_cache=False)
    assert np.array_equal(a, b)


def test_rope_relative_shift_changes_absolute_add_only():
    """RoPE encodings depend on absolute index of each token, so shifting
    the starting cache_pos rotates Q/K but should still run and stay finite."""
    m = TinyLMNumPy.from_config(_cfg(use_rope=True, qk_norm=True), seed=2)
    x = np.array([[1, 2, 3]], dtype=np.int64)
    y0, _ = m.forward(x)
    caches = m.alloc_kv_caches(1, 8)
    y1, _ = m.forward(x, kv_caches=caches, cache_pos=3)
    assert np.isfinite(y0).all() and np.isfinite(y1).all()
    assert not np.allclose(y0, y1, atol=1e-5)


def test_yarn_preset_and_max_seq():
    c = TinyLMConfig.preset("yarn", vocab_size=32, n_layer=2, n_embd=16, n_head=4, block_size=16)
    assert c.use_rope and c.rope_scaling == "yarn" and c.rope_factor == 2.0
    assert c.max_seq_len() == 32
    ntk = TinyLMConfig.preset("ntk", block_size=16, n_embd=16, n_head=4)
    assert ntk.rope_scaling == "ntk" and ntk.max_seq_len() == 32


def test_factor1_scaling_matches_plain_rope():
    base = _cfg(use_rope=True, qk_norm=True)
    yarn1 = _cfg(use_rope=True, qk_norm=True, rope_scaling="yarn", rope_factor=1.0)
    ntk1 = _cfg(use_rope=True, qk_norm=True, rope_scaling="ntk", rope_factor=1.0)
    x = np.array([[1, 2, 3, 4, 5]], dtype=np.int64)
    a, _ = TinyLMNumPy.from_config(base, seed=4).forward(x)
    b, _ = TinyLMNumPy.from_config(yarn1, seed=4).forward(x)
    c, _ = TinyLMNumPy.from_config(ntk1, seed=4).forward(x)
    assert np.allclose(a, b, atol=1e-6)
    assert np.allclose(a, c, atol=1e-6)


def test_ntk_changes_inv_freq():
    plain = rope_inv_freq(16, 10000.0, "none", 1.0, 16)
    ntk = rope_inv_freq(16, 10000.0, "ntk", 2.0, 16)
    yarn = rope_inv_freq(16, 10000.0, "yarn", 2.0, 16)
    lin = rope_inv_freq(16, 10000.0, "linear", 2.0, 16)
    assert not np.allclose(plain, ntk)
    assert not np.allclose(plain, yarn)
    assert np.allclose(lin, plain / 2.0)
    assert yarn_attn_scale("yarn", 2.0) < 1.0
    assert yarn_attn_scale("ntk", 2.0) == 1.0


def test_yarn_extends_past_block_size():
    cfg = _cfg(use_rope=True, rope_scaling="yarn", rope_factor=2.0, block_size=8)
    m = TinyLMNumPy.from_config(cfg, seed=1)
    x = np.zeros((1, 12), dtype=np.int64)
    logits, _ = m.forward(x)
    assert logits.shape == (1, 12, 32)
    assert np.isfinite(logits).all()
    try:
        m.forward(np.zeros((1, 17), dtype=np.int64))
        assert False, "expected overflow"
    except ValueError:
        pass


def test_learned_pos_still_caps_at_block_size():
    m = TinyLMNumPy.from_config(_cfg(use_rope=False, block_size=8), seed=0)
    try:
        m.forward(np.zeros((1, 9), dtype=np.int64))
        assert False, "expected ValueError"
    except ValueError as e:
        assert "max_seq_len" in str(e) or "block_size" in str(e)


def test_yarn_numpy_torch_parity():
    cfg = _cfg(use_rope=True, qk_norm=True, rope_scaling="yarn", rope_factor=2.0, block_size=16)
    np_m = TinyLMNumPy.from_config(cfg, seed=13)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[5, 6, 7, 1, 0, 2, 3, 4, 8, 9]], dtype=np.int64)
    n_logits, _ = np_m.forward(x)
    with torch.no_grad():
        t_logits, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_logits, t_logits.numpy(), atol=2e-5, rtol=2e-5)


def test_yarn_cache_matches_full():
    m = TinyLMNumPy.from_config(
        _cfg(use_rope=True, qk_norm=True, rope_scaling="ntk", rope_factor=2.0, block_size=12),
        seed=5,
    )
    prompt = np.arange(8, dtype=np.int64)[None, :]
    full, _ = m.forward(np.concatenate([prompt, np.array([[3]])], axis=1))
    _, caches = m.forward(prompt)
    step, _ = m.forward(np.array([[3]], dtype=np.int64), kv_caches=caches)
    assert np.allclose(full[:, -1], step[:, -1], atol=1e-4, rtol=1e-4)


def test_sdpa_matches_numpy_when_no_softcap():
    cfg = _cfg(qk_norm=True, attn_logit_softcap=0.0)
    np_m = TinyLMNumPy.from_config(cfg, seed=11)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[3, 1, 4, 1, 5]], dtype=np.int64)
    n_logits, _ = np_m.forward(x)
    with torch.no_grad():
        t_logits, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_logits, t_logits.numpy(), atol=2e-5, rtol=2e-5)


def test_torch_compile_greedy_match_or_skip():
    """If compile works on this host, greedy tokens must match eager."""
    from tinylm.generate import try_compile_torch, generate_torch

    cfg = _cfg(use_rope=True, qk_norm=True, attn_logit_softcap=0.0)
    m = TinyLMTorch.from_config(cfg)
    np_m = TinyLMNumPy.from_config(cfg, seed=21)
    m.load_numpy_state(np_m)
    idx = torch.arange(6)[None, :] % cfg.vocab_size
    compiled, ok, err = try_compile_torch(m)
    if not ok:
        return  # environment limitation is not a test failure
    with torch.no_grad():
        # warm compile
        generate_torch(compiled, idx, 4, use_cache=True, prealloc=True)
        a = generate_torch(m, idx, 8, use_cache=True, prealloc=True)
        b = generate_torch(compiled, idx, 8, use_cache=True, prealloc=True)
    assert torch.equal(a, b), f"compiled decode diverged (err was {err})"


def test_rope_context_probe_yarn_allows_long():
    from tinylm.train import train_rope_context_probe

    r = train_rope_context_probe(
        steps=8, lr=3e-2, batch=4, train_seq=12, block_size=12, long_seq=20,
        seed=0, n_layer=1, n_embd=16, n_head=4, vocab=16,
    )
    assert r["yarn_max_seq"] >= 20
    assert np.isfinite(r["yarn_long_nll"])
    assert np.isfinite(r["plain_short_nll"])
    assert np.isfinite(r["yarn_short_nll"])
    # plain must not silently accept long_seq beyond block without scaling
    assert r["plain_long_allowed"] is False or r["plain_long_nll"] is not None


def test_int8_weight_only_quant():
    from tinylm.quantize import quantize_and_eval
    from tinylm.config import TinyLMConfig

    cfg = TinyLMConfig(vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16, use_rope=True, qk_norm=True)
    stats = quantize_and_eval(cfg, seed=0)
    assert stats.compression_ratio > 3.0  # ~4x weights, scales small
    assert stats.max_abs_logit_err < 5.0  # toy untrained; still bounded
    assert 0.0 <= stats.greedy_match_rate <= 1.0


def test_int4_groupwise_roundtrip_and_eval():
    from tinylm.quantize import _roundtrip_int4, quantize_and_eval_int4
    from tinylm.config import TinyLMConfig

    torch.manual_seed(0)
    w = torch.randn(16, 64)
    rec = _roundtrip_int4(w, group_size=32)
    # reconstruction error should be well below weight scale
    assert rec.shape == w.shape
    assert (rec - w).abs().mean() < 0.15

    cfg = TinyLMConfig(vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16, use_rope=True, qk_norm=True)
    stats = quantize_and_eval_int4(cfg, seed=0, group_size=32)
    assert stats.bits == 4
    assert stats.compression_ratio > 5.0  # packed 4-bit + group scales
    assert stats.max_abs_logit_err < 15.0
    assert 0.0 <= stats.greedy_match_rate <= 1.0
    # INT4 should compress more than INT8 on the same model
    from tinylm.quantize import quantize_and_eval
    s8 = quantize_and_eval(cfg, seed=0)
    assert stats.compression_ratio > s8.compression_ratio


def test_trained_ckpt_int4_int8_nll():
    from tinylm.quantize import train_then_quant_nll

    r = train_then_quant_nll(steps=12, lr=2e-2, batch=4, seq=16, seed=0, n_layer=2, n_embd=32)
    assert r.fp32_nll > 0
    assert np.isfinite(r.int8_nll) and np.isfinite(r.int4_nll)
    # INT8 should stay close to FP32 NLL on this toy task
    assert r.int8_dnll < 0.25
    # INT4 may drift more but must remain finite and not explode
    assert r.int4_dnll < 1.5
    assert r.int4_compression > r.int8_compression
    assert r.steps == 12


def test_fused_int4_linear_matches_dequant():
    from tinylm.quantize import (
        _quant_weight_int4_group,
        int4_linear,
        int4_linear_ref,
        bench_fused_int4,
    )

    torch.manual_seed(3)
    w = torch.randn(24, 64)
    packed, scales, orig_in = _quant_weight_int4_group(w, group_size=32)
    x = torch.randn(5, 64)
    a = int4_linear(x, packed, scales, orig_in, 32)
    b = int4_linear_ref(x, packed, scales, orig_in, 32)
    assert a.shape == (5, 24)
    assert torch.allclose(a, b, atol=1e-5, rtol=1e-5)

    # 3D leading dims
    x3 = torch.randn(2, 3, 64)
    a3 = int4_linear(x3, packed, scales, orig_in, 32)
    b3 = int4_linear_ref(x3, packed, scales, orig_in, 32)
    assert a3.shape == (2, 3, 24)
    assert torch.allclose(a3, b3, atol=1e-5, rtol=1e-5)

    bench = bench_fused_int4(out_features=64, in_features=64, batch=8, repeats=3, warmup=1)
    assert np.isfinite(bench.speedup)
    assert bench.max_abs_err < 1e-4


def test_packed_int4_tinylm_matches_dequant():
    from tinylm.quantize import (
        Int4Linear,
        eval_packed_vs_dequant,
        pack_model_int4,
        packed_int4_linear_bytes,
        packed_int4_cache_bytes,
        materialize_int4_model,
        release_int4_model,
        bench_packed_int4_decode,
    )
    from tinylm.config import TinyLMConfig
    from tinylm.torch_model import TinyLMTorch

    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32, use_rope=True, qk_norm=True
    )
    stats = eval_packed_vs_dequant(cfg, seed=0, seq=8, n=3)
    # same quantized weights; only the GEMM path differs
    assert stats.max_abs_logit_err < 1e-4
    assert stats.greedy_match_rate == 1.0

    m = TinyLMTorch.from_config(cfg)
    pack_model_int4(m)
    n_int4 = sum(1 for mod in m.modules() if isinstance(mod, Int4Linear))
    n_lin = sum(1 for mod in m.modules() if isinstance(mod, torch.nn.Linear))
    assert n_int4 == 12  # 2 layers × (wq wk wv wo w1 w2)
    assert n_lin == 0
    packed_b, leftover = packed_int4_linear_bytes(m)
    assert leftover == 0
    assert packed_b > 0

    dec = bench_packed_int4_decode(cfg, seed=1, prompt_len=4, n_new=8, warmup=0)
    assert dec.greedy_match == 1.0
    assert dec.leftover_linear_bytes == 0
    assert np.isfinite(dec.packed_tok_s) and dec.packed_tok_s > 0
    assert dec.cached_greedy_match == 1.0
    assert dec.cache_bytes > 0
    assert np.isfinite(dec.cached_tok_s) and dec.cached_tok_s > 0

    # unpack-once cache is opt-in and reversible
    m2 = TinyLMTorch.from_config(cfg)
    pack_model_int4(m2, cache_fp32=False)
    assert packed_int4_cache_bytes(m2) == 0
    materialize_int4_model(m2)
    assert packed_int4_cache_bytes(m2) > 0
    x = torch.randint(0, cfg.vocab_size, (1, 6))
    with torch.no_grad():
        log_c, _ = m2.forward(x)
    release_int4_model(m2)
    assert packed_int4_cache_bytes(m2) == 0
    with torch.no_grad():
        log_u, _ = m2.forward(x)
    assert torch.allclose(log_c, log_u, atol=1e-5, rtol=1e-5)

    # Cycle 17: drop packed after materialize (same weights)
    torch.manual_seed(7)
    base = TinyLMTorch.from_config(cfg)
    keep = TinyLMTorch.from_config(cfg)
    keep.load_state_dict(base.state_dict())
    drop = TinyLMTorch.from_config(cfg)
    drop.load_state_dict(base.state_dict())
    pack_model_int4(keep, cache_fp32=True)
    pack_model_int4(drop, cache_fp32=True, drop_packed=True)
    pb_drop, leftover_drop = packed_int4_linear_bytes(drop)
    pb_keep, _ = packed_int4_linear_bytes(keep)
    assert leftover_drop == 0
    assert packed_int4_cache_bytes(drop) > 0
    assert pb_drop < pb_keep  # uint8 packed gone; scales remain
    with torch.no_grad():
        log_keep, _ = keep.forward(x)
        log_drop, _ = drop.forward(x)
    assert torch.allclose(log_keep, log_drop, atol=1e-5, rtol=1e-5)
    try:
        release_int4_model(drop)
        raise AssertionError("release after drop_packed should fail")
    except RuntimeError:
        pass
    with torch.no_grad():
        log_drop2, _ = drop.forward(x)
    assert torch.allclose(log_drop, log_drop2, atol=1e-5, rtol=1e-5)

    assert dec.dropped_greedy_match == 1.0
    assert dec.dropped_packed_bytes < dec.packed_weight_bytes
    assert dec.dropped_cache_bytes > 0


def test_int4_checkpoint_roundtrip(tmp_path):
    from tinylm.quantize import (
        Int4Linear,
        bench_int4_checkpoint_roundtrip,
        export_int4_state,
        load_int4_checkpoint,
        pack_model_int4,
        packed_int4_linear_bytes,
        save_int4_checkpoint,
    )
    from tinylm.config import TinyLMConfig
    from tinylm.torch_model import TinyLMTorch

    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32, use_rope=True, qk_norm=True
    )
    torch.manual_seed(3)
    src = TinyLMTorch.from_config(cfg)
    pack_model_int4(src)
    path = str(tmp_path / "tinylm_int4.pt")
    nbytes = save_int4_checkpoint(src, path)
    assert nbytes > 0

    restored = load_int4_checkpoint(path)
    n_int4 = sum(1 for m in restored.modules() if isinstance(m, Int4Linear))
    n_lin = sum(1 for m in restored.modules() if isinstance(m, torch.nn.Linear))
    assert n_int4 == 12
    assert n_lin == 0
    leftover = packed_int4_linear_bytes(restored)[1]
    assert leftover == 0

    x = torch.randint(0, cfg.vocab_size, (1, 8))
    with torch.no_grad():
        a, _ = src.forward(x)
        b, _ = restored.forward(x)
    assert torch.allclose(a, b, atol=1e-6, rtol=1e-6)

    # drop_packed export requires from_cache
    torch.manual_seed(3)
    drop = TinyLMTorch.from_config(cfg)
    pack_model_int4(drop, cache_fp32=True, drop_packed=True)
    try:
        export_int4_state(drop)
        raise AssertionError("export without packed should fail")
    except RuntimeError:
        pass
    qsd = export_int4_state(drop, from_cache=True)
    assert "_group_size" in qsd

    bench = bench_int4_checkpoint_roundtrip(cfg, seed=5, seq=8)
    assert bench.max_abs_logit_err < 1e-5
    assert bench.greedy_match == 1.0
    assert bench.leftover_linear_bytes == 0
    assert bench.int4_bytes < bench.fp32_bytes
    assert bench.compression > 1.0


def test_int4_mmap_roundtrip(tmp_path):
    from tinylm.quantize import (
        Int4Linear,
        bench_int4_mmap_roundtrip,
        is_int4_mmap,
        load_int4_checkpoint,
        load_int4_mmap,
        load_int4_mmap_state,
        pack_model_int4,
        packed_int4_linear_bytes,
        save_int4_mmap,
    )
    from tinylm.config import TinyLMConfig
    from tinylm.torch_model import TinyLMTorch

    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32, use_rope=True, qk_norm=True
    )
    torch.manual_seed(3)
    src = TinyLMTorch.from_config(cfg)
    pack_model_int4(src)
    path = str(tmp_path / "tinylm.int4m")
    nbytes = save_int4_mmap(src, path)
    assert nbytes > 0
    assert is_int4_mmap(path)

    restored = load_int4_checkpoint(path)  # auto-detect mmap
    n_int4 = sum(1 for m in restored.modules() if isinstance(m, Int4Linear))
    n_lin = sum(1 for m in restored.modules() if isinstance(m, torch.nn.Linear))
    assert n_int4 == 12
    assert n_lin == 0
    assert packed_int4_linear_bytes(restored)[1] == 0

    x = torch.randint(0, cfg.vocab_size, (1, 8))
    with torch.no_grad():
        a, _ = src.forward(x)
        b, _ = restored.forward(x)
    assert torch.allclose(a, b, atol=1e-6, rtol=1e-6)

    qsd = load_int4_mmap_state(path, copy=False)
    assert any(hasattr(t, "_orbit_mmap") for t in qsd.values())
    mapped = load_int4_mmap(path, copy=False)
    with torch.no_grad():
        c, _ = mapped.forward(x)
    assert torch.allclose(a, c, atol=1e-6, rtol=1e-6)

    bench = bench_int4_mmap_roundtrip(cfg, seed=7, seq=8)
    assert bench.max_abs_logit_err < 1e-5
    assert bench.greedy_match == 1.0
    assert bench.leftover_linear_bytes == 0
    assert bench.mmap_view_used
    assert bench.mmap_bytes > 0
    assert bench.pickle_bytes > 0


def test_int4_embeddings():
    from tinylm.quantize import (
        Int4Embedding,
        bench_int4_embeddings,
        load_int4_mmap,
        pack_model_int4,
        packed_int4_embed_bytes,
        save_int4_mmap,
    )
    from tinylm.config import TinyLMConfig
    from tinylm.torch_model import TinyLMTorch

    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32, use_rope=True, qk_norm=True
    )
    torch.manual_seed(11)
    src = TinyLMTorch.from_config(cfg)
    lin = TinyLMTorch.from_config(cfg)
    lin.load_state_dict(src.state_dict())
    both = TinyLMTorch.from_config(cfg)
    both.load_state_dict(src.state_dict())
    pack_model_int4(lin)
    pack_model_int4(both, quantize_embeddings=True)
    assert isinstance(both.tok_emb, Int4Embedding)
    # Cycle 21: use_rope → no learned pos_emb
    assert both.pos_emb is None
    assert lin.pos_emb is None
    assert not isinstance(lin.tok_emb, Int4Embedding)
    pb, leftover = packed_int4_embed_bytes(both)
    assert leftover == 0
    assert pb > 0
    fp32_e, leftover_lin = packed_int4_embed_bytes(lin)
    assert leftover_lin > 0

    x = torch.randint(0, cfg.vocab_size, (1, 8))
    with torch.no_grad():
        a, _ = lin.forward(x)
        b, _ = both.forward(x)
    # embeddings quantize so logits differ, but stay finite
    assert torch.isfinite(b).all()
    # tied weight property usable
    assert both.tok_emb.weight.shape == (cfg.vocab_size, cfg.n_embd)

    import tempfile
    from pathlib import Path

    tmp = tempfile.NamedTemporaryFile(suffix=".int4m", delete=False)
    path = tmp.name
    tmp.close()
    save_int4_mmap(both, path)
    restored = load_int4_mmap(path, copy=True)
    assert isinstance(restored.tok_emb, Int4Embedding)
    with torch.no_grad():
        c, _ = restored.forward(x)
    assert torch.allclose(b, c, atol=1e-5, rtol=1e-5)
    Path(path).unlink(missing_ok=True)

    bench = bench_int4_embeddings(cfg, seed=4, seq=8)
    assert bench.leftover_embed_bytes == 0
    assert bench.int4_embed_bytes < bench.fp32_embed_bytes
    assert bench.compression > 1.0
    assert bench.mmap_bytes > 0
    assert torch.isfinite(torch.tensor(bench.max_abs_logit_err_vs_linear_only))


def test_rope_skips_learned_pos_emb():
    """Cycle 21: use_rope=True allocates no learned position table."""
    cfg_rope = _cfg(use_rope=True, qk_norm=True)
    cfg_abs = _cfg(use_rope=False)
    np_r = TinyLMNumPy.from_config(cfg_rope, seed=1)
    np_a = TinyLMNumPy.from_config(cfg_abs, seed=1)
    assert np_r.pos_emb.shape[0] == 0
    assert np_a.pos_emb.shape[0] == cfg_abs.block_size
    t_r = TinyLMTorch.from_config(cfg_rope)
    t_a = TinyLMTorch.from_config(cfg_abs)
    assert t_r.pos_emb is None
    assert t_a.pos_emb is not None
    # param count: rope model has fewer parameters
    n_r = sum(p.numel() for p in t_r.parameters())
    n_a = sum(p.numel() for p in t_a.parameters())
    assert n_r + cfg_abs.block_size * cfg_abs.n_embd == n_a
    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    n_log, _ = np_r.forward(x)
    t_r.load_numpy_state(np_r)
    with torch.no_grad():
        t_log, _ = t_r.forward(torch.from_numpy(x))
    assert np.allclose(n_log, t_log.numpy(), atol=2e-5, rtol=2e-5)


def test_gqa_shapes_and_cache():
    cfg = _cfg(use_rope=True, qk_norm=True, n_head=4, n_kv_head=2, n_embd=32)
    assert cfg.n_kv_head == 2
    m = TinyLMNumPy.from_config(cfg, seed=3)
    assert m.layers[0]["wk"].shape == (32, 16)  # kv_dim = 2*8
    caches = m.alloc_kv_caches(1, 16)
    assert caches[0][0].shape == (1, 2, 16, 8)
    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    full, _ = m.forward(np.concatenate([x, np.array([[5]])], axis=1))
    _, c = m.forward(x)
    step, _ = m.forward(np.array([[5]], dtype=np.int64), kv_caches=c)
    assert np.allclose(full[:, -1], step[:, -1], atol=1e-4)


def test_gqa_numpy_torch_parity():
    cfg = _cfg(use_rope=True, qk_norm=True, n_head=4, n_kv_head=2, n_embd=32, attn_logit_softcap=0.0)
    np_m = TinyLMNumPy.from_config(cfg, seed=9)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[2, 3, 5, 7, 1]], dtype=np.int64)
    n_log, _ = np_m.forward(x)
    with torch.no_grad():
        t_log, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_log, t_log.numpy(), atol=2e-5, rtol=2e-5)


def test_swiglu_numpy_torch_parity():
    cfg = _cfg(use_swiglu=True, ffn_mult=2.0, use_rope=True, qk_norm=True, attn_logit_softcap=0.0)
    np_m = TinyLMNumPy.from_config(cfg, seed=4)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    assert np_m.layers[0]["w1"].shape[1] == 2 * cfg.ffn_dim()
    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    n_log, _ = np_m.forward(x)
    with torch.no_grad():
        t_log, _ = t_m.forward(torch.from_numpy(x))
    assert np.allclose(n_log, t_log.numpy(), atol=2e-5, rtol=2e-5)


def test_modern_preset():
    cfg = TinyLMConfig.preset("modern", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16)
    assert cfg.use_swiglu and cfg.use_rope and cfg.qk_norm
    assert cfg.n_kv_head == 2
    m = TinyLMTorch.from_config(cfg)
    n = sum(p.numel() for p in m.parameters())
    assert n == cfg.estimate_parameters() or abs(n - cfg.estimate_parameters()) < 8


def test_cosine_lr_schedule():
    from tinylm.train import cosine_lr
    assert abs(cosine_lr(0, 100, 1.0, warmup=10) - 0.1) < 1e-6
    assert abs(cosine_lr(10, 100, 1.0, warmup=10) - 1.0) < 1e-5
    mid = cosine_lr(55, 100, 1.0, warmup=10, min_ratio=0.1)
    assert 0.1 < mid < 1.0
    end = cosine_lr(99, 100, 1.0, warmup=10, min_ratio=0.1)
    assert abs(end - 0.1) < 0.05


def test_adamw_param_groups():
    from tinylm.train import adamw_param_groups
    cfg = _cfg()
    m = TinyLMTorch.from_config(cfg)
    groups = adamw_param_groups(m, 0.01)
    assert len(groups) == 2
    assert groups[0]["weight_decay"] == 0.01
    assert groups[1]["weight_decay"] == 0.0
    n = sum(p.numel() for g in groups for p in g["params"])
    assert n == sum(p.numel() for p in m.parameters())


def test_config_estimate_parameters_matches():
    for name in ("default", "rope", "gqa", "modern"):
        cfg = TinyLMConfig.preset(name, vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16)
        m = TinyLMTorch.from_config(cfg)
        n = sum(p.numel() for p in m.parameters())
        est = cfg.estimate_parameters()
        # allow small mismatch if qk_norm weights counted differently when unused
        assert abs(n - est) <= 2 * cfg.head_dim * 2 + 8, (name, n, est)


def test_config_json_roundtrip(tmp_path=None):
    import tempfile, os
    cfg = TinyLMConfig.preset("modern", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16)
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    try:
        cfg.to_json(path)
        cfg2 = TinyLMConfig.from_json(path)
        assert cfg2.use_swiglu and cfg2.n_kv_head == cfg.n_kv_head
        assert cfg2.vocab_size == 32
    finally:
        os.unlink(path)


def test_temperature_sample_greedy_stable():
    from tinylm.generate import sample_numpy
    logits = np.array([0.1, 5.0, 0.2], dtype=np.float64)
    assert sample_numpy(logits, temperature=0.0) == 1


def test_generate_wires_topk_and_rep_penalty():
    from tinylm.generate import generate_numpy, apply_repetition_penalty_np
    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=1)
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    a = generate_numpy(m, prompt, 5, temperature=0.0)
    b = generate_numpy(m, prompt, 5, temperature=0.0, top_k=5, top_p=0.9, repetition_penalty=1.2)
    assert a.shape == b.shape
    # greedy should ignore top_k; with temp=0 both greedy path
    assert np.array_equal(a, b)
    logits = np.array([1.0, 2.0, 3.0, 0.5])
    p = apply_repetition_penalty_np(logits, [1, 2], 1.5)
    assert p[1] < logits[1] and p[2] < logits[2]


def test_grad_accum_runs():
    from tinylm.train import train_ablation
    r = train_ablation(qk_norm=True, steps=6, lr=2e-2, batch=4, seq=12, seed=0, n_layer=1, n_embd=16, n_head=4, vocab=16, grad_accum=2, use_cosine=True)
    assert len(r.losses) == 6
    assert np.isfinite(r.final_nll)


def test_cli_kv_and_card():
    from tinylm.cli import main
    assert main(["kv-report", "--preset", "gqa", "--seq", "64"]) == 0
    assert main(["card", "--preset", "modern"]) == 0


def test_model_card_fields():
    from tinylm.model_card import build_model_card
    c = build_model_card("modern", vocab=32, layers=2, embd=32, heads=4, block=16)
    assert c["features"]["swiglu"] is True
    assert c["features"]["gqa"] is True
    assert c["estimate_parameters"] > 0


def test_sliding_window_masks_far_keys_and_parity():
    """Cycle 51: SWA keeps last W tokens; NumPy ↔ Torch logits match."""
    cfg = TinyLMConfig.preset(
        "swa",
        vocab_size=32,
        n_layer=2,
        n_embd=32,
        n_head=4,
        block_size=24,
        sliding_window=4,
    )
    assert cfg.sliding_window == 4
    np_m = TinyLMNumPy.from_config(cfg, seed=7)
    th_m = TinyLMTorch.from_config(cfg)
    th_m.load_numpy_state(np_m)
    th_m.eval()
    idx = np.arange(16, dtype=np.int64)[None, :] % 32
    with torch.no_grad():
        np_logits, _ = np_m.forward(idx)
        th_logits, _ = th_m.forward(torch.from_numpy(idx))
    assert np.isfinite(np_logits).all()
    assert np.max(np.abs(np_logits - th_logits.numpy())) < 2e-5

    full = TinyLMConfig.preset(
        "rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=24, sliding_window=0
    )
    # Same init seed + load: windowed vs full must differ on long seq
    np_full = TinyLMNumPy.from_config(full, seed=7)
    # copy weights from windowed model (same architecture except mask)
    np_full.tok_emb = np_m.tok_emb.copy()
    np_full.ln_f_w = np_m.ln_f_w.copy()
    for a, b in zip(np_full.layers, np_m.layers):
        for k in a:
            a[k] = b[k].copy()
    full_logits, _ = np_full.forward(idx)
    assert np.max(np.abs(full_logits - np_logits)) > 1e-4


def test_sliding_window_cached_matches_full():
    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=20,
        use_rope=True, qk_norm=True, sliding_window=5,
    )
    m = TinyLMNumPy.from_config(cfg, seed=3)
    prompt = np.array([[1, 2, 3, 4]], dtype=np.int64)
    caches = m.alloc_kv_caches(1, 16)
    assert caches[0][0].shape[2] == 5  # Cycle 54: compact to W
    logits0, caches = m.forward(prompt, kv_caches=caches, cache_pos=0)
    logits1, _ = m.forward(np.array([[5]], dtype=np.int64), kv_caches=caches, cache_pos=4)
    full, _ = m.forward(np.array([[1, 2, 3, 4, 5]], dtype=np.int64))
    assert np.max(np.abs(logits1[0, -1] - full[0, -1])) < 2e-5


def test_swa_ring_buffer_wraps_and_matches_full_and_torch():
    """Cycle 54: ring KV cap=W; decode past W matches full prefill + Torch."""
    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32,
        use_rope=True, qk_norm=True, sliding_window=4,
    )
    np_m = TinyLMNumPy.from_config(cfg, seed=11)
    th_m = TinyLMTorch.from_config(cfg)
    th_m.load_numpy_state(np_m)
    th_m.eval()
    seq = np.array([[1, 2, 3, 4, 5, 6, 7, 8, 9]], dtype=np.int64)
    # compact alloc requested max_len >> W
    caches = np_m.alloc_kv_caches(1, 64)
    assert caches[0][0].shape[2] == 4
    logits, caches = np_m.forward(seq[:, :3], kv_caches=caches, cache_pos=0)
    for i in range(3, seq.shape[1]):
        logits, caches = np_m.forward(seq[:, i : i + 1], kv_caches=caches, cache_pos=i)
    full, _ = np_m.forward(seq)
    assert np.max(np.abs(logits[0, -1] - full[0, -1])) < 2e-5

    t_caches = th_m.alloc_kv_caches(1, 64)
    assert t_caches[0][0].size(2) == 4
    with torch.no_grad():
        t_logits, t_caches = th_m.forward(torch.from_numpy(seq[:, :3]), kv_caches=t_caches, cache_pos=0)
        for i in range(3, seq.shape[1]):
            t_logits, t_caches = th_m.forward(
                torch.from_numpy(seq[:, i : i + 1]), kv_caches=t_caches, cache_pos=i
            )
        t_full, _ = th_m.forward(torch.from_numpy(seq))
    assert torch.max(torch.abs(t_logits[0, -1] - t_full[0, -1])).item() < 2e-5
    assert np.max(np.abs(logits[0, -1] - t_logits[0, -1].numpy())) < 2e-5

    # no-SWA still allocates requested max_len
    cfg0 = TinyLMConfig(vocab_size=32, n_layer=1, n_embd=16, n_head=2, block_size=16, sliding_window=0)
    m0 = TinyLMNumPy.from_config(cfg0, seed=0)
    c0 = m0.alloc_kv_caches(1, 16)
    assert c0[0][0].shape[2] == 16


def test_ring_store_gather_matches_fancy_index_and_wraps():
    """Cycle 71: contiguous ring write/gather ≡ modulo fancy index."""
    from tinylm.numpy_model import ring_store_gather
    from tinylm.torch_model import ring_store_gather as torch_ring

    rng = np.random.default_rng(0)
    B, H, cap, D = 2, 3, 8, 4
    pk = np.zeros((B, H, cap, D), dtype=np.float32)
    pv = np.zeros_like(pk)
    cache_pos = 6
    t = 5
    k = rng.standard_normal((B, H, t, D)).astype(np.float32)
    v = rng.standard_normal((B, H, t, D)).astype(np.float32)
    used = cache_pos + t
    k_out, v_out = ring_store_gather(pk, pv, k, v, cache_pos, used)

    pk2 = np.zeros_like(pk)
    pv2 = np.zeros_like(pv)
    slots = (cache_pos + np.arange(t)) % cap
    pk2[:, :, slots] = k
    pv2[:, :, slots] = v
    n = min(used, cap)
    start = used - n
    idxs = np.arange(start, used) % cap
    assert np.allclose(k_out, pk2[:, :, idxs])
    assert np.allclose(v_out, pv2[:, :, idxs])
    assert k_out.shape[2] == cap

    tpk = torch.zeros(B, H, cap, D)
    tpv = torch.zeros_like(tpk)
    tk = torch.from_numpy(k.copy())
    tv = torch.from_numpy(v.copy())
    tk_out, tv_out = torch_ring(tpk, tpv, tk, tv, cache_pos, used)
    assert torch.allclose(tk_out, torch.from_numpy(k_out.copy()))
    assert torch.allclose(tv_out, torch.from_numpy(v_out.copy()))


def test_kv_report_sliding_window_shrinks_seq():
    from tinylm.kv_report import kv_cache_bytes_report
    full = kv_cache_bytes_report("rope", seq=128, layers=4, embd=64, heads=4)
    swa = kv_cache_bytes_report("swa", seq=128, layers=4, embd=64, heads=4)
    assert swa["sliding_window"] == 32
    assert swa["kv_seq"] == 32
    assert swa["kv_cache_bytes"] * 4 == full["kv_cache_bytes"]


def test_dropout_train_eval_differs():
    cfg = TinyLMConfig(
        vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=16,
        use_rope=True, resid_pdrop=0.5, attn_pdrop=0.5, attn_logit_softcap=0.0,
    )
    m = TinyLMTorch.from_config(cfg)
    x = torch.randint(0, 32, (2, 8))
    m.train()
    torch.manual_seed(0)
    a, _ = m.forward(x)
    torch.manual_seed(1)
    b, _ = m.forward(x)
    # high dropout should change outputs across seeds in train mode
    assert not torch.allclose(a, b)
    m.eval()
    with torch.no_grad():
        c, _ = m.forward(x)
        d, _ = m.forward(x)
    assert torch.allclose(c, d)


def test_gqa_property_shapes():
    for n_head, n_kv in [(4, 1), (4, 2), (8, 2), (8, 4)]:
        cfg = TinyLMConfig(
            vocab_size=16, n_layer=1, n_embd=32, n_head=n_head, n_kv_head=n_kv,
            block_size=16, use_rope=True, qk_norm=True,
        )
        m = TinyLMNumPy.from_config(cfg, seed=0)
        assert m.layers[0]["wk"].shape[1] == n_kv * cfg.head_dim
        caches = m.alloc_kv_caches(2, 12)
        assert caches[0][0].shape == (2, n_kv, 12, cfg.head_dim)
        logits, _ = m.forward(np.zeros((2, 5), dtype=np.int64))
        assert logits.shape == (2, 5, 16)


def test_regression_suite():
    from tinylm.regression import run_regression
    r = run_regression()
    assert r["ok"], r


def test_bench_matrix_default():
    from tinylm.bench_matrix import run_matrix
    res = run_matrix()
    assert len(res) >= 2
    assert "numpy_tok_s" in res[0]


def test_numpy_checkpoint_roundtrip(tmp_path):
    from tinylm.checkpoint import save_numpy_checkpoint, load_numpy_checkpoint

    cfg = _cfg(qk_norm=True, use_rope=True)
    m = TinyLMNumPy.from_config(cfg, seed=11)
    x = np.array([[1, 2, 3, 4, 5]], dtype=np.int64)
    before, _ = m.forward(x)
    path = tmp_path / "toy.npz"
    info = save_numpy_checkpoint(m, str(path), extra={"tag": "cycle67"})
    assert path.exists()
    assert Path(info["json"]).exists()
    loaded, meta = load_numpy_checkpoint(str(path))
    after, _ = loaded.forward(x)
    assert np.allclose(before, after, atol=0, rtol=0)
    assert meta.get("tag") == "cycle67"
    assert loaded.config.use_rope is True


def test_torch_dump_matches_numpy():
    cfg = _cfg(qk_norm=True, residual_init_scale=True, use_rope=True)
    np_m = TinyLMNumPy.from_config(cfg, seed=13)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    dumped = t_m.dump_numpy_state()
    clone = TinyLMNumPy.from_config(cfg, seed=99)
    clone.load_state_dict(dumped)
    x = np.array([[4, 5, 6, 1]], dtype=np.int64)
    a, _ = np_m.forward(x)
    b, _ = clone.forward(x)
    assert np.allclose(a, b, atol=1e-6, rtol=1e-6)


def test_train_chat_tiny_lowers_nll_and_saves(tmp_path):
    from tinylm.train import train_chat_tiny
    from tinylm.eval_harness import nll_numpy, synthetic_copy_batch

    ckpt = tmp_path / "chat_toy.npz"
    init = TinyLMNumPy.from_config(
        TinyLMConfig.preset("rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32),
        seed=0,
    )
    probe = synthetic_copy_batch(32, 16, 32, seed=9999)
    probe[:, 1::2] = (probe[:, 0::2] + 1) % 32
    nll_before = nll_numpy(init, probe).nll
    out = train_chat_tiny(
        steps=25,
        vocab=32,
        n_layer=2,
        n_embd=32,
        n_head=4,
        seq=32,
        ckpt_path=str(ckpt),
        seed=0,
    )
    assert ckpt.exists()
    assert out["final_nll"] < nll_before
    assert out["losses"][-1] < out["losses"][0] or out["final_nll"] < nll_before
    nll_loaded = nll_numpy(out["model_np"], probe).nll
    assert abs(nll_loaded - out["final_nll"]) < 0.15


def test_train_persona_chat_nll_drops_and_saves(tmp_path):
    from tinylm.train import train_persona_chat

    ckpt = tmp_path / "persona.npz"
    out = train_persona_chat(
        steps=25,
        batch=4,
        seq=32,
        seed=0,
        n_layer=2,
        n_embd=32,
        n_head=4,
        vocab=64,
        ckpt_path=str(ckpt),
    )
    assert out["loss_end"] < out["loss_start"]
    assert ckpt.exists()
    from tinylm import load_numpy_checkpoint

    m, meta = load_numpy_checkpoint(str(ckpt))
    assert meta.get("corpus") == "persona_chat"
    assert m is not None
    assert meta.get("tokenizer") in (None, "byte")


def test_train_persona_chat_bpe_roundtrip_and_compresses(tmp_path):
    from tinylm.train import train_persona_chat
    from tools.chat_tool import generate_chat_tinylm, _resolve_chat_tokenizer

    ckpt = tmp_path / "persona_bpe.npz"
    out = train_persona_chat(
        steps=20,
        batch=4,
        seq=32,
        seed=0,
        n_layer=2,
        n_embd=32,
        n_head=4,
        tokenizer="bpe",
        vocab_target=288,
        ckpt_path=str(ckpt),
    )
    assert out["tokenizer"] == "bpe"
    assert out["bpe_merges"] >= 1
    assert out["vocab_size"] >= 259
    assert out["loss_end"] < out["loss_start"]
    assert Path(ckpt).with_suffix(".bpe.json").exists()
    tok = out["tokenizer_obj"]
    sample = "user: hi\nassistant: Hey. I'm ORBIT."
    ids = tok.encode(sample, add_bos=False, add_eos=False)
    assert tok.decode(ids) == sample
    assert len(ids) < len(sample.encode("utf-8"))
    from tinylm import load_numpy_checkpoint

    m, meta = load_numpy_checkpoint(str(ckpt))
    m._ckpt_path = str(ckpt)
    m._ckpt_meta = meta
    assert meta.get("tokenizer") == "bpe"
    loaded = _resolve_chat_tokenizer(m)
    assert loaded is not None
    assert loaded.decode(loaded.encode("ORBIT", add_bos=False, add_eos=False)) == "ORBIT"
    gen = generate_chat_tinylm("hi", model=m, max_tokens=8, temperature=0.0)
    assert gen["ok"] is True
    assert gen["tokenizer"] == "bpe"
    assert gen["n_new"] >= 1
    assert gen["prompt_compression"] >= 1.0


def test_shipped_persona_bpe_ckpt_loads_when_present():
    from tools.chat_tool import generate_chat_tinylm, build_chat_tinylm

    root = Path(__file__).resolve().parents[2]
    ckpt = root / "checkpoints" / "tinylm_persona_bpe.npz"
    sidecar = root / "checkpoints" / "tinylm_persona_bpe.bpe.json"
    if not ckpt.exists() or not sidecar.exists():
        return
    m = build_chat_tinylm(ckpt_path=str(ckpt))
    assert getattr(m, "_ckpt_meta", {}).get("tokenizer") == "bpe"
    gen = generate_chat_tinylm("hi", model=m, max_tokens=8, temperature=0.0)
    assert gen["ok"] is True
    assert gen["tokenizer"] == "bpe"
    assert gen["prompt_compression"] >= 1.2


def test_persona_ckpt_candidates_prefer_bpe_order():
    from tools.chat_tool import _persona_ckpt_candidates

    byte_first = _persona_ckpt_candidates(prefer_bpe=False)
    bpe_first = _persona_ckpt_candidates(prefer_bpe=True)
    assert "tinylm_persona.npz" in byte_first[0]
    assert "tinylm_persona_bpe.npz" in bpe_first[0]
    assert any("tinylm_persona_bpe.npz" in c for c in byte_first)


def test_prefer_bpe_ckpt_env(monkeypatch):
    from tools import chat_tool

    monkeypatch.delenv("ORBIT_TINYLM_PREFER_BPE", raising=False)
    monkeypatch.delenv("ORBIT_TINYLM_TOKENIZER", raising=False)
    assert chat_tool._prefer_bpe_ckpt() is False
    monkeypatch.setenv("ORBIT_TINYLM_TOKENIZER", "bpe")
    assert chat_tool._prefer_bpe_ckpt() is True


def test_numpy_int4_pack_roundtrip_and_persona():
    from tinylm.checkpoint import (
        load_numpy_checkpoint,
        save_numpy_int4_checkpoint,
        quant_weight_int4_np,
        dequant_weight_int4_np,
    )
    from tinylm.eval_harness import nll_numpy

    rng = np.random.default_rng(0)
    w = rng.normal(0, 0.05, (64, 48)).astype(np.float32)
    packed, scales, orig = quant_weight_int4_np(w, 32)
    rec = dequant_weight_int4_np(packed, scales, orig, 32)
    assert rec.shape == w.shape
    assert float(np.max(np.abs(w - rec))) < 0.02

    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=11)
    import tempfile

    tmp = tempfile.NamedTemporaryFile(suffix=".npz", delete=False)
    tmp.close()
    saved = save_numpy_int4_checkpoint(m, tmp.name, extra={"format_test": True})
    loaded, meta = load_numpy_checkpoint(tmp.name)
    assert meta.get("loaded_int4") is True
    assert meta.get("format") == "int4_numpy"
    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a, _ = m.forward(x)
    b, _ = loaded.forward(x)
    assert np.isfinite(a).all() and np.isfinite(b).all()
    # Group-wise INT4 is lossy; greedy last-token should usually agree on toy sizes.
    match = float((a[0].argmax(-1) == b[0].argmax(-1)).mean())
    assert match >= 0.5

    root = Path(__file__).resolve().parents[2]
    fp = root / "checkpoints" / "tinylm_persona_bpe.npz"
    qpath = root / "checkpoints" / "tinylm_persona_bpe_int4.npz"
    if fp.exists() and qpath.exists():
        fp_m, _ = load_numpy_checkpoint(str(fp))
        q_m, qmeta = load_numpy_checkpoint(str(qpath))
        assert qmeta.get("loaded_int4") is True
        ids = np.array([[1, 2, 3, 4, 5, 8]], dtype=np.int64)
        nll_fp = nll_numpy(fp_m, ids)
        nll_q = nll_numpy(q_m, ids)
        assert np.isfinite(nll_fp.nll) and np.isfinite(nll_q.nll)
        assert abs(nll_q.nll - nll_fp.nll) < 0.15
        assert qpath.stat().st_size < fp.stat().st_size


def test_numpy_int4_embeddings_pack_and_persona():
    from tinylm.checkpoint import (
        load_numpy_checkpoint,
        pack_numpy_state_int4,
        save_numpy_int4_checkpoint,
        unpack_numpy_state_int4,
    )
    from tinylm.eval_harness import nll_numpy

    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=13)
    packed = pack_numpy_state_int4(m.state_dict(), quantize_embeddings=True)
    assert "tok_emb_int4" in packed
    assert "tok_emb" not in packed
    rec = unpack_numpy_state_int4(packed)
    assert rec["tok_emb"].shape == m.tok_emb.shape
    assert float(np.max(np.abs(rec["tok_emb"] - m.tok_emb))) < 0.05

    import tempfile

    tmp = tempfile.NamedTemporaryFile(suffix=".npz", delete=False)
    tmp.close()
    saved = save_numpy_int4_checkpoint(m, tmp.name, quantize_embeddings=True)
    assert saved["meta"]["quantize_embeddings"] is True
    loaded, meta = load_numpy_checkpoint(tmp.name)
    assert meta.get("loaded_int4") is True
    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a, _ = m.forward(x)
    b, _ = loaded.forward(x)
    assert np.isfinite(a).all() and np.isfinite(b).all()

    root = Path(__file__).resolve().parents[2]
    fp = root / "checkpoints" / "tinylm_persona_bpe.npz"
    lin = root / "checkpoints" / "tinylm_persona_bpe_int4.npz"
    emb = root / "checkpoints" / "tinylm_persona_bpe_int4emb.npz"
    if fp.exists() and emb.exists():
        fp_m, _ = load_numpy_checkpoint(str(fp))
        e_m, emeta = load_numpy_checkpoint(str(emb))
        assert emeta.get("quantize_embeddings") is True
        assert emeta.get("loaded_int4") is True
        ids = np.array([[1, 2, 3, 4, 5, 8]], dtype=np.int64)
        nll_fp = nll_numpy(fp_m, ids)
        nll_e = nll_numpy(e_m, ids)
        assert np.isfinite(nll_fp.nll) and np.isfinite(nll_e.nll)
        assert abs(nll_e.nll - nll_fp.nll) < 0.25
        assert emb.stat().st_size < fp.stat().st_size
        if lin.exists():
            assert emb.stat().st_size < lin.stat().st_size


def test_numpy_keep_packed_dequant_on_matmul():
    from tinylm.checkpoint import (
        load_numpy_checkpoint,
        pack_numpy_state_int4,
        save_numpy_int4_checkpoint,
    )
    from tinylm.numpy_model import PackedInt4, packed_int4_numpy_bytes
    from tinylm.generate import generate_numpy

    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=21)
    packed_sd = pack_numpy_state_int4(m.state_dict(), quantize_embeddings=True)
    keep = TinyLMNumPy.from_config(cfg, seed=0)
    keep.load_packed_int4_state(packed_sd)
    assert isinstance(keep.layers[0]["wq"], PackedInt4)
    assert isinstance(keep.tok_emb, PackedInt4)
    pb, leftover, cache0 = packed_int4_numpy_bytes(keep)
    assert pb > 0 and leftover == 0 and cache0 == 0

    x = np.array([[1, 2, 3, 4]], dtype=np.int64)
    a, _ = keep.forward(x)
    # After first forward, FP32 cache is warm
    _, _, cache1 = packed_int4_numpy_bytes(keep)
    assert cache1 > 0
    assert np.isfinite(a).all()

    import tempfile

    tmp = tempfile.NamedTemporaryFile(suffix=".npz", delete=False)
    tmp.close()
    save_numpy_int4_checkpoint(m, tmp.name, quantize_embeddings=True)
    eager, meta_e = load_numpy_checkpoint(tmp.name, keep_packed=False)
    lazy, meta_l = load_numpy_checkpoint(tmp.name, keep_packed=True)
    assert meta_e.get("loaded_int4") and meta_l.get("keep_packed")
    ae, _ = eager.forward(x)
    al, _ = lazy.forward(x)
    assert float(np.max(np.abs(ae - al))) == 0.0

    prompt = np.array([[1, 2]], dtype=np.int64)
    ids_e = generate_numpy(eager, prompt, n_new=8, temperature=0.0)
    ids_l = generate_numpy(lazy, prompt, n_new=8, temperature=0.0)
    assert np.array_equal(ids_e, ids_l)

    keep.materialize_packed(drop_packed=True)
    pb2, leftover2, cache2 = packed_int4_numpy_bytes(keep)
    assert pb2 < pb  # uint8 dropped
    assert cache2 > 0


def test_persona_ckpt_candidates_prefer_int4():
    from tools.chat_tool import _persona_ckpt_candidates

    ordered = _persona_ckpt_candidates(prefer_bpe=True, prefer_int4=True)
    assert "tinylm_persona_bpe_int4.npz" in ordered[0]


def test_persona_ckpt_candidates_prefer_int4_emb():
    from tools.chat_tool import _persona_ckpt_candidates

    ordered = _persona_ckpt_candidates(
        prefer_bpe=True, prefer_int4=True, prefer_int4_emb=True
    )
    assert "tinylm_persona_bpe_int4emb.npz" in ordered[0]


class _StopStub:
    """Forward returns logits that greedily emit `emit` then `eos`."""

    def __init__(self, vocab=16, emit=3, eos=15):
        self.config = TinyLMConfig(vocab_size=vocab, n_layer=1, n_embd=8, n_head=2, block_size=32)
        self.cfg = self.config
        self.emit = emit
        self.eos = eos
        self.n_calls = 0

    def alloc_kv_caches(self, *a, **k):
        return None

    def forward(self, idx, kv_caches=None, cache_pos=None):
        self.n_calls += 1
        b, t = idx.shape
        logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
        tok = self.emit if self.n_calls == 1 else self.eos
        logits[:, -1, tok] = 10.0
        return logits, kv_caches


def test_generate_numpy_stops_on_eos():
    stub = _StopStub()
    prompt = np.array([[1, 2]], dtype=np.int64)
    out = generate_numpy(stub, prompt, n_new=20, use_cache=True, prealloc=False, eos_id=15)
    new = out[0, 2:].tolist()
    assert new == [3, 15], new
    assert stub.n_calls == 2


def test_generate_numpy_stops_on_stop_ids_uncached():
    stub = _StopStub(emit=4, eos=7)
    prompt = np.array([[1]], dtype=np.int64)
    out = generate_numpy(stub, prompt, n_new=12, use_cache=False, stop_ids=(7,))
    assert out[0].tolist() == [1, 4, 7]


def test_generate_without_stop_fills_n_new():
    stub = _StopStub()
    prompt = np.array([[1, 2]], dtype=np.int64)
    out = generate_numpy(stub, prompt, n_new=5, use_cache=False)
    assert out.shape[1] == 7


class _ImmediateEosStub:
    """Every step prefers EOS; runner-up is `alt` so min_new can unmask it."""

    def __init__(self, vocab=16, eos=15, alt=3):
        self.config = TinyLMConfig(vocab_size=vocab, n_layer=1, n_embd=8, n_head=2, block_size=32)
        self.cfg = self.config
        self.eos = eos
        self.alt = alt
        self.n_calls = 0

    def alloc_kv_caches(self, *a, **k):
        return None

    def forward(self, idx, kv_caches=None, cache_pos=None):
        self.n_calls += 1
        b, t = idx.shape
        logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
        logits[:, -1, self.alt] = 5.0
        logits[:, -1, self.eos] = 10.0
        return logits, kv_caches


def test_min_new_tokens_suppresses_immediate_eos():
    stub = _ImmediateEosStub()
    prompt = np.array([[1, 2]], dtype=np.int64)
    early = generate_numpy(stub, prompt, n_new=8, use_cache=False, eos_id=15, min_new_tokens=0)
    assert early[0, 2:].tolist() == [15]

    stub2 = _ImmediateEosStub()
    delayed = generate_numpy(
        stub2, prompt, n_new=8, use_cache=True, prealloc=False, eos_id=15, min_new_tokens=2
    )
    new = delayed[0, 2:].tolist()
    assert new[0] == 3, new
    assert new == [3, 3, 15], new


def test_science_math_derivative_and_geometry():
    from science_math import solve_science_math

    d = solve_science_math("derivative of x^2")
    assert d["ok"] and "2" in str(d["result"])
    g = solve_science_math("area of a circle radius 5")
    assert g["ok"] and float(g["result"]) > 70
    f = solve_science_math("force if mass 2 and acceleration 3")
    assert f["ok"] and float(f["result"]) == 6.0


def test_science_math_expanded():
    from science_math import solve_science_math

    assert solve_science_math("surface area of sphere radius 2")["ok"]
    assert abs(float(solve_science_math("surface area of sphere radius 2")["result"]) - 50.2655) < 0.01
    assert solve_science_math("volume of cylinder radius 3 height 4")["ok"]
    assert solve_science_math("momentum mass 2 velocity 5")["result"] == 10.0
    assert solve_science_math("density mass 10 volume 2")["result"] == 5.0
    assert solve_science_math("work force 3 distance 4")["result"] == 12.0
    d2 = solve_science_math("second derivative of x^3")
    assert d2["ok"] and "6" in str(d2["result"])
    lim = solve_science_math("limit as x approaches 0 of sin(x)/x")
    assert lim["ok"] and str(lim["result"]) in ("1", "1.00000000000000")


def test_persona_ckpt_candidates_prefer_l4_order():
    from tools.chat_tool import _persona_ckpt_candidates

    l4 = _persona_ckpt_candidates(prefer_bpe=True, prefer_l4=True)
    assert "tinylm_persona_bpe_l4.npz" in l4[0]
    default = _persona_ckpt_candidates(prefer_bpe=False, prefer_l4=False)
    assert "tinylm_persona_bpe_l4.npz" not in default[0]


def test_prefer_l4_ckpt_env(monkeypatch):
    from tools import chat_tool

    monkeypatch.delenv("ORBIT_TINYLM_L4", raising=False)
    monkeypatch.delenv("ORBIT_TINYLM_SIZE", raising=False)
    assert chat_tool._prefer_l4_ckpt() is False
    monkeypatch.setenv("ORBIT_TINYLM_SIZE", "l4d64")
    assert chat_tool._prefer_l4_ckpt() is True


def test_shipped_persona_bpe_l4_ckpt_when_present():
    from tools.chat_tool import generate_chat_tinylm, build_chat_tinylm

    root = Path(__file__).resolve().parents[2]
    ckpt = root / "checkpoints" / "tinylm_persona_bpe_l4.npz"
    if not ckpt.exists():
        return
    m = build_chat_tinylm(ckpt_path=str(ckpt))
    cfg = m.config
    assert cfg.n_layer == 4
    assert cfg.n_embd == 64
    gen = generate_chat_tinylm("hi", model=m, max_tokens=8, temperature=0.0)
    assert gen["ok"] is True
    assert gen["n_new"] >= 1


def test_persona_ckpt_candidates_prefer_l4_int4_order():
    from tools.chat_tool import _persona_ckpt_candidates

    ordered = _persona_ckpt_candidates(
        prefer_bpe=True, prefer_l4=True, prefer_int4=True
    )
    assert "tinylm_persona_bpe_l4_int4.npz" in ordered[0]
    emb = _persona_ckpt_candidates(
        prefer_bpe=True, prefer_l4=True, prefer_int4=True, prefer_int4_emb=True
    )
    assert "tinylm_persona_bpe_l4_int4emb.npz" in emb[0]
    small = _persona_ckpt_candidates(prefer_bpe=True, prefer_int4=True)
    assert "tinylm_persona_bpe_int4.npz" in small[0]


def test_shipped_persona_bpe_l4_int4_ckpt_when_present():
    from tinylm import load_numpy_checkpoint
    from tinylm.eval_harness import nll_numpy
    from tinylm.generate import generate_numpy
    from tools.chat_tool import generate_chat_tinylm, build_chat_tinylm

    root = Path(__file__).resolve().parents[2]
    fp = root / "checkpoints" / "tinylm_persona_bpe_l4.npz"
    lin = root / "checkpoints" / "tinylm_persona_bpe_l4_int4.npz"
    emb = root / "checkpoints" / "tinylm_persona_bpe_l4_int4emb.npz"
    if not (fp.exists() and lin.exists() and emb.exists()):
        return
    fp_m, _ = load_numpy_checkpoint(str(fp))
    lin_m, lmeta = load_numpy_checkpoint(str(lin))
    emb_m, emeta = load_numpy_checkpoint(str(emb))
    assert lmeta.get("loaded_int4") is True
    assert emeta.get("loaded_int4") is True
    assert emeta.get("quantize_embeddings") is True
    assert lin_m.config.n_layer == 4 and lin_m.config.n_embd == 64
    ids = np.array([[1, 2, 3, 4, 5, 8, 9, 10]], dtype=np.int64)
    nll_fp = nll_numpy(fp_m, ids)
    nll_lin = nll_numpy(lin_m, ids)
    nll_emb = nll_numpy(emb_m, ids)
    assert abs(nll_lin.nll - nll_fp.nll) < 0.05
    assert abs(nll_emb.nll - nll_fp.nll) < 0.08
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    gf = generate_numpy(fp_m, prompt, n_new=8, temperature=0.0)
    gl = generate_numpy(lin_m, prompt, n_new=8, temperature=0.0)
    ge = generate_numpy(emb_m, prompt, n_new=8, temperature=0.0)
    assert np.array_equal(gf, gl)
    assert np.array_equal(gf, ge)
    assert lin.stat().st_size < fp.stat().st_size
    assert emb.stat().st_size < lin.stat().st_size
    m = build_chat_tinylm(ckpt_path=str(emb))
    gen = generate_chat_tinylm("hi", model=m, max_tokens=8, temperature=0.0)
    assert gen["ok"] is True
    assert gen["n_new"] >= 1
    assert gen["tokenizer"] == "bpe"



def test_numpy_int4_mmap_roundtrip(tmp_path):
    from tinylm.checkpoint import (
        is_numpy_int4_mmap,
        load_numpy_checkpoint,
        save_numpy_int4_mmap,
        save_numpy_int4_checkpoint,
    )
    from tinylm.eval_harness import nll_numpy
    from tinylm.generate import generate_numpy

    src = TinyLMNumPy.from_config(_cfg(), seed=11)
    mmap_path = tmp_path / "toy.n4m"
    info = save_numpy_int4_mmap(src, str(mmap_path), quantize_embeddings=True)
    assert is_numpy_int4_mmap(str(mmap_path))
    assert info["bytes"] > 0
    npz_path = tmp_path / "toy_int4.npz"
    save_numpy_int4_checkpoint(src, str(npz_path), quantize_embeddings=True)
    m_mm, meta = load_numpy_checkpoint(str(mmap_path))
    m_pk, meta_p = load_numpy_checkpoint(str(npz_path), keep_packed=True)
    assert meta.get("loaded_n4m") is True
    assert meta.get("loaded_int4") is True
    assert meta_p.get("keep_packed") is True
    ids = np.array([[1, 2, 3, 4]], dtype=np.int64)
    logits_p, _ = m_pk.forward(ids)
    logits_m, _ = m_mm.forward(ids)
    assert np.allclose(logits_p, logits_m, atol=1e-5, rtol=1e-5)
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    assert np.array_equal(
        generate_numpy(m_pk, prompt, n_new=6, temperature=0.0),
        generate_numpy(m_mm, prompt, n_new=6, temperature=0.0),
    )
    nll_p = nll_numpy(m_pk, ids)
    nll_m = nll_numpy(m_mm, ids)
    assert abs(nll_p.nll - nll_m.nll) < 1e-6
    lazy, lmeta = load_numpy_checkpoint(str(mmap_path), keep_packed=True)
    assert lmeta.get("keep_packed") and lmeta.get("loaded_n4m")
    assert np.array_equal(
        generate_numpy(m_mm, prompt, n_new=6, temperature=0.0),
        generate_numpy(lazy, prompt, n_new=6, temperature=0.0),
    )


def test_persona_ckpt_candidates_prefer_n4m_order():
    from tools.chat_tool import _persona_ckpt_candidates

    n4m = _persona_ckpt_candidates(prefer_n4m=True)
    assert "tinylm_persona_bpe_l4_int4emb.n4m" in n4m[0]
    default = _persona_ckpt_candidates()
    assert "tinylm_persona.npz" in default[0]
    packed = _persona_ckpt_candidates(
        prefer_bpe=True, prefer_int4=True, prefer_int4_emb=True, prefer_l4=True, prefer_n4m=True
    )
    assert "tinylm_persona_bpe_l4_int4emb.n4m" in packed[0]
    no_flag = _persona_ckpt_candidates(prefer_bpe=True, prefer_int4=True, prefer_int4_emb=True)
    assert "tinylm_persona_bpe_int4emb.npz" in no_flag[0]


def test_prefer_n4m_env_and_build_chat(monkeypatch):
    from tools import chat_tool

    monkeypatch.delenv("ORBIT_TINYLM_N4M", raising=False)
    monkeypatch.delenv("ORBIT_TINYLM_FORMAT", raising=False)
    assert chat_tool._prefer_n4m_ckpt() is False
    monkeypatch.setenv("ORBIT_TINYLM_N4M", "1")
    assert chat_tool._prefer_n4m_ckpt() is True
    monkeypatch.delenv("ORBIT_TINYLM_N4M", raising=False)
    monkeypatch.setenv("ORBIT_TINYLM_FORMAT", "n4m")
    assert chat_tool._prefer_n4m_ckpt() is True
    monkeypatch.setenv("ORBIT_TINYLM_CKPT", "")
    model = chat_tool.build_chat_tinylm()
    path = getattr(model, "_ckpt_path", "") or ""
    assert path.endswith(".n4m")
    assert getattr(model, "_ckpt_meta", {}).get("loaded_n4m") is True


def test_shipped_persona_l4_int4_mmap_when_present():
    from tinylm import load_numpy_checkpoint, save_numpy_int4_mmap, is_numpy_int4_mmap
    from tinylm.generate import generate_numpy

    root = Path(__file__).resolve().parents[2]
    fp = root / "checkpoints" / "tinylm_persona_bpe_l4.npz"
    emb = root / "checkpoints" / "tinylm_persona_bpe_l4_int4emb.npz"
    mmap_path = root / "checkpoints" / "tinylm_persona_bpe_l4_int4emb.n4m"
    if not (fp.exists() and emb.exists()):
        return
    if not mmap_path.exists():
        src, _ = load_numpy_checkpoint(str(fp))
        save_numpy_int4_mmap(src, str(mmap_path), extra={"source": "l4_fp32"}, quantize_embeddings=True)
    assert is_numpy_int4_mmap(str(mmap_path))
    emb_m, _ = load_numpy_checkpoint(str(emb))
    mm_m, meta = load_numpy_checkpoint(str(mmap_path))
    assert meta.get("loaded_n4m") is True
    assert meta.get("quantize_embeddings") is True
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    ge = generate_numpy(emb_m, prompt, n_new=8, temperature=0.0)
    gm = generate_numpy(mm_m, prompt, n_new=8, temperature=0.0)
    assert np.array_equal(ge, gm)
    assert mmap_path.stat().st_size < fp.stat().st_size


def test_science_math_units():
    from science_math import solve_science_math
    r = solve_science_math("100 km to m")
    assert r["ok"] and float(r["result"]) == 100000
    r = solve_science_math("0 celsius to fahrenheit")
    assert r["ok"] and abs(float(r["result"]) - 32) < 1e-6
    r = solve_science_math("2 kg to g")
    assert r["ok"] and float(r["result"]) == 2000


def test_apply_rope_context_extension_learned_pos_clamped():
    from tools.chat_tool import apply_rope_context_extension
    from tinylm import TinyLMConfig

    cfg = TinyLMConfig(vocab_size=32, n_layer=1, n_embd=8, n_head=2, block_size=16, use_rope=False)
    keep, n_new, factor = apply_rope_context_extension(cfg, prompt_len=40, want=8)
    assert keep == 15 and n_new == 1 and factor == 1.0


def test_apply_rope_context_extension_yarn_grows_limit():
    from tools.chat_tool import apply_rope_context_extension
    from tinylm import TinyLMConfig

    cfg = TinyLMConfig(
        vocab_size=32, n_layer=1, n_embd=8, n_head=2, block_size=16, use_rope=True, rope_scaling="none", rope_factor=1.0
    )
    keep, n_new, factor = apply_rope_context_extension(cfg, prompt_len=40, want=8, max_factor=4.0)
    assert factor >= 3.0
    assert cfg.rope_scaling == "yarn"
    assert keep == 40
    assert n_new == 8
    assert cfg.max_seq_len() >= 48


def test_generate_chat_extend_keeps_long_prompt():
    import numpy as np
    from tinylm import TinyLMConfig, TinyLMNumPy
    from tools.chat_tool import generate_chat_tinylm

    cfg = TinyLMConfig(
        vocab_size=128, n_layer=2, n_embd=16, n_head=4, block_size=16, use_rope=True, qk_norm=True
    )
    m = TinyLMNumPy.from_config(cfg, seed=0)
    long = "hello world " * 20
    off = generate_chat_tinylm(long, model=m, max_tokens=4, temperature=0.0, extend_context=False)
    on = generate_chat_tinylm(long, model=m, max_tokens=4, temperature=0.0, extend_context=True)
    assert off["ok"] and on["ok"]
    assert off["prompt_tokens"] <= 15
    assert on["extended"] is True
    assert on["prompt_tokens"] > off["prompt_tokens"]
    assert on["rope_factor"] >= 2.0
    assert np.isfinite(on["tok_s"])


def test_trim_chat_completion_keeps_internal_newline():
    from tools.chat_tool import trim_chat_completion

    multi = "line one\nline two\nuser: next"
    assert trim_chat_completion(multi, stop_on_newline=False) == "line one\nline two"
    assert trim_chat_completion(multi, stop_on_newline=True) == "line one"
    assert trim_chat_completion("ok\n\nmore") == "ok"


class _SeqStub:
    def __init__(self, seq, vocab=128):
        from tinylm import TinyLMConfig

        self.config = TinyLMConfig(vocab_size=vocab, n_layer=1, n_embd=8, n_head=2, block_size=64)
        self.cfg = self.config
        self.seq = list(seq)
        self.i = 0

    def alloc_kv_caches(self, *a, **k):
        return None

    def forward(self, idx, kv_caches=None, cache_pos=None):
        import numpy as np

        b, t = idx.shape
        logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
        tok = self.seq[min(self.i, len(self.seq) - 1)]
        self.i += 1
        logits[:, -1, tok] = 10.0
        return logits, kv_caches


def test_generate_chat_default_does_not_stop_on_newline():
    from tools.chat_tool import generate_chat_tinylm

    # 65='A', 10='\n', 66='B', then EOS=127
    m = _SeqStub([65, 10, 66, 127], vocab=128)
    off = generate_chat_tinylm(
        "hi", model=m, max_tokens=8, temperature=0.0, stop_on_newline=False, preamble=""
    )
    assert off["ok"]
    assert off["stop_on_newline"] is False
    assert off["n_new"] == 3
    from tools.chat_tool import _ids_to_text

    assert off["text"] == _ids_to_text([65, 10, 66], 128)

    # Byte-lab maps raw byte 10 to id lo+(10%span)=11 when used as a stop id.
    m2 = _SeqStub([65, 11, 66, 127], vocab=128)
    on = generate_chat_tinylm(
        "hi", model=m2, max_tokens=8, temperature=0.0, stop_on_newline=True, preamble=""
    )
    assert on["stop_on_newline"] is True
    assert on["n_new"] == 1
    assert on["text"] == _ids_to_text([65], 128)
    assert off["n_new"] > on["n_new"]


def test_generate_chat_min_new_skips_first_eos():
    from tools.chat_tool import generate_chat_tinylm, _ids_to_text

    # First greedy token is EOS=127; alt=65 ('A') is runner-up.
    class _EosFirst(_SeqStub):
        def forward(self, idx, kv_caches=None, cache_pos=None):
            import numpy as np

            b, t = idx.shape
            logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
            logits[:, -1, 65] = 5.0
            logits[:, -1, 127] = 10.0
            return logits, kv_caches

    m = _EosFirst([127], vocab=128)
    off = generate_chat_tinylm(
        "hi", model=m, max_tokens=4, temperature=0.0, preamble="", min_new_tokens=0
    )
    assert off["min_new_tokens"] == 0
    assert off["n_new"] == 0  # EOS stripped after halt

    m2 = _EosFirst([127], vocab=128)
    on = generate_chat_tinylm(
        "hi", model=m2, max_tokens=4, temperature=0.0, preamble="", min_new_tokens=1
    )
    assert on["min_new_tokens"] == 1
    assert on["n_new"] >= 1
    assert on["text"] == _ids_to_text([65], 128)


class _LoopStub:
    """Always prefers token `loop` so greedy decode without n-gram ban repeats it."""

    def __init__(self, loop=3, alt=5, vocab=16):
        self.config = TinyLMConfig(vocab_size=vocab, n_layer=1, n_embd=8, n_head=2, block_size=32)
        self.cfg = self.config
        self.loop = loop
        self.alt = alt
        self.n_calls = 0

    def alloc_kv_caches(self, *a, **k):
        return None

    def forward(self, idx, kv_caches=None, cache_pos=None):
        self.n_calls += 1
        b, t = idx.shape
        logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
        logits[:, -1, self.alt] = 5.0
        logits[:, -1, self.loop] = 10.0
        return logits, kv_caches


def test_no_repeat_ngram_breaks_unigram_loop():
    from tinylm.generate import generate_numpy, banned_ngram_tokens

    assert banned_ngram_tokens([1, 2, 3, 1, 2], 3) == [3]
    assert banned_ngram_tokens([7, 7], 2) == [7]
    assert banned_ngram_tokens([1, 2], 3) == []

    stub = _LoopStub()
    prompt = np.array([[1, 2]], dtype=np.int64)
    looping = generate_numpy(stub, prompt, n_new=4, use_cache=False)
    assert looping[0, 2:].tolist() == [3, 3, 3, 3]

    stub2 = _LoopStub()
    banned = generate_numpy(
        stub2, prompt, n_new=4, use_cache=True, prealloc=False, no_repeat_ngram_size=2
    )
    # Size 2 bans completing a seen bigram. After [1,2,3] prefix (3,) is
    # unseen, so a second 3 is allowed; then (3,)->3 is banned and alt=5 wins.
    new = banned[0, 2:].tolist()
    assert new[0] == 3, new
    assert new != [3, 3, 3, 3], new
    assert 5 in new, new
    full = banned[0].tolist()
    # After the first 3,3 pair, 3 is never immediately followed by 3 again.
    seen_33 = False
    for i in range(len(full) - 1):
        if full[i] == 3 and full[i + 1] == 3:
            assert not seen_33, full
            seen_33 = True


def test_generate_chat_no_repeat_ngram_default():
    from tools.chat_tool import generate_chat_tinylm

    class _Repeat(_SeqStub):
        def forward(self, idx, kv_caches=None, cache_pos=None):
            import numpy as np

            b, t = idx.shape
            logits = np.full((b, t, self.config.vocab_size), -20.0, dtype=np.float64)
            logits[:, -1, 65] = 10.0
            logits[:, -1, 66] = 5.0
            return logits, kv_caches

    m = _Repeat([65], vocab=128)
    off = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=4,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
    )
    assert off["no_repeat_ngram_size"] == 0
    assert off["n_new"] == 4

    m2 = _Repeat([65], vocab=128)
    on = generate_chat_tinylm(
        "hi",
        model=m2,
        max_tokens=4,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=2,
    )
    assert on["no_repeat_ngram_size"] == 2
    # After first 'A'(65), repeating 65 is banned so 'B'(66) is next.
    from tools.chat_tool import _ids_to_text

    assert on["n_new"] >= 2
    assert on["text"][0] == _ids_to_text([65], 128)
    assert "B" in on["text"] or on["text"] != _ids_to_text([65, 65, 65, 65], 128)


def test_min_p_keeps_mode_and_drops_tail():
    from tinylm.generate import apply_min_p_np, sample_numpy

    logits = np.array([4.0, 0.0, -2.0, 3.5], dtype=np.float64)
    # After softmax, token 0 is mode. min_p=0.5 keeps only tokens near p_max.
    filtered = apply_min_p_np(logits, 0.5)
    assert filtered[0] == logits[0]
    assert filtered[2] < -1e8
    # min_p=1.0 + temperature>0 is deterministic: only the mode remains.
    picks = {sample_numpy(logits, temperature=1.0, min_p=1.0, rng=np.random.default_rng(i)) for i in range(8)}
    assert picks == {0}


def test_generate_min_p_ignored_when_greedy():
    from tinylm.generate import generate_numpy

    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=2)
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    a = generate_numpy(m, prompt, 6, temperature=0.0, min_p=0.0)
    b = generate_numpy(m, prompt, 6, temperature=0.0, min_p=0.9)
    assert np.array_equal(a, b)


def test_generate_chat_min_p_default_on_temperature():
    from tools.chat_tool import generate_chat_tinylm

    m = _SeqStub([65, 66, 67], vocab=128)
    greedy = generate_chat_tinylm(
        "hi", model=m, max_tokens=3, temperature=0.0, preamble="", min_new_tokens=0, no_repeat_ngram_size=0
    )
    assert greedy["min_p"] == 0.0
    sampled = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=3,
        temperature=0.8,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
    )
    assert abs(sampled["min_p"] - 0.05) < 1e-9
    override = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=3,
        temperature=0.8,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        min_p=0.2,
    )
    assert abs(override["min_p"] - 0.2) < 1e-9


def test_presence_frequency_subtracts_seen_tokens():
    from tinylm.generate import apply_presence_frequency_np

    logits = np.array([0.0, 0.0, 0.0, 0.0], dtype=np.float64)
    out = apply_presence_frequency_np(logits, [1, 1, 2], presence_penalty=0.5, frequency_penalty=0.25)
    assert out[0] == 0.0
    assert abs(out[1] - (-0.5 - 0.5)) < 1e-9  # presence + 2 * freq
    assert abs(out[2] - (-0.5 - 0.25)) < 1e-9
    assert out[3] == 0.0
    same = apply_presence_frequency_np(logits, [1, 2], presence_penalty=0.0, frequency_penalty=0.0)
    assert np.array_equal(same, logits)


def test_frequency_penalty_breaks_unigram_loop():
    from tinylm.generate import generate_numpy

    stub = _LoopStub()
    prompt = np.array([[1, 2]], dtype=np.int64)
    looping = generate_numpy(stub, prompt, n_new=6, use_cache=False)
    assert looping[0, 2:].tolist() == [3, 3, 3, 3, 3, 3]

    stub2 = _LoopStub()
    # After a few 3s, 10 - freq*count drops below alt=5.
    diverted = generate_numpy(
        stub2, prompt, n_new=6, use_cache=False, frequency_penalty=2.0
    )
    new = diverted[0, 2:].tolist()
    assert new[0] == 3
    assert 5 in new, new
    assert new != [3, 3, 3, 3, 3, 3]


def test_generate_chat_frequency_default():
    from tools.chat_tool import generate_chat_tinylm

    m = _SeqStub([65, 66], vocab=128)
    out = generate_chat_tinylm(
        "hi", model=m, max_tokens=2, temperature=0.0, preamble="", min_new_tokens=0, no_repeat_ngram_size=0
    )
    assert abs(out["frequency_penalty"] - 0.2) < 1e-9
    assert abs(out["presence_penalty"] - 0.0) < 1e-9
    off = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=2,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        frequency_penalty=0.0,
        presence_penalty=0.4,
    )
    assert off["frequency_penalty"] == 0.0
    assert abs(off["presence_penalty"] - 0.4) < 1e-9


def test_typical_p_noop_at_one_and_keeps_mode():
    from tinylm.generate import apply_typical_p_np, sample_numpy

    logits = np.array([3.0, 2.5, 2.4, -4.0], dtype=np.float64)
    same = apply_typical_p_np(logits, 1.0)
    assert np.allclose(same, logits)
    off = apply_typical_p_np(logits, 0.0)
    assert np.allclose(off, logits)
    filtered = apply_typical_p_np(logits, 0.2)
    # Lowest |−log p − H| token survives; the far tail is dropped.
    assert filtered[3] < -1e8
    assert np.isfinite(filtered[0])
    picks = {
        sample_numpy(logits, temperature=1.0, typical_p=0.01, rng=np.random.default_rng(i))
        for i in range(6)
    }
    assert len(picks) == 1


def test_generate_typical_p_ignored_when_greedy():
    from tinylm.generate import generate_numpy

    cfg = _cfg(use_rope=True, qk_norm=True)
    m = TinyLMNumPy.from_config(cfg, seed=2)
    prompt = np.array([[1, 2, 3]], dtype=np.int64)
    a = generate_numpy(m, prompt, 6, temperature=0.0, typical_p=1.0)
    b = generate_numpy(m, prompt, 6, temperature=0.0, typical_p=0.2)
    assert a.tolist() == b.tolist()


def test_generate_chat_typical_p_default_off():
    from tools.chat_tool import generate_chat_tinylm

    m = _SeqStub([65, 66], vocab=128)
    out = generate_chat_tinylm(
        "hi", model=m, max_tokens=2, temperature=0.8, preamble="", min_new_tokens=0, no_repeat_ngram_size=0
    )
    assert abs(out["typical_p"] - 1.0) < 1e-9
    on = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=2,
        temperature=0.8,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        typical_p=0.95,
    )
    assert abs(on["typical_p"] - 0.95) < 1e-9


def test_dry_match_lengths_and_penalty():
    from tinylm.generate import apply_dry_np, dry_max_match_lengths

    # "... a b c a b" — next token that would extend "a b" after earlier "a b c"
    # is c, with match length 2.
    seq = [1, 2, 3, 1, 2]
    matches = dry_max_match_lengths(seq, last_n=16)
    assert matches.get(3) == 2
    logits = np.array([0.0, 0.0, 0.0, 5.0, 0.0], dtype=np.float64)
    off = apply_dry_np(logits, seq, multiplier=0.0)
    assert np.allclose(off, logits)
    # allowed_length=2 means match of 2 is NOT penalized
    same = apply_dry_np(logits, seq, multiplier=0.8, allowed_length=2)
    assert np.allclose(same, logits)
    # allowed_length=1 → penalty 0.8 * 1.75**(2-1) = 1.4
    on = apply_dry_np(logits, seq, multiplier=0.8, base=1.75, allowed_length=1)
    assert abs((5.0 - on[3]) - 0.8 * 1.75) < 1e-9
    # longer loop: "x y z x y z x y" next z has match 2 from last z and 5? 
    # last token y at end. Earlier y at index 1 followed by z, match of [x y]?
    loop = [9, 10, 11, 9, 10, 11, 9, 10]
    m2 = dry_max_match_lengths(loop, last_n=32)
    assert m2.get(11) >= 2


def test_generate_dry_breaks_verbatim_loop():
    from tinylm.generate import generate_numpy

    class _LoopStub:
        def __init__(self):
            self.config = type("C", (), {"vocab_size": 16, "block_size": 64})()
            self.cfg = self.config

        def alloc_kv_caches(self, b, t):
            return None

        def forward(self, idx, kv_caches=None, cache_pos=None):
            # Always prefer token 7; after seeing 7,7 the DRY match grows.
            v = 16
            row = np.full(v, -20.0)
            row[7] = 8.0
            row[3] = 7.5
            logits = np.broadcast_to(row, (idx.shape[0], idx.shape[1], v)).copy()
            return logits, kv_caches

    m = _LoopStub()
    prompt = np.array([[7, 7, 7]], dtype=np.int64)
    greedy = generate_numpy(m, prompt, 6, temperature=0.0, dry_multiplier=0.0, use_cache=False)
    assert greedy[0, 3:].tolist() == [7, 7, 7, 7, 7, 7]
    diverted = generate_numpy(
        m,
        prompt,
        6,
        temperature=0.0,
        dry_multiplier=8.0,
        dry_base=2.0,
        dry_allowed_length=1,
        dry_last_n=16,
        use_cache=False,
    )
    new = diverted[0, 3:].tolist()
    assert 7 not in new or new != [7, 7, 7, 7, 7, 7]
    assert 3 in new


def test_generate_chat_dry_default():
    from tools.chat_tool import generate_chat_tinylm

    m = _SeqStub([65, 66], vocab=128)
    out = generate_chat_tinylm(
        "hi", model=m, max_tokens=2, temperature=0.0, preamble="", min_new_tokens=0, no_repeat_ngram_size=0
    )
    assert abs(out["dry_multiplier"] - 0.8) < 1e-9
    assert abs(out["dry_base"] - 1.75) < 1e-9
    assert out["dry_allowed_length"] == 2
    off = generate_chat_tinylm(
        "hi",
        model=m,
        max_tokens=2,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        dry_multiplier=0.0,
    )
    assert off["dry_multiplier"] == 0.0


def test_mirostat_v2_truncates_high_surprise_and_updates_mu():
    from tinylm.generate import sample_mirostat_v2_np

    logits = np.array([5.0, 4.5, -8.0, -8.0], dtype=np.float64)
    # Very low mu keeps only the mode.
    tok, mu_new = sample_mirostat_v2_np(logits, mu=0.5, tau=5.0, eta=0.1, rng=np.random.default_rng(0))
    assert tok == 0
    assert mu_new != 0.5
    # High mu keeps the full support; still a valid token.
    toks = {
        sample_mirostat_v2_np(logits, mu=20.0, tau=5.0, eta=0.1, rng=np.random.default_rng(i))[0]
        for i in range(20)
    }
    assert toks <= {0, 1, 2, 3}


def test_generate_mirostat_off_matches_greedy():
    from tinylm.generate import generate_numpy

    class _Stub:
        def forward(self, idx, kv_caches=None, cache_pos=None):
            v = 8
            row = np.zeros(v)
            row[2] = 4.0
            row[5] = 1.0
            logits = np.broadcast_to(row, (idx.shape[0], idx.shape[1], v)).copy()
            return logits, kv_caches

    m = _Stub()
    prompt = np.array([[1, 1]], dtype=np.int64)
    a = generate_numpy(m, prompt, 5, temperature=0.0, use_cache=False, mirostat=0)
    b = generate_numpy(m, prompt, 5, temperature=0.0, use_cache=False, mirostat=0, mirostat_tau=3.0)
    assert a.tolist() == b.tolist()
    assert a[0, 2:].tolist() == [2, 2, 2, 2, 2]


def test_generate_mirostat_v2_samples_and_chat_default_off():
    from tinylm.generate import generate_numpy
    from tools.chat_tool import generate_chat_tinylm

    class _Stub:
        def forward(self, idx, kv_caches=None, cache_pos=None):
            v = 8
            row = np.array([0.0, 3.0, 2.5, 0.5, -2.0, -2.0, -2.0, -2.0])
            logits = np.broadcast_to(row, (idx.shape[0], idx.shape[1], v)).copy()
            return logits, kv_caches

        def __init__(self):
            self.config = type("C", (), {"vocab_size": 128, "block_size": 64})()
            self.cfg = self.config

        def alloc_kv_caches(self, b, t):
            return None

    m = _Stub()
    prompt = np.array([[0, 0]], dtype=np.int64)
    out = generate_numpy(
        m, prompt, 8, temperature=1.0, use_cache=False, mirostat=2, mirostat_tau=5.0, seed=0
    )
    assert out.shape == (1, 10)
    assert all(0 <= int(t) < 8 for t in out[0].tolist())
    chat = generate_chat_tinylm(
        "hi", model=_SeqStub([65, 66], vocab=128), max_tokens=2, temperature=0.0, preamble="", min_new_tokens=0, no_repeat_ngram_size=0
    )
    assert chat["mirostat"] == 0
    on = generate_chat_tinylm(
        "hi",
        model=_SeqStub([65, 66], vocab=128),
        max_tokens=2,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        mirostat=2,
        mirostat_tau=4.0,
    )
    assert on["mirostat"] == 2
    assert abs(on["mirostat_tau"] - 4.0) < 1e-9


def test_xtc_excludes_high_prob_keeps_least_above():
    from tinylm.generate import apply_xtc_np

    # Two tokens above 0.1, two below. Always-on XTC should drop the
    # highest-p token and keep the least-p token among those above thr.
    logits = np.array([4.0, 2.0, -1.0, -2.0], dtype=np.float64)
    rng = np.random.default_rng(0)
    out = apply_xtc_np(logits, probability=1.0, threshold=0.1, rng=rng)
    z = logits - logits.max()
    p = np.exp(z)
    p = p / p.sum()
    above = p > 0.1
    assert int(above.sum()) >= 2
    keep = int(np.argmin(np.where(above, p, np.inf)))
    assert out[keep] > -1e8
    for i, flag in enumerate(above):
        if flag and i != keep:
            assert out[i] <= -1e8
    # probability 0 is a no-op
    same = apply_xtc_np(logits, probability=0.0, threshold=0.1, rng=rng)
    assert np.allclose(same, logits)


def test_generate_xtc_off_matches_greedy_and_chat_default():
    from tinylm.generate import generate_numpy
    from tools.chat_tool import generate_chat_tinylm

    class _Stub:
        def forward(self, idx, kv_caches=None, cache_pos=None):
            v = 8
            row = np.zeros(v)
            row[3] = 5.0
            row[1] = 2.0
            logits = np.broadcast_to(row, (idx.shape[0], idx.shape[1], v)).copy()
            return logits, kv_caches

    m = _Stub()
    prompt = np.array([[1, 1]], dtype=np.int64)
    a = generate_numpy(m, prompt, 4, temperature=0.0, use_cache=False, xtc_probability=0.0)
    b = generate_numpy(m, prompt, 4, temperature=0.0, use_cache=False, xtc_probability=1.0)
    assert a.tolist() == b.tolist()
    assert a[0, 2:].tolist() == [3, 3, 3, 3]
    sampled = generate_numpy(
        m, prompt, 6, temperature=1.0, use_cache=False, xtc_probability=1.0, xtc_threshold=0.1, seed=1
    )
    assert sampled.shape == (1, 8)
    assert all(0 <= int(t) < 8 for t in sampled[0].tolist())
    chat = generate_chat_tinylm(
        "hi",
        model=_SeqStub([65, 66], vocab=128),
        max_tokens=2,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
    )
    assert abs(chat["xtc_probability"] - 0.0) < 1e-9
    on = generate_chat_tinylm(
        "hi",
        model=_SeqStub([65, 66], vocab=128),
        max_tokens=2,
        temperature=0.0,
        preamble="",
        min_new_tokens=0,
        no_repeat_ngram_size=0,
        xtc_probability=0.5,
        xtc_threshold=0.2,
    )
    assert abs(on["xtc_probability"] - 0.5) < 1e-9
    assert abs(on["xtc_threshold"] - 0.2) < 1e-9
