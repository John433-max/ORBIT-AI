"""
Document chat / RAG system (spec Phases 3-5).

Honest design note on "answering questions about documents": this repo's
own TinyLM is ~135K-780K parameters trained on ~4KB of text (see model.py /
DESIGN.md) -- nowhere near capable of abstractive summarization or free-form
generation grounded in arbitrary uploaded documents. Claiming otherwise
would violate this project's own no-fake-features rule. So this module is
deliberately RETRIEVAL + EXTRACTIVE, not generative:
  - retrieval: rank document chunks by similarity to the query (hash-embed
    cosine + a lexical-overlap rerank term -- both real, cheap, and testable,
    not a placeholder).
  - extraction: pull the most relevant sentence(s) out of the winning
    chunk(s) rather than asking the tiny LM to "write an answer".
  - summarization: a real (if simple) frequency-based extractive summarizer
    (classic technique, no ML dependency) -- picks the N highest-scoring
    original sentences, in original order. Not abstractive; it will not
    produce sentences that don't appear in the source.
Every answer is grounded in and cites an actual retrieved chunk. If nothing
clears the relevance threshold, the system says so (see `Support` levels)
instead of guessing -- this is Phase 19's hallucination-control requirement
applied concretely here, not just declared.
"""
import re
import csv
import io
import json
import time
import sqlite3
import threading
from collections import Counter
from enum import Enum

import numpy as np

from memory_store import hash_embed

# Optional format support: PDF/DOCX need third-party libraries. Missing
# either one degrades that format only -- never silently fakes extraction.
try:
    import pypdf
    _PDF_AVAILABLE = True
except ImportError:
    _PDF_AVAILABLE = False

try:
    import docx as _docx_lib
    _DOCX_AVAILABLE = True
except ImportError:
    _DOCX_AVAILABLE = False

try:
    from pptx import Presentation as _PptxPresentation
    _PPTX_AVAILABLE = True
except ImportError:
    _PPTX_AVAILABLE = False

SUPPORTED_FORMATS = {"txt", "md", "markdown", "csv", "json"}
if _PDF_AVAILABLE:
    SUPPORTED_FORMATS.add("pdf")
if _DOCX_AVAILABLE:
    SUPPORTED_FORMATS.add("docx")
if _PPTX_AVAILABLE:
    SUPPORTED_FORMATS.add("pptx")


class Support(str, Enum):
    """Phase 19 hallucination-control states. Set from retrieval scores, not
    from the LM's own confidence -- a tiny model's stated confidence isn't
    evidence of anything, so it's never used as a signal here."""
    SUPPORTED = "SUPPORTED"
    PARTIALLY_SUPPORTED = "PARTIALLY_SUPPORTED"
    UNSUPPORTED = "UNSUPPORTED"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# Loaders: return (full_text, pages) where pages is a list of (page_number,
# page_text) -- page_number is None for formats with no page concept.
# ---------------------------------------------------------------------------

def load_txt(raw_bytes: bytes):
    text = raw_bytes.decode("utf-8", errors="replace")
    return text, [(None, text)]


def load_markdown(raw_bytes: bytes):
    return load_txt(raw_bytes)


def load_csv(raw_bytes: bytes):
    text = raw_bytes.decode("utf-8", errors="replace")
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return "", [(None, "")]
    header, body = rows[0], rows[1:]
    lines = [", ".join(header)]
    for row in body:
        lines.append(", ".join(row))
    rendered = "\n".join(lines)
    return rendered, [(None, rendered)]


def load_json(raw_bytes: bytes):
    text = raw_bytes.decode("utf-8", errors="replace")
    try:
        parsed = json.loads(text)
        pretty = json.dumps(parsed, indent=2, ensure_ascii=False)
    except json.JSONDecodeError:
        pretty = text  # malformed JSON: still index as raw text rather than failing the upload
    return pretty, [(None, pretty)]


def load_pdf(raw_bytes: bytes):
    if not _PDF_AVAILABLE:
        raise RuntimeError("PDF support requires the 'pypdf' package, which is not installed.")
    reader = pypdf.PdfReader(io.BytesIO(raw_bytes))
    pages = []
    full_parts = []
    for i, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text() or ""
        pages.append((i, page_text))
        full_parts.append(page_text)
    return "\n".join(full_parts), pages


def load_docx(raw_bytes: bytes):
    if not _DOCX_AVAILABLE:
        raise RuntimeError("DOCX support requires the 'python-docx' package, which is not installed.")
    doc = _docx_lib.Document(io.BytesIO(raw_bytes))
    paras = [p.text for p in doc.paragraphs]
    text = "\n".join(paras)
    return text, [(None, text)]


def load_pptx(raw_bytes: bytes):
    """Cycle 52: optional PowerPoint text extraction via python-pptx."""
    if not _PPTX_AVAILABLE:
        raise RuntimeError("PPTX support requires the 'python-pptx' package, which is not installed.")
    prs = _PptxPresentation(io.BytesIO(raw_bytes))
    pages = []
    full_parts = []
    for i, slide in enumerate(prs.slides, start=1):
        parts = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text:
                parts.append(shape.text)
        page_text = "\n".join(parts)
        pages.append((i, page_text))
        full_parts.append(page_text)
    return "\n\n".join(full_parts), pages


_LOADERS = {
    "txt": load_txt, "md": load_markdown, "markdown": load_markdown,
    "csv": load_csv, "json": load_json, "pdf": load_pdf, "docx": load_docx,
    "pptx": load_pptx,
}


def sanitize_filename(filename: str) -> str:
    """Strip path components and reject empty / dangerous names."""
    import os

    name = os.path.basename((filename or "").replace("\\", "/").strip())
    # Null bytes and control characters are never legitimate in a display name.
    name = "".join(ch for ch in name if ch.isprintable() and ch not in ("\x00", "/"))
    if not name or name in (".", ".."):
        raise ValueError("invalid filename")
    if len(name) > 255:
        name = name[:255]
    return name


# Lightweight magic-byte checks (extension alone is not enough).
_MAGIC_PREFIXES = {
    "pdf": (b"%PDF",),
    "png": (b"\x89PNG\r\n\x1a\n",),
    "jpg": (b"\xff\xd8\xff",),
    "jpeg": (b"\xff\xd8\xff",),
    "docx": (b"PK\x03\x04",),  # zip container
    "pptx": (b"PK\x03\x04",),
}


def _check_magic(ext: str, raw_bytes: bytes) -> None:
    prefixes = _MAGIC_PREFIXES.get(ext)
    if not prefixes:
        return
    if not any(raw_bytes.startswith(p) for p in prefixes):
        raise ValueError(
            f"file content does not match declared type '.{ext}' "
            f"(magic-byte mismatch — possible spoofed upload)"
        )


def load_document(filename: str, raw_bytes: bytes):
    filename = sanitize_filename(filename)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in SUPPORTED_FORMATS:
        available = ", ".join(sorted(SUPPORTED_FORMATS))
        raise ValueError(f"unsupported file type '.{ext}'. Supported: {available}")
    if not isinstance(raw_bytes, (bytes, bytearray)):
        raise ValueError("document content must be bytes")
    if len(raw_bytes) == 0:
        raise ValueError("empty document")
    # Soft cap aligned with API base64 max (~10MB decoded)
    if len(raw_bytes) > 10_500_000:
        raise ValueError("document exceeds maximum allowed size (10MB)")
    _check_magic(ext, raw_bytes)
    return _LOADERS[ext](raw_bytes)


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text: str) -> list:
    text = text.strip()
    if not text:
        return []
    return [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 80) -> list:
    """Character-based sliding-window chunking with overlap, breaking on
    sentence boundaries where possible so chunks don't cut mid-sentence.
    Returns a list of chunk strings."""
    sentences = split_sentences(text)
    if not sentences:
        return []
    chunks = []
    current = []
    current_len = 0
    for sent in sentences:
        if current_len + len(sent) > chunk_size and current:
            chunks.append(" ".join(current))
            # carry the tail of the previous chunk forward for overlap
            tail = []
            tail_len = 0
            for s in reversed(current):
                if tail_len + len(s) > overlap:
                    break
                tail.insert(0, s)
                tail_len += len(s)
            current = tail
            current_len = tail_len
        current.append(sent)
        current_len += len(sent)
    if current:
        chunks.append(" ".join(current))
    return chunks


def chunk_pages(pages: list, chunk_size: int = 500, overlap: int = 80) -> list:
    """pages: list of (page_number, page_text). Returns list of
    (page_number, chunk_text) preserving which page each chunk came from."""
    out = []
    for page_num, page_text in pages:
        for c in chunk_text(page_text, chunk_size, overlap):
            out.append((page_num, c))
    return out


# ---------------------------------------------------------------------------
# Extractive summarization (real algorithm, not a placeholder -- classic
# word-frequency sentence scoring, used in extractive summarizers before
# neural approaches existed)
# ---------------------------------------------------------------------------

_STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "in", "on", "at", "of", "to", "and", "or",
    "for", "with", "this", "that", "it", "as", "by", "be", "from", "has", "have", "had",
}


def extractive_summarize(text: str, n_sentences: int = 3) -> list:
    """Returns the top `n_sentences` original sentences by word-frequency
    score, in their original order. Every returned sentence is verbatim
    from `text` -- nothing is generated. Used for whole-document summaries
    (no query to anchor on); see query_aware_extract for Q&A."""
    sentences = split_sentences(text)
    if len(sentences) <= n_sentences:
        return sentences
    words = re.findall(r"[a-zA-Z']+", text.lower())
    freqs = Counter(w for w in words if w not in _STOPWORDS)
    if not freqs:
        return sentences[:n_sentences]
    max_freq = max(freqs.values())
    scored = []
    for i, sent in enumerate(sentences):
        sent_words = re.findall(r"[a-zA-Z']+", sent.lower())
        score = sum(freqs.get(w, 0) / max_freq for w in sent_words)
        if i == 0:
            score *= 1.2  # mild position bias: openers often set up the topic
        scored.append((score, i, sent))
    top = sorted(scored, key=lambda t: t[0], reverse=True)[:n_sentences]
    top_in_order = [s for _, _, s in sorted(top, key=lambda t: t[1])]
    return top_in_order


def query_aware_extract(text: str, query: str, n_sentences: int = 2) -> list:
    """Like extractive_summarize, but scores sentences by overlap with the
    query's own words rather than by generic in-document frequency -- for
    Q&A, the sentence that actually addresses the question matters more
    than the sentence that's topically 'central' to the whole chunk."""
    sentences = split_sentences(text)
    if not sentences:
        return []
    if len(sentences) <= n_sentences:
        return sentences
    q_words = set(re.findall(r"[a-zA-Z']+", query.lower())) - _STOPWORDS
    if not q_words:
        return extractive_summarize(text, n_sentences)
    scored = []
    for i, sent in enumerate(sentences):
        sent_words = set(re.findall(r"[a-zA-Z']+", sent.lower()))
        overlap = len(q_words & sent_words)
        scored.append((overlap, i, sent))
    top = sorted(scored, key=lambda t: t[0], reverse=True)[:n_sentences]
    if all(score == 0 for score, _, _ in top):
        # no lexical overlap anywhere in the chunk -- fall back to frequency-based
        return extractive_summarize(text, n_sentences)
    top_in_order = [s for _, _, s in sorted(top, key=lambda t: t[1])]
    return top_in_order


# ---------------------------------------------------------------------------
# Persistent document + chunk store, with retrieval
# ---------------------------------------------------------------------------

def _locked(method):
    """Same rationale as memory_store.py's _locked: FastAPI runs sync
    endpoints in a worker thread pool, so a single long-lived sqlite3
    connection needs serialized access across threads."""
    def wrapper(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    wrapper.__name__ = method.__name__
    wrapper.__doc__ = method.__doc__
    return wrapper


class DocumentStore:
    """SQLite-backed document/chunk store. Chunk embeddings are recomputed
    from stored text at query time (same rationale as
    memory_store.SQLiteVectorStore: cheap, deterministic, never stale)."""

    def __init__(self, db_path: str = "orbit_documents.db", dim: int = 256):
        self.dim = dim
        self._lock = threading.RLock()
        # In-memory cache of chunk_id -> embedding. Without this, search()
        # recomputed hash_embed() for every chunk of every stored document
        # on EVERY query -- with no persistent vector index, that cost was
        # paid in full every single time regardless of how many times the
        # same (unchanged) chunk had already been embedded. hash_embed is
        # deterministic given the same text, so caching by chunk_id is
        # exactly correct as long as the cache is invalidated on delete
        # (done in delete_document below) -- there's no update-in-place
        # path for chunk text, so no separate invalidation-on-edit case to
        # handle. This is not a substitute for a real persistent vector
        # index at large scale (that would also avoid the linear per-query
        # scan over every chunk this still does), but it removes the
        # single biggest redundant cost for a store that's queried more
        # than once, which is the normal case.
        self._embed_cache = {}
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                filetype TEXT NOT NULL,
                uploaded_at REAL NOT NULL,
                num_chunks INTEGER NOT NULL,
                char_count INTEGER NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id INTEGER NOT NULL,
                chunk_index INTEGER NOT NULL,
                page INTEGER,
                section TEXT,
                text TEXT NOT NULL,
                FOREIGN KEY(document_id) REFERENCES documents(id)
            )
        """)
        self._conn.commit()

    @_locked
    def add_document(self, filename: str, raw_bytes: bytes, chunk_size: int = 500, overlap: int = 80) -> dict:
        filename = sanitize_filename(filename)
        text, pages = load_document(filename, raw_bytes)
        ext = filename.rsplit(".", 1)[-1].lower()
        page_chunks = chunk_pages(pages, chunk_size, overlap)
        if not page_chunks:
            raise ValueError("document produced no extractable text (empty or unreadable)")

        cur = self._conn.execute(
            "INSERT INTO documents (filename, filetype, uploaded_at, num_chunks, char_count) "
            "VALUES (?, ?, ?, ?, ?)",
            (filename, ext, time.time(), len(page_chunks), len(text)),
        )
        doc_id = cur.lastrowid
        for i, (page_num, chunk) in enumerate(page_chunks):
            self._conn.execute(
                "INSERT INTO chunks (document_id, chunk_index, page, section, text) VALUES (?, ?, ?, ?, ?)",
                (doc_id, i, page_num, None, chunk),
            )
        self._conn.commit()
        return {"document_id": doc_id, "filename": filename, "num_chunks": len(page_chunks),
                "char_count": len(text)}

    @_locked
    def get_document_text(self, document_id: int) -> str:
        """Reassemble chunk text for a document (Cycle 56 extract)."""
        cur = self._conn.execute(
            "SELECT text FROM chunks WHERE document_id = ? ORDER BY chunk_index",
            (int(document_id),),
        )
        return "\n".join(r[0] for r in cur.fetchall() if r and r[0])

    @_locked
    def list_documents(self) -> list:
        cur = self._conn.execute(
            "SELECT id, filename, filetype, uploaded_at, num_chunks, char_count FROM documents ORDER BY id")
        return [
            {"id": r[0], "filename": r[1], "filetype": r[2], "uploaded_at": r[3],
             "num_chunks": r[4], "char_count": r[5]}
            for r in cur.fetchall()
        ]

    @_locked
    def delete_document(self, document_id: int) -> bool:
        cur = self._conn.execute("SELECT id FROM documents WHERE id = ?", (document_id,))
        if cur.fetchone() is None:
            return False
        chunk_ids = [r[0] for r in self._conn.execute(
            "SELECT id FROM chunks WHERE document_id = ?", (document_id,)).fetchall()]
        self._conn.execute("DELETE FROM chunks WHERE document_id = ?", (document_id,))
        self._conn.execute("DELETE FROM documents WHERE id = ?", (document_id,))
        self._conn.commit()
        for cid in chunk_ids:
            self._embed_cache.pop(cid, None)
        return True

    @_locked
    def _all_chunks(self, document_id: int = None):
        if document_id is not None:
            cur = self._conn.execute(
                "SELECT c.id, c.document_id, d.filename, c.chunk_index, c.page, c.section, c.text "
                "FROM chunks c JOIN documents d ON c.document_id = d.id WHERE c.document_id = ?",
                (document_id,),
            )
        else:
            cur = self._conn.execute(
                "SELECT c.id, c.document_id, d.filename, c.chunk_index, c.page, c.section, c.text "
                "FROM chunks c JOIN documents d ON c.document_id = d.id"
            )
        return cur.fetchall()

    @_locked
    def search(self, query: str, k: int = 5, document_id: int = None) -> list:
        """Retrieve top-k chunks for `query`, ranked by hash-embed cosine
        similarity with a lexical-overlap rerank bonus (Phase 4's
        'reranking' step -- cheap and real, not a stub). Returns chunks with
        their document/page/section metadata attached, per Phase 4's field
        list."""
        rows = self._all_chunks(document_id)
        if not rows:
            return []
        q_vec = hash_embed(query, self.dim)
        q_words = set(re.findall(r"[a-zA-Z']+", query.lower())) - _STOPWORDS

        scored = []
        for chunk_id, doc_id, filename, chunk_idx, page, section, text in rows:
            vec = self._embed_cache.get(chunk_id)
            if vec is None:
                vec = hash_embed(text, self.dim)
                self._embed_cache[chunk_id] = vec
            cos_sim = float(np.dot(q_vec, vec))
            chunk_words = set(re.findall(r"[a-zA-Z']+", text.lower()))
            overlap = len(q_words & chunk_words) / max(1, len(q_words)) if q_words else 0.0
            score = 0.7 * cos_sim + 0.3 * overlap
            scored.append((score, {
                "chunk_id": chunk_id, "document_id": doc_id, "filename": filename,
                "chunk_index": chunk_idx, "page": page, "section": section,
                "text": text, "score": score,
            }))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [item for _, item in scored[:k]]

    @_locked
    def close(self):
        self._conn.close()


# Score thresholds used to derive a Support level from the top retrieval
# score. Heuristic (as any threshold on a hash-embed similarity is) --
# documented here rather than hidden, so the honesty claim is checkable.
SUPPORT_THRESHOLD_FULL = 0.35
SUPPORT_THRESHOLD_PARTIAL = 0.15


def answer_from_documents(store: DocumentStore, question: str, k: int = 3, document_id: int = None) -> dict:
    """Retrieval + extraction, with an honest support level and real
    citations. Never fabricates a citation: `sources` only ever contains
    chunks that were actually retrieved and actually used."""
    hits = store.search(question, k=k, document_id=document_id)
    if not hits:
        return {"answer": "I don't have any indexed documents that relate to this question.",
                "support": Support.UNKNOWN, "sources": []}

    top_score = hits[0]["score"]
    if top_score >= SUPPORT_THRESHOLD_FULL:
        support = Support.SUPPORTED
    elif top_score >= SUPPORT_THRESHOLD_PARTIAL:
        support = Support.PARTIALLY_SUPPORTED
    else:
        support = Support.UNSUPPORTED

    if support == Support.UNSUPPORTED:
        return {"answer": "I don't have verified information about this in the indexed documents.",
                "support": support, "sources": []}

    used = hits[:2] if support == Support.SUPPORTED else hits[:1]
    extracted_sentences = []
    sources = []
    for hit in used:
        sents = query_aware_extract(hit["text"], question, n_sentences=2)
        extracted_sentences.extend(sents)
        loc = f"page {hit['page']}" if hit["page"] else f"chunk {hit['chunk_index']}"
        sources.append({"filename": hit["filename"], "location": loc, "score": round(hit["score"], 3)})

    answer = " ".join(extracted_sentences)
    return {"answer": answer, "support": support, "sources": sources}


def summarize_document(store: DocumentStore, document_id: int, n_sentences: int = 5) -> dict:
    rows = store._all_chunks(document_id)
    if not rows:
        return {"summary": "", "sources": []}
    filename = rows[0][2]
    full_text = " ".join(r[6] for r in sorted(rows, key=lambda r: r[3]))
    summary_sentences = extractive_summarize(full_text, n_sentences=n_sentences)
    return {"summary": " ".join(summary_sentences), "filename": filename,
            "n_chunks_used": len(rows)}
