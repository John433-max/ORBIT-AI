"""
Property-based / fuzz tests (Hypothesis). Targets chosen deliberately for
where fuzzing actually adds value beyond the example-based tests elsewhere
in this project, per the spec's own "do not add fuzz tests merely to
increase coverage" guidance:

  - bpe_tokenizer: round-trip robustness is the single property a
    byte-level tokenizer most needs to hold across arbitrary Unicode, and
    example-based tests can only ever cover the inputs someone thought of.
  - calculator: this is a security-relevant component (AST-restricted, not
    eval-based) -- fuzzing throws unusual/malformed expression shapes at it
    that a human wouldn't necessarily think to write by hand, checking it
    never crashes and never reaches disallowed functionality.
  - documents.chunk_text: arbitrary text (including pathological whitespace
    and Unicode) must never crash the chunker.
  - sampling.sample_next_token: must always return a valid vocabulary
    index for arbitrary logits, since an out-of-range index would corrupt
    downstream decoding.

Kept deliberately small (low max_examples, deadline=None) per the spec's
"do not make the test suite unnecessarily slow" instruction -- these run in
well under a second combined despite each covering dozens of generated cases.
"""
import numpy as np
import pytest
from hypothesis import given, settings, strategies as st, HealthCheck

from calculator import calculate
from documents import chunk_text, split_sentences
from sampling import sample_next_token

FAST = settings(max_examples=50, deadline=None, suppress_health_check=[HealthCheck.too_slow])


# --- Tokenizer round-trip ---

@pytest.fixture(scope="module")
def trained_tokenizer():
    from bpe_tokenizer import BPETokenizer
    corpus = ("the quick brown fox jumps over the lazy dog many times. "
              "ang pusa ay natutulog. def foo(x): return x + 1. "
              '{"key": "value"}. attention is all you need.')
    return BPETokenizer().train(corpus, vocab_size=350, min_frequency=2)


@given(st.text(max_size=200))
@FAST
def test_tokenizer_round_trip_never_crashes_and_is_lossless(trained_tokenizer, text):
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    decoded = trained_tokenizer.decode(ids)
    assert decoded == text


@given(st.text(alphabet=st.characters(min_codepoint=0x1F300, max_codepoint=0x1FAFF), max_size=50))
@FAST
def test_tokenizer_handles_emoji_and_high_unicode(trained_tokenizer, text):
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    assert trained_tokenizer.decode(ids) == text


def test_tokenizer_does_not_crash_on_lone_surrogate():
    """Regression test for a real, fuzzing-found crash: a Python str
    containing an unpaired UTF-16 surrogate code point (e.g. from malformed
    JSON \\uD800-\\uDFFF escapes, or certain encoding-error-handling paths)
    is technically a valid Python string but cannot be represented in
    UTF-8 at all. encode()'s `.encode("utf-8")` call (no errors= argument)
    raised an uncaught UnicodeEncodeError on this input instead of
    degrading gracefully -- found by deliberately constructing a lone
    surrogate and testing it directly (Hypothesis's default text()
    strategy doesn't generate these, so the general round-trip fuzz test
    above wouldn't have caught it on its own)."""
    from bpe_tokenizer import BPETokenizer
    tok = BPETokenizer().train("the quick brown fox", vocab_size=300)
    lone_surrogate = "\ud83d\ude00"  # two separate surrogate-half code points, not a combined emoji
    ids = tok.encode(lone_surrogate, add_bos=False, add_eos=False)  # must not raise
    tok.decode(ids)  # must not raise either


@given(st.text(alphabet=st.characters(min_codepoint=0xD800, max_codepoint=0xDFFF), max_size=20))
@FAST
def test_tokenizer_never_crashes_on_surrogate_range_characters(trained_tokenizer, text):
    """Systematic version of the regression test above -- fuzzes the
    specific codepoint range that caused the crash, rather than relying on
    one hand-picked example staying representative of the whole class."""
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    trained_tokenizer.decode(ids)  # neither call should raise


@given(st.lists(st.integers(min_value=0, max_value=10_000), max_size=50))
@FAST
def test_tokenizer_decode_never_crashes_on_arbitrary_ids(trained_tokenizer, ids):
    """decode() may legitimately be handed IDs beyond the trained
    vocabulary (e.g. a corrupted request) -- it must not crash, even if it
    can't produce meaningful text for them."""
    try:
        trained_tokenizer.decode(ids)
    except (KeyError, IndexError):
        pytest.fail("decode() crashed on an out-of-vocabulary id instead of handling it")


# --- Calculator: never executes anything unsafe, never crashes ---

@given(st.text(max_size=100))
@FAST
def test_calculate_never_raises_on_arbitrary_text(text):
    result = calculate(text)
    assert isinstance(result, dict)
    assert "ok" in result


@given(st.text(alphabet="0123456789+-*/(). ", max_size=60))
@FAST
def test_calculate_arithmetic_shaped_strings_never_raise(expr):
    result = calculate(expr)
    assert isinstance(result, dict)
    if result["ok"]:
        assert isinstance(result["result"], (int, float))


@given(st.text(alphabet="abcdefghijklmnopqrstuvwxyz_(). \"'0123456789", max_size=80))
@FAST
def test_calculate_never_executes_arbitrary_function_calls(expr):
    """Fuzz malformed/unusual function-call-shaped expressions -- the
    allowlist in calculator.py must reject anything not in _FUNCS
    regardless of how the call is spelled, never partially execute it."""
    result = calculate(expr)
    assert isinstance(result, dict)
    # if it succeeded, the only way that's possible is via the restricted
    # AST evaluator's allowlisted functions/operators -- there is no path
    # to arbitrary code execution to check for a crash-with-side-effect on


# --- Document chunker: never crashes on arbitrary text ---

@given(st.text(max_size=2000))
@FAST
def test_chunk_text_never_crashes(text):
    chunks = chunk_text(text)
    assert isinstance(chunks, list)
    assert all(isinstance(c, str) for c in chunks)


@given(st.text(max_size=2000))
@FAST
def test_split_sentences_never_crashes_and_returns_nonempty_strings(text):
    sentences = split_sentences(text)
    assert isinstance(sentences, list)
    assert all(s.strip() for s in sentences)  # no blank/whitespace-only "sentences"


@given(st.text(min_size=1, max_size=3000), st.integers(min_value=50, max_value=1000))
@FAST
def test_chunk_text_chunk_size_bounds_are_respected_approximately(text, chunk_size):
    chunks = chunk_text(text, chunk_size=chunk_size, overlap=min(30, chunk_size // 2))
    for c in chunks:
        # generous slack: chunking breaks on sentence boundaries, so a
        # single very long sentence can legitimately exceed chunk_size --
        # the real invariant is "doesn't runaway grow unboundedly", not an
        # exact cap
        assert len(c) < chunk_size * 20 + 500


# --- Sampling: always returns a valid vocabulary index ---

@given(
    st.lists(st.floats(min_value=-100, max_value=100, allow_nan=False, allow_infinity=False),
              min_size=2, max_size=200),
    st.floats(min_value=0.05, max_value=3.0),
    st.floats(min_value=0.1, max_value=1.0),
)
@FAST
def test_sample_next_token_always_returns_valid_index(logits_list, temperature, top_p):
    logits = np.array(logits_list)
    rng = np.random.default_rng(0)
    idx = sample_next_token(logits, [], temperature=temperature, top_p=top_p, top_k=0,
                             repetition_penalty=1.0, rng=rng)
    assert 0 <= idx < len(logits)


@given(st.lists(st.floats(min_value=-50, max_value=50, allow_nan=False, allow_infinity=False),
                 min_size=2, max_size=100))
@FAST
def test_sample_next_token_valid_with_recent_ids_and_repetition_penalty(logits_list):
    logits = np.array(logits_list)
    rng = np.random.default_rng(0)
    recent = list(range(min(5, len(logits))))
    idx = sample_next_token(logits, recent, temperature=0.8, top_p=0.9, top_k=2,
                             repetition_penalty=1.3, rng=rng)
    assert 0 <= idx < len(logits)


# --- Same crash class found in other modules during this sweep ---

def test_stable_seed_does_not_crash_on_lone_surrogate():
    """Same UnicodeEncodeError class as the tokenizer bug above, found by
    sweeping the whole project for the same unsafe `.encode("utf-8")`
    pattern (no errors= argument) once one instance was found. This one is
    directly on the user-input path: FinanceAgent and MainChatAgent both
    seed their RNG from the raw request text via stable_seed()."""
    from agents import stable_seed
    stable_seed("\ud83d\ude00")  # must not raise


def test_hash_embed_does_not_crash_on_lone_surrogate():
    """Same bug class -- hash_embed() is used for every memory add/query
    and every document upload/search, all directly on user-controlled text."""
    from memory_store import hash_embed
    hash_embed("\ud83d\ude00")  # must not raise


def test_byte_tokenizer_does_not_crash_on_lone_surrogate():
    """Same bug class -- ByteTokenizer is the fallback tokenizer used
    whenever no trained BPE tokenizer/checkpoint is available, directly on
    the chat request path."""
    from tokenizer import ByteTokenizer
    ByteTokenizer().encode("\ud83d\ude00")  # must not raise


@given(st.text(alphabet=st.characters(min_codepoint=0xD800, max_codepoint=0xDFFF), max_size=20))
@FAST
def test_hash_embed_never_crashes_on_surrogate_range(text):
    from memory_store import hash_embed
    hash_embed(text)
