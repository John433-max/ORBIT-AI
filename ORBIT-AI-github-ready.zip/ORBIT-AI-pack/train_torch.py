"""
PyTorch-backed version of train_large.py. Same pipeline (tokenizer trained
on a representative sample, full corpus encoded and trained on), same
corpus (dataset.py's build_corpus(include_external=True)), same checkpoint
metadata shape -- the only thing that changes is the model backend, which
is where the actual bottleneck was. Measured directly in this project's own
dev environment: ~117ms/step on this backend vs ~1.57s/step on the NumPy
autograd engine at a comparable model size (d_model=128, 4 layers, seq_len
64, batch 16) -- roughly a 13x speedup, entirely from using a real
optimized tensor library instead of pure-Python nested loops, with no GPU
involved (this sandbox has none; torch.cuda.is_available() is False here).

See model_torch.py's docstring for why this exists alongside, not instead
of, the NumPy path, and for this file's own verification-status notes.

Usage:
    python train_torch.py                                  # defaults below
    python train_torch.py --train-chars 40000000 --steps 3000   # use much more of the corpus
"""
import argparse
import time

import torch
import torch.nn.functional as F

from dataset import build_corpus
from bpe_tokenizer import BPETokenizer
from model_torch import TinyLMTorch, save_checkpoint_torch
from train import full_checkpoint_metadata  # reused as-is: reads model.d_model/.n_heads/etc,
# which TinyLMTorch also exposes as plain attributes, so this works unmodified on either backend.


def make_batches_torch(ids: torch.Tensor, seq_len: int, batch_size: int, generator: torch.Generator):
    n = len(ids) - seq_len - 1
    if n <= 0:
        raise ValueError("corpus too short for this seq_len")
    while True:
        starts = torch.randint(0, n, (batch_size,), generator=generator)
        x = torch.stack([ids[s: s + seq_len] for s in starts])
        y = torch.stack([ids[s + 1: s + seq_len + 1] for s in starts])
        yield x, y


@torch.no_grad()
def eval_perplexity_torch(model, ids: torch.Tensor, seq_len: int, n_windows: int = 8):
    n = min(n_windows, max(1, (len(ids) - 1) // seq_len))
    losses = []
    model.eval()
    for i in range(n):
        s = i * seq_len
        x = ids[s: s + seq_len][None, :]
        y = ids[s + 1: s + seq_len + 1][None, :]
        logits = model(x)
        losses.append(F.cross_entropy(logits, y.reshape(-1)).item())
    model.train()
    avg_loss = sum(losses) / len(losses)
    import math
    return avg_loss, math.exp(min(avg_loss, 20))


def run(train_chars=8_000_000, val_chars=1_000_000, tokenizer_sample_chars=3_000_000,
        tokenizer_vocab_size=3000, d_model=128, n_layers=4, n_heads=8, n_kv_heads=4,
        seq_len=64, batch_size=16, steps=800, lr=3e-3, warmup_steps=50,
        gradient_clip=1.0, seed=0, log_every=50):
    t_start = time.time()
    torch.manual_seed(seed)

    print("[1/4] Building corpus (include_external=True)...")
    train_text, val_text, report = build_corpus(include_external=True, seed=seed)
    print(f"  {report['n_train_docs']} train docs, {report['n_val_docs']} val docs, "
          f"{report['train_bytes']/1e6:.1f}MB train / {report['val_bytes']/1e6:.1f}MB val")

    train_text = train_text[:train_chars]
    val_text = val_text[:val_chars]
    print(f"  using {len(train_text)/1e6:.1f}M train chars, {len(val_text)/1e6:.1f}M val chars this run")

    print(f"[2/4] Training tokenizer on a {tokenizer_sample_chars/1e6:.1f}M-char sample "
          f"(vocab_size={tokenizer_vocab_size})...")
    t0 = time.time()
    tokenizer = BPETokenizer().train(train_text[:tokenizer_sample_chars], vocab_size=tokenizer_vocab_size,
                                      min_frequency=2)
    tokenizer.save("bpe_tokenizer_torch.json")
    print(f"  trained in {time.time()-t0:.1f}s, vocab={tokenizer.VOCAB_SIZE}")

    print("[3/4] Encoding train/val text...")
    t0 = time.time()
    train_chars_used = len(train_text)
    train_ids = torch.tensor(tokenizer.encode(train_text, add_bos=False, add_eos=False), dtype=torch.long)
    val_ids = torch.tensor(tokenizer.encode(val_text, add_bos=False, add_eos=False), dtype=torch.long)
    print(f"  encoded in {time.time()-t0:.1f}s -> {len(train_ids)/1e6:.2f}M train tokens, "
          f"{len(val_ids)/1e3:.1f}K val tokens")
    del train_text, val_text

    print(f"[4/4] Training model (d_model={d_model}, n_layers={n_layers}, "
          f"n_heads={n_heads}, n_kv_heads={n_kv_heads}, seq_len={seq_len}) for {steps} steps...")
    model = TinyLMTorch(vocab_size=tokenizer.VOCAB_SIZE, d_model=d_model, n_layers=n_layers,
                         n_heads=n_heads, n_kv_heads=n_kv_heads, max_seq_len=seq_len, seed=seed)
    print(f"  {model.param_count():,} parameters")
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    gen = torch.Generator().manual_seed(seed)
    batches = make_batches_torch(train_ids, seq_len, batch_size, gen)

    def lr_at_step(step):
        if warmup_steps > 0 and step < warmup_steps:
            return lr * step / max(1, warmup_steps)
        progress = min(1.0, max(0.0, (step - warmup_steps) / max(1, steps - warmup_steps)))
        cosine = 0.5 * (1 + torch.cos(torch.tensor(3.14159265 * progress)).item())
        return lr * (0.1 + 0.9 * cosine)

    best_val_loss = float("inf")
    best_state = None
    t0 = time.time()
    for step in range(1, steps + 1):
        x, y = next(batches)
        opt.zero_grad()
        logits = model(x)
        loss = F.cross_entropy(logits, y.reshape(-1))
        loss.backward()
        step_lr = lr_at_step(step)
        for g in opt.param_groups:
            g["lr"] = step_lr
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip)
        opt.step()
        if step % log_every == 0 or step == 1 or step == steps:
            val_loss, val_ppl = eval_perplexity_torch(model, val_ids, seq_len)
            print(f"  step {step:4d}/{steps}  train_loss {loss.item():.4f}  "
                  f"val_loss {val_loss:.4f}  val_ppl {val_ppl:.2f}  lr {step_lr:.2e}  "
                  f"grad_norm {float(grad_norm):.2f}  ({time.time()-t0:.0f}s elapsed)")
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = {k: v.clone() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)
    final_val_loss, final_val_ppl = eval_perplexity_torch(model, val_ids, seq_len)
    save_checkpoint_torch(model, "checkpoint_torch.pt", metadata=full_checkpoint_metadata(
        model, config="torch_large_corpus", val_loss=final_val_loss, val_ppl=final_val_ppl, seed=seed,
        train_chars_used=train_chars_used, train_tokens_used=len(train_ids), backend="pytorch"))
    print(f"\nDone in {time.time()-t_start:.0f}s total. "
          f"Final val_loss={final_val_loss:.4f}, val_ppl={final_val_ppl:.2f}")
    print("Saved checkpoint_torch.pt + checkpoint_torch.json, bpe_tokenizer_torch.json")
    return model, tokenizer, final_val_loss, final_val_ppl


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--train-chars", type=int, default=8_000_000)
    p.add_argument("--val-chars", type=int, default=1_000_000)
    p.add_argument("--tokenizer-sample-chars", type=int, default=3_000_000)
    p.add_argument("--tokenizer-vocab-size", type=int, default=3000)
    p.add_argument("--steps", type=int, default=800)
    p.add_argument("--seq-len", type=int, default=64)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--n-layers", type=int, default=4)
    p.add_argument("--n-heads", type=int, default=8)
    p.add_argument("--n-kv-heads", type=int, default=4)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()
    run(train_chars=args.train_chars, val_chars=args.val_chars,
        tokenizer_sample_chars=args.tokenizer_sample_chars,
        tokenizer_vocab_size=args.tokenizer_vocab_size, steps=args.steps,
        seq_len=args.seq_len, batch_size=args.batch_size, d_model=args.d_model,
        n_layers=args.n_layers, n_heads=args.n_heads, n_kv_heads=args.n_kv_heads, seed=args.seed)
