"""Measure real generation throughput on this machine (no fabricated numbers)."""

from __future__ import annotations

import argparse
import time


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--prompt", default="the quick brown fox")
    p.add_argument("--max-tokens", type=int, default=32)
    p.add_argument("--preset", default="development")
    p.add_argument("--runs", type=int, default=3)
    args = p.parse_args(argv)

    import sys
    from pathlib import Path as _P
    sys.path.insert(0, str(_P(__file__).resolve().parents[1]))
    from generate import _load_model_and_tokenizer
    from sampling import sample_next_token
    import numpy as np
    from monitoring.metrics import record_generation

    model, tok, ckpt, meta = _load_model_and_tokenizer(None, None, args.preset)
    max_seq = getattr(model, "max_seq_len", 64)
    speeds = []
    for run in range(args.runs):
        ids = tok.encode(args.prompt, add_bos=False, add_eos=False)
        prompt_len = len(ids)
        rng = np.random.default_rng(run)
        t0 = time.perf_counter()
        for _ in range(args.max_tokens):
            window = ids[-max_seq:]
            x = np.array(window)[None, :]
            logits = model(x)
            data = logits.data if hasattr(logits, "data") else logits
            row = data[-1] if data.ndim == 2 else data[0, -1]
            nxt = sample_next_token(row, recent_ids=ids[-16:], temperature=0.8, top_p=0.9, rng=rng)
            ids.append(int(nxt))
        elapsed = time.perf_counter() - t0
        n_new = len(ids) - prompt_len
        stats = record_generation(
            n_tokens=n_new,
            elapsed_s=elapsed,
            model_params=model.param_count(),
            checkpoint=ckpt,
            prompt_len=prompt_len,
        )
        speeds.append(stats["tokens_per_sec"])
        print(f"run {run+1}: {stats['tokens_per_sec']} tok/s")
    print(f"mean: {sum(speeds)/len(speeds):.2f} tok/s  params={model.param_count():,}  ckpt={ckpt}")


if __name__ == "__main__":
    main()
