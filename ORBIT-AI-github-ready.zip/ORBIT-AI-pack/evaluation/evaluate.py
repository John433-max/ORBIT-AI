"""
Evaluation helpers — validation loss, perplexity, generation speed.
Never invents results; only reports what is measured.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np


REPEATABLE_PROMPTS = {
    "general": [
        "The history of computing begins with",
        "Once upon a time in a small village",
    ],
    "code": [
        "def fibonacci(n):",
        "public class HelloWorld {",
    ],
    "reasoning": [
        "If all bloops are razzies and all razzies are lazzies, then",
        "Step by step, the solution to 17 * 19 is",
    ],
    "instruction": [
        "Write a short summary of photosynthesis.",
        "List three benefits of unit testing.",
    ],
}


def evaluate_checkpoint(
    model,
    tokenizer,
    val_ids: Optional[np.ndarray] = None,
    seq_len: int = 32,
    n_windows: int = 8,
    gen_prompt: str = "The",
    max_new_tokens: int = 32,
) -> Dict[str, Any]:
    """Measure val loss/ppl (if ids given) and generation throughput."""
    from monitoring import SystemMonitor

    report: Dict[str, Any] = {
        "n_params": model.param_count() if hasattr(model, "param_count") else None,
        "seq_len": seq_len,
    }
    mon = SystemMonitor()
    snap0 = mon.snapshot()

    if val_ids is not None and len(val_ids) > seq_len + 1:
        try:
            from training.trainer import eval_loss
            val_loss, val_ppl = eval_loss(model, val_ids, seq_len, n_windows=n_windows)
            report["val_loss"] = val_loss
            report["val_ppl"] = val_ppl
        except Exception as e:
            report["val_error"] = str(e)

    # Generation speed
    try:
        from sampling import sample_next_token

        ids = tokenizer.encode(gen_prompt, add_bos=False, add_eos=False)
        rng = np.random.default_rng(0)
        t0 = time.perf_counter()
        for _ in range(max_new_tokens):
            window = ids[-getattr(model, "max_seq_len", seq_len) :]
            logits = model(np.array([window]))
            data = logits.data if hasattr(logits, "data") else logits
            row = data[0, -1] if data.ndim == 3 else data[-1]
            nxt = sample_next_token(row, ids, temperature=0.8, rng=rng)
            ids.append(int(nxt))
        elapsed = time.perf_counter() - t0
        report["generation"] = {
            "prompt": gen_prompt,
            "new_tokens": max_new_tokens,
            "elapsed_s": elapsed,
            "tokens_per_sec": max_new_tokens / max(elapsed, 1e-6),
            "sample": tokenizer.decode(ids)[:200],
        }
    except Exception as e:
        report["generation_error"] = str(e)

    snap1 = mon.snapshot()
    report["memory"] = {
        "rss_mb_before": snap0.rss_mb,
        "rss_mb_after": snap1.rss_mb,
    }
    return report


def run_prompts(
    model,
    tokenizer,
    categories: Optional[List[str]] = None,
    max_new_tokens: int = 40,
    temperature: float = 0.8,
) -> Dict[str, List[Dict[str, str]]]:
    """Generate on repeatable prompts; store actual outputs only."""
    from sampling import sample_next_token

    cats = categories or list(REPEATABLE_PROMPTS.keys())
    out: Dict[str, List[Dict[str, str]]] = {}
    rng = np.random.default_rng(0)
    for cat in cats:
        out[cat] = []
        for prompt in REPEATABLE_PROMPTS.get(cat, []):
            ids = tokenizer.encode(prompt, add_bos=False, add_eos=False)
            for _ in range(max_new_tokens):
                window = ids[-getattr(model, "max_seq_len", 64) :]
                logits = model(np.array([window]))
                data = logits.data if hasattr(logits, "data") else logits
                row = data[0, -1] if data.ndim == 3 else data[-1]
                nxt = sample_next_token(row, ids, temperature=temperature, rng=rng)
                ids.append(int(nxt))
            text = tokenizer.decode(ids)
            out[cat].append({"prompt": prompt, "completion": text})
    return out


def save_report(report: Dict[str, Any], path: str = "evaluation/reports/last_eval.json") -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    return str(p)
