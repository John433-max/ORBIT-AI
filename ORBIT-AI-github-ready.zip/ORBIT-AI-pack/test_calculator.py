"""Tests for calculator.py — correctness and, critically, that it's not
eval-based (no arbitrary code execution reachable through it)."""
import pytest

from calculator import calculate, parse_and_calculate, looks_like_math, calculate_percentage_of


@pytest.mark.parametrize("expr,expected", [
    ("2 + 3", 5), ("10 - 4", 6), ("6 * 7", 42), ("10 / 4", 2.5),
    ("2 ** 10", 1024), ("17 % 5", 2), ("-5 + 3", -2), ("(2 + 3) * 4", 20),
])
def test_basic_arithmetic(expr, expected):
    r = calculate(expr)
    assert r["ok"] is True
    assert r["result"] == expected


def test_sqrt():
    assert calculate("sqrt(16)")["result"] == 4.0


def test_stats_functions():
    assert calculate("mean([2, 4, 6])")["result"] == 4
    assert calculate("median([1, 3, 2])")["result"] == 2
    assert calculate("max([1, 5, 3])")["result"] == 5
    assert calculate("min([1, 5, 3])")["result"] == 1


def test_division_by_zero_handled():
    r = calculate("1 / 0")
    assert r["ok"] is False
    assert "zero" in r["error"]


def test_empty_expression():
    r = calculate("")
    assert r["ok"] is False


def test_too_long_expression_rejected():
    r = calculate("1+" * 1000 + "1")
    assert r["ok"] is False


def test_syntax_error_handled_gracefully():
    r = calculate("2 +* 3")
    assert r["ok"] is False


@pytest.mark.parametrize("malicious", [
    "__import__('os').system('ls')",
    "eval('1+1')",
    "exec('import os')",
    "open('/etc/passwd').read()",
    "().__class__.__bases__[0]",
])
def test_calculator_blocks_non_arithmetic_calls(malicious):
    r = calculate(malicious)
    assert r["ok"] is False  # rejected as unsupported, never executed


def test_percentage_of():
    assert calculate_percentage_of(20, 150) == 30.0


def test_parse_and_calculate_percentage_phrasing():
    r = parse_and_calculate("what is 20% of 150")
    assert r["ok"] is True
    assert r["result"] == 30.0


def test_parse_and_calculate_plain_expression():
    r = parse_and_calculate("please compute 12 * 7 for me")
    assert r["ok"] is True
    assert r["result"] == 84


def test_parse_and_calculate_no_numbers():
    r = parse_and_calculate("hello there, how are you")
    assert r["ok"] is False


def test_looks_like_math_positive_cases():
    assert looks_like_math("what is 2 + 2")
    assert looks_like_math("calculate the average of these numbers")
    assert looks_like_math("what is 15 percent of 80")


def test_looks_like_math_negative_case():
    assert not looks_like_math("tell me about the history of Rome")
