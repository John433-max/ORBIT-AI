"""Tests for debugging.py — rule-based traceback/error diagnosis (Phase 15)."""
import pytest

from debugging import diagnose_traceback


@pytest.mark.parametrize("error_name,sample", [
    ("ModuleNotFoundError", "ModuleNotFoundError: No module named 'numpy'"),
    ("ImportError", "ImportError: cannot import name 'foo' from 'bar'"),
    ("SyntaxError", "SyntaxError: invalid syntax"),
    ("IndentationError", "IndentationError: unexpected indent"),
    ("NameError", "NameError: name 'x' is not defined"),
    ("TypeError", "TypeError: unsupported operand type(s)"),
    ("ValueError", "ValueError: invalid literal for int()"),
    ("KeyError", "KeyError: 'missing_key'"),
    ("IndexError", "IndexError: list index out of range"),
    ("AttributeError", "AttributeError: 'NoneType' object has no attribute 'foo'"),
    ("ZeroDivisionError", "ZeroDivisionError: division by zero"),
    ("FileNotFoundError", "FileNotFoundError: [Errno 2] No such file or directory"),
    ("RecursionError", "RecursionError: maximum recursion depth exceeded"),
])
def test_recognizes_known_python_errors(error_name, sample):
    result = diagnose_traceback(sample)
    assert result["error_type"] == error_name
    assert result["explanation"]
    assert result["likely_causes"]
    assert result["suggestions"]
    assert result["category"] == "python"


def test_recognizes_full_traceback_not_just_bare_error_line():
    tb = (
        "Traceback (most recent call last):\n"
        '  File "app.py", line 3, in <module>\n'
        "    import requests\n"
        "ModuleNotFoundError: No module named 'requests'"
    )
    result = diagnose_traceback(tb)
    assert result["error_type"] == "ModuleNotFoundError"


@pytest.mark.parametrize("sample,expected_label", [
    ("Got a 401 Unauthorized response from the API", "HTTP 401 Unauthorized"),
    ("Request failed with 403 Forbidden", "HTTP 403 Forbidden"),
    ("Server responded 404 Not Found", "HTTP 404 Not Found"),
    ("Hit rate limit: 429 Too Many Requests", "HTTP 429 Rate Limited"),
    ("500 Internal Server Error from upstream", "HTTP 500 Internal Server Error"),
])
def test_recognizes_api_error_patterns(sample, expected_label):
    result = diagnose_traceback(sample)
    assert result["error_type"] == expected_label
    assert result["category"] == "api"


def test_unrecognized_text_returns_none_honestly():
    result = diagnose_traceback("everything worked fine, no errors here")
    assert result["error_type"] is None
    assert result["explanation"] is None
    assert result["likely_causes"] == []
    assert result["suggestions"] == []


def test_every_known_error_has_nonempty_fields():
    from debugging import _KNOWN_ERRORS
    for name, (explanation, causes, suggestions) in _KNOWN_ERRORS.items():
        assert explanation and len(explanation) > 10
        assert len(causes) >= 1
        assert len(suggestions) >= 1
