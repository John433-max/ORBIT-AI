"""
Regression tests for train.py's checkpoint loading. Covers a real bug: an
earlier api.py hardcoded one model architecture while a differently-shaped
checkpoint (from train_large.py) sat in the same directory -- nothing
enforced they matched, so loading would either crash confusingly deep
inside inference or silently produce a corrupted model.
"""
import numpy as np
import pytest

from model import TinyLM
from train import (
    save_checkpoint, load_into, build_model_from_checkpoint, full_checkpoint_metadata,
)


@pytest.fixture
def small_checkpoint(tmp_path):
    model = TinyLM(vocab_size=50, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    path = str(tmp_path / "small.npz")
    save_checkpoint(model, path, metadata=full_checkpoint_metadata(
        model, config="test_small", val_loss=1.23, val_ppl=4.56, seed=0))
    return model, path


@pytest.fixture
def large_checkpoint(tmp_path):
    model = TinyLM(vocab_size=80, d_model=32, n_layers=3, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=1)
    path = str(tmp_path / "large.npz")
    save_checkpoint(model, path, metadata=full_checkpoint_metadata(
        model, config="test_large", val_loss=2.34, val_ppl=6.78, seed=1))
    return model, path


def test_load_into_matching_architecture_succeeds(small_checkpoint):
    original_model, path = small_checkpoint
    fresh_model = TinyLM(vocab_size=50, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=99)
    load_into(fresh_model, path)
    for p1, p2 in zip(original_model.params(), fresh_model.params()):
        assert np.allclose(p1.data, p2.data)


def test_load_into_rejects_mismatched_architecture(large_checkpoint):
    """The exact bug: loading a checkpoint into a model built with the
    wrong dimensions must fail loudly, not silently write wrong-shaped
    data into the model's parameters."""
    _, large_path = large_checkpoint
    wrong_model = TinyLM(vocab_size=50, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    with pytest.raises(ValueError, match="parameter tensors|shape"):
        load_into(wrong_model, large_path)


def test_load_into_rejects_mismatched_param_shape_same_count(tmp_path):
    """Different architectures can coincidentally have the same number of
    parameter tensors but different shapes (e.g. different d_model with the
    same n_layers) -- this must still be caught, not just a tensor-count check."""
    model_a = TinyLM(vocab_size=50, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    model_b = TinyLM(vocab_size=50, d_model=32, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    assert len(model_a.params()) == len(model_b.params())  # same count, different shapes

    path = str(tmp_path / "a.npz")
    save_checkpoint(model_a, path)
    with pytest.raises(ValueError, match="shape"):
        load_into(model_b, path)


def test_build_model_from_checkpoint_reconstructs_correct_architecture(large_checkpoint):
    original_model, path = large_checkpoint
    rebuilt_model, meta = build_model_from_checkpoint(path)
    assert rebuilt_model.d_model == original_model.d_model == 32
    assert len(rebuilt_model.blocks) == 3
    assert rebuilt_model.n_heads == 4
    assert rebuilt_model.vocab_size == 80
    for p1, p2 in zip(original_model.params(), rebuilt_model.params()):
        assert np.allclose(p1.data, p2.data)


def test_build_model_from_checkpoint_missing_npz_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        build_model_from_checkpoint(str(tmp_path / "does_not_exist.npz"))


def test_build_model_from_checkpoint_missing_metadata_fields_raises(tmp_path):
    import json
    model = TinyLM(vocab_size=20, d_model=8, n_layers=1, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    npz_path = str(tmp_path / "incomplete.npz")
    save_checkpoint(model, npz_path, metadata={"config": "incomplete"})  # missing d_model etc.
    with pytest.raises(ValueError, match="missing required fields"):
        build_model_from_checkpoint(npz_path)


def test_full_checkpoint_metadata_matches_model_attributes():
    model = TinyLM(vocab_size=64, d_model=32, n_layers=3, n_heads=4, n_kv_heads=2, max_seq_len=16,
                    use_recursive_reasoning=True, seed=0)
    meta = full_checkpoint_metadata(model, config="test", val_loss=0.5, val_ppl=1.5, seed=0)
    assert meta["d_model"] == 32
    assert meta["n_layers"] == 3
    assert meta["n_heads"] == 4
    assert meta["n_kv_heads"] == 2
    assert meta["vocab_size"] == 64
    assert meta["seq_len"] == 16
    assert meta["recursive"] is True
    assert meta["val_loss"] == 0.5


def test_two_different_checkpoints_both_loadable_by_metadata(small_checkpoint, large_checkpoint):
    """Simulates the exact scenario reported: two checkpoints from
    different training runs sitting side by side. Each must load into its
    own correct architecture via metadata, with no cross-contamination."""
    small_model, small_path = small_checkpoint
    large_model, large_path = large_checkpoint

    rebuilt_small, _ = build_model_from_checkpoint(small_path)
    rebuilt_large, _ = build_model_from_checkpoint(large_path)

    assert rebuilt_small.d_model == 16
    assert rebuilt_large.d_model == 32
    assert rebuilt_small.vocab_size == 50
    assert rebuilt_large.vocab_size == 80
