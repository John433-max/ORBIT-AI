"""
Large-corpus training entry point (opt-in, separate from train.py's default
fast path so nothing about the existing quick-iteration workflow changes).

Real, honest scope of this script -- see dataset.py's load_external_documents()
docstring for the full explanation, summarized here:
  - Source: 79 complete public-domain books (~56MB) from github.com/GITenberg,
    Gutenberg boilerplate stripped. Real literary text, not placeholders.
  - The BPE tokenizer is TRAINED on a representative sample (a few million
    characters -- standard practice; you don't need the whole corpus to
    learn good subword statistics), then used to ENCODE as much of the full
    corpus as the configured `train_chars`/`val_chars` budget allows.
  - Both tokenizer training and encoding are pure-Python and O(merges) per
    unique word; even after the optimizations added in this pass (frequency
    collapsing on the train side, per-word caching on the encode side),
    processing the full 56MB in one run takes on the order of tens of
    minutes. This script processes a configurable prefix by default (see
    `train_chars`) rather than assuming unlimited wall-clock time --
    increase the limits and let it run longer for a more complete pass over
    the corpus.

Usage:
    python train_large.py                      # uses the defaults below
    python train_large.py --train-chars 40000000 --steps 2000   # more of the corpus, longer run
"""
import argparse
import time
import gc
import numpy as np

from dataset import build_corpus
from bpe_tokenizer import BPETokenizer
from model import TinyLM
from autograd import cross_entropy
from train import Adam, lr_at_step, clip_grad_norm, save_checkpoint, eval_perplexity, make_batches, \
    full_checkpoint_metadata


def run(train_chars=8_000_000, val_chars=1_000_000, tokenizer_sample_chars=3_000_000,
        tokenizer_vocab_size=3000, d_model=128, n_layers=4, n_heads=8, n_kv_heads=4,
        seq_len=64, batch_size=16, steps=800, lr=3e-3, warmup_steps=50,
        gradient_clip=1.0, seed=0, log_every=50):
    t_start = time.time()

    print("[1/4] Building corpus (include_external=True)...")
    train_text, val_text, report = build_corpus(include_external=True, seed=seed)
    print(f"  {report['n_train_docs']} train docs, {report['n_val_docs']} val docs, "
          f"{report['train_bytes']/1e6:.1f}MB train / {report['val_bytes']/1e6:.1f}MB val, "
          f"contamination={report['contamination_overlap_8gram_count']}")

    train_text = train_text[:train_chars]
    val_text = val_text[:val_chars]
    print(f"  using {len(train_text)/1e6:.1f}M train chars, {len(val_text)/1e6:.1f}M val chars this run")

    print(f"[2/4] Training tokenizer on a {tokenizer_sample_chars/1e6:.1f}M-char sample "
          f"(vocab_size={tokenizer_vocab_size})...")
    t0 = time.time()
    tokenizer_sample = train_text[:tokenizer_sample_chars]
    tokenizer = BPETokenizer().train(tokenizer_sample, vocab_size=tokenizer_vocab_size, min_frequency=2)
    tokenizer.save("bpe_tokenizer_large.json")
    print(f"  trained in {time.time()-t0:.1f}s, vocab={tokenizer.VOCAB_SIZE}")

    print("[3/4] Encoding train/val text...")
    t0 = time.time()
    train_chars_used = len(train_text)
    train_ids = np.array(tokenizer.encode(train_text, add_bos=False, add_eos=False), dtype=np.int32)
    val_ids = np.array(tokenizer.encode(val_text, add_bos=False, add_eos=False), dtype=np.int32)
    print(f"  encoded in {time.time()-t0:.1f}s -> {len(train_ids)/1e6:.2f}M train tokens, "
          f"{len(val_ids)/1e3:.1f}K val tokens")
    # free the raw text and intermediate structures before training starts --
    # at multi-MB corpus scale, holding both the raw strings and the token
    # arrays simultaneously roughly doubles peak memory for no reason once
    # encoding is done.
    del train_text, val_text, tokenizer_sample
    gc.collect()

    print(f"[4/4] Training model (d_model={d_model}, n_layers={n_layers}, "
          f"n_heads={n_heads}, n_kv_heads={n_kv_heads}, seq_len={seq_len}) for {steps} steps...")
    rng = np.random.default_rng(seed)
    model = TinyLM(vocab_size=tokenizer.VOCAB_SIZE, d_model=d_model, n_layers=n_layers,
                    n_heads=n_heads, n_kv_heads=n_kv_heads, max_seq_len=seq_len, seed=seed)
    print(f"  {model.param_count():,} parameters")
    opt = Adam(model.params(), lr=lr)
    batches = make_batches(train_ids, seq_len, batch_size, rng)

    best_val_loss = float("inf")
    best_state = None
    t0 = time.time()
    for step in range(1, steps + 1):
        x, y = next(batches)
        opt.zero_grad()
        logits = model(x)
        loss = cross_entropy(logits, y.reshape(-1))
        loss.backward()
        step_lr = lr_at_step(step, lr, warmup_steps, steps)
        grad_norm = clip_grad_norm(model.params(), gradient_clip)
        opt.step(lr=step_lr)
        if step % 200 == 0:
            gc.collect()  # defensive; see train.py's identical comment for why
        if step % log_every == 0 or step == 1 or step == steps:
            val_loss, val_ppl = eval_perplexity(model, val_ids, seq_len)
            print(f"  step {step:4d}/{steps}  train_loss {float(loss.data):.4f}  "
                  f"val_loss {val_loss:.4f}  val_ppl {val_ppl:.2f}  lr {step_lr:.2e}  "
                  f"grad_norm {grad_norm:.2f}  ({time.time()-t0:.0f}s elapsed)")
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = [p.data.copy() for p in model.params()]

    if best_state is not None:
        for p, saved in zip(model.params(), best_state):
            p.data = saved
    final_val_loss, final_val_ppl = eval_perplexity(model, val_ids, seq_len)
    save_checkpoint(model, "checkpoint_large.npz", metadata=full_checkpoint_metadata(
        model, config="large_corpus", val_loss=final_val_loss, val_ppl=final_val_ppl, seed=seed,
        train_chars_used=train_chars_used, train_tokens_used=len(train_ids)))
    print(f"\nDone in {time.time()-t_start:.0f}s total. "
          f"Final val_loss={final_val_loss:.4f}, val_ppl={final_val_ppl:.2f}")
    print("Saved checkpoint_large.npz + checkpoint_large.json, bpe_tokenizer_large.json")
    return model, tokenizer, final_val_loss, final_val_ppl


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--train-chars", type=int, default=8_000_000)
    p.add_argument("--val-chars", type=int, default=1_000_000)
    p.add_argument("--tokenizer-sample-chars", type=int, default=3_000_000)
    p.add_argument("--tokenizer-vocab-size", type=int, default=3000)
    p.add_argument("--steps", type=int, default=800)
    p.add_argument("--seq-len", type=int, default=64)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--n-layers", type=int, default=4)
    p.add_argument("--n-heads", type=int, default=8)
    p.add_argument("--n-kv-heads", type=int, default=4)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()
    run(train_chars=args.train_chars, val_chars=args.val_chars,
        tokenizer_sample_chars=args.tokenizer_sample_chars,
        tokenizer_vocab_size=args.tokenizer_vocab_size, steps=args.steps,
        seq_len=args.seq_len, batch_size=args.batch_size, d_model=args.d_model,
        n_layers=args.n_layers, n_heads=args.n_heads, n_kv_heads=args.n_kv_heads, seed=args.seed)
