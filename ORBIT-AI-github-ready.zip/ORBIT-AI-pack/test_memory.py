"""Tests for memory_store.py — both the in-memory VectorStore and the
persistent SQLiteVectorStore, since Phase 10 requires them to share the same
interface and behavior."""
import os
import time
import pytest

from memory_store import VectorStore, SQLiteVectorStore, hash_embed


@pytest.fixture(params=["memory", "sqlite"])
def store(request, tmp_path):
    if request.param == "memory":
        s = VectorStore()
        yield s
    else:
        db_path = str(tmp_path / "test.db")
        s = SQLiteVectorStore(db_path)
        yield s
        s.close()


def test_add_and_query(store):
    store.add("the user likes hiking on weekends")
    store.add("the weather today is sunny")
    hits = store.query("hiking", k=1)
    assert len(hits) == 1
    assert "hiking" in hits[0]["text"]


def test_delete(store):
    item_id = store.add("temporary fact")
    assert store.delete(item_id) is True
    assert store.delete(item_id) is False  # already gone
    assert store.query("temporary", k=5) == []


def test_ttl_expiry(store):
    store.add("short-lived note", ttl_seconds=0.15, dedupe=False)
    assert len(store.query("short-lived", k=5)) == 1
    time.sleep(0.25)
    assert len(store.query("short-lived", k=5)) == 0


def test_duplicate_detection_reuses_id(store):
    id1 = store.add("the user's favorite color is blue")
    id2 = store.add("the user's favorite color is blue")  # identical text
    assert id1 == id2
    assert len(store.list()) == 1


def test_duplicate_detection_bumps_importance(store):
    id1 = store.add("the user's favorite color is blue", importance=0.5)
    store.add("the user's favorite color is blue")
    item = [i for i in store.list() if i["id"] == id1][0]
    assert item["importance"] > 0.5


def test_distinct_text_not_deduped(store):
    id1 = store.add("fact about hiking")
    id2 = store.add("completely unrelated fact about cooking pasta")
    assert id1 != id2
    assert len(store.list()) == 2


def test_dedupe_can_be_disabled(store):
    id1 = store.add("repeat me", dedupe=False)
    id2 = store.add("repeat me", dedupe=False)
    assert id1 != id2
    assert len(store.list()) == 2


def test_query_empty_store_returns_empty(store):
    assert store.query("anything", k=3) == []


def test_hash_embed_is_deterministic_and_normalized():
    v1 = hash_embed("hello world")
    v2 = hash_embed("hello world")
    assert (v1 == v2).all()
    import numpy as np
    assert abs(np.linalg.norm(v1) - 1.0) < 1e-9


def test_sqlite_persists_across_reconnect(tmp_path):
    db_path = str(tmp_path / "persist.db")
    s1 = SQLiteVectorStore(db_path)
    s1.add("persisted fact", importance=0.8, dedupe=False)
    s1.close()

    s2 = SQLiteVectorStore(db_path)
    items = s2.list()
    assert len(items) == 1
    assert items[0]["text"] == "persisted fact"
    assert items[0]["importance"] == 0.8
    s2.close()
