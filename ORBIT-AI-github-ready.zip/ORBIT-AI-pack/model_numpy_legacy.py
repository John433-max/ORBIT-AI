"""
Tiny decoder-only transformer, built from scratch on autograd.py.

This is Architecture A (standard decoder-only) with an optional bolt-on
Architecture B module (recursive latent x/y/z reasoning), toggled by
`use_recursive_reasoning`. It is a *reference implementation of the pattern*
at toy scale (see DESIGN.md Part 7 for why this must not be read as "this is
how a larger research model might work") — it exists to make the recursion mechanics
(shared weights, N_sup outer steps, gradient flow) concrete and testable,
not to demonstrate reasoning improvement (a 2-layer / d_model=64 model on a
few hundred bytes of toy text can't show that either way).

Components, and why each was chosen (see DESIGN.md for the full comparison):
- RMSNorm instead of LayerNorm: no mean-subtraction/bias term, cheaper, and
  the standard choice in current open decoder-only models.
- RoPE instead of learned/absolute positions: relative-position encoding,
  extrapolates better, no extra parameters.
- GQA (fewer KV heads than Q heads): shrinks the KV cache, the dominant
  inference memory cost at long context, at a small quality cost vs full MHA.
- SwiGLU MLP: gated activation, consistently outperforms plain ReLU/GELU MLPs
  of matched compute in published ablations.
- Tied input/output embedding: halves the embedding parameter count, which
  matters relatively more at small vocab/dim (still common practice at scale
  for the same reason, just smaller relative effect).
"""
import numpy as np
from autograd import Tensor, embedding_lookup


def check_finite(x: np.ndarray, name: str):
    """Raise immediately (with the offending tensor's name) on NaN/Inf.

    Cheap guard for catching numerical blow-ups (bad init scale, unclipped
    gradients, div-by-zero in norm/softmax) at the point they first appear,
    rather than several layers downstream where the actual cause is gone.
    """
    if not np.all(np.isfinite(x)):
        n_nan = int(np.sum(np.isnan(x)))
        n_inf = int(np.sum(np.isinf(x)))
        raise FloatingPointError(f"non-finite values in {name}: {n_nan} NaN, {n_inf} Inf")


def init_linear(rng, d_in, d_out, scale=None):
    scale = scale or (1.0 / np.sqrt(d_in))
    return Tensor(rng.normal(scale=scale, size=(d_in, d_out)))


def rmsnorm(x: Tensor, weight: Tensor, eps=1e-6) -> Tensor:
    # x: (..., D)
    ms = (x * x).mean(axis=-1, keepdims=True)
    inv = (ms + eps).sqrt().pow(-1.0)
    return x * inv * weight


def rope_cos_sin(seq_len, d_head, base=10000.0):
    inv_freq = 1.0 / (base ** (np.arange(0, d_head, 2) / d_head))
    t = np.arange(seq_len)
    freqs = np.outer(t, inv_freq)              # (T, d_head/2)
    cos = np.concatenate([np.cos(freqs), np.cos(freqs)], axis=-1)  # (T, d_head)
    sin = np.concatenate([np.sin(freqs), np.sin(freqs)], axis=-1)
    return cos, sin  # numpy constants, no grad needed


def apply_rope(x: Tensor, cos: np.ndarray, sin: np.ndarray) -> Tensor:
    # x: (B, H, T, d_head). Rotation is linear/orthogonal per position, so
    # backward is just the same rotation applied to the incoming grad
    # (R^T = R(-theta) for a rotation matrix) — done manually here.
    d = x.data.shape[-1]
    x1, x2 = x.data[..., : d // 2], x.data[..., d // 2 :]
    rot = np.concatenate([-x2, x1], axis=-1)
    y = x.data * cos + rot * sin
    out = Tensor(y, (x,))
    def _bw():
        g = out.grad
        g1, g2 = g[..., : d // 2], g[..., d // 2 :]
        # d(rot)/dx contributes via the sin term; apply inverse rotation
        grot = np.concatenate([g2, -g1], axis=-1)
        dx = g * cos + grot * sin
        x._accum(dx)
    out._backward = _bw
    return out


class CausalSelfAttentionGQA:
    def __init__(self, rng, d_model, n_heads, n_kv_heads, d_head):
        self.n_heads, self.n_kv_heads, self.d_head = n_heads, n_kv_heads, d_head
        self.Wq = init_linear(rng, d_model, n_heads * d_head)
        self.Wk = init_linear(rng, d_model, n_kv_heads * d_head)
        self.Wv = init_linear(rng, d_model, n_kv_heads * d_head)
        self.Wo = init_linear(rng, n_heads * d_head, d_model)

    def params(self):
        return [self.Wq, self.Wk, self.Wv, self.Wo]

    @staticmethod
    def _expand_kv(t: Tensor, group: int, B, KVH, T, dh) -> Tensor:
        # (B,KVH,T,dh) -> (B,H,T,dh): repeat each KV head `group` times so it
        # can be compared against every Q head that shares it (the GQA trick).
        rep = np.repeat(t.data, group, axis=1)
        out = Tensor(rep, (t,))
        def _bw():
            g = out.grad.reshape(B, KVH, group, T, dh).sum(axis=2)
            t._accum(g)
        out._backward = _bw
        return out

    def __call__(self, x: Tensor, cos, sin, causal_mask: np.ndarray) -> Tensor:
        B, T, D = x.data.shape
        H, KVH, dh = self.n_heads, self.n_kv_heads, self.d_head
        group = H // KVH

        q = (x @ self.Wq).reshape(B, T, H, dh).transpose(0, 2, 1, 3)      # (B,H,T,dh)
        k = (x @ self.Wk).reshape(B, T, KVH, dh).transpose(0, 2, 1, 3)    # (B,KVH,T,dh)
        v = (x @ self.Wv).reshape(B, T, KVH, dh).transpose(0, 2, 1, 3)

        q = apply_rope(q, cos, sin)
        k = apply_rope(k, cos, sin)

        k = self._expand_kv(k, group, B, KVH, T, dh)
        v = self._expand_kv(v, group, B, KVH, T, dh)

        scores = q.matmul(k.transpose(0, 1, 3, 2)) * (1.0 / np.sqrt(dh))  # (B,H,T,T)
        scores = scores + Tensor(causal_mask, requires_grad=False)
        attn = scores.softmax(axis=-1)
        out = attn.matmul(v)                                              # (B,H,T,dh)
        out = out.transpose(0, 2, 1, 3).reshape(B, T, H * dh)
        return out @ self.Wo


class SwiGLUMLP:
    def __init__(self, rng, d_model, d_ff):
        self.W1 = init_linear(rng, d_model, d_ff)   # gate
        self.W2 = init_linear(rng, d_model, d_ff)   # up
        self.W3 = init_linear(rng, d_ff, d_model)   # down

    def params(self):
        return [self.W1, self.W2, self.W3]

    def __call__(self, x: Tensor) -> Tensor:
        gate = (x @ self.W1).silu()
        up = x @ self.W2
        return (gate * up) @ self.W3


class Block:
    def __init__(self, rng, d_model, n_heads, n_kv_heads, d_head, d_ff):
        self.attn = CausalSelfAttentionGQA(rng, d_model, n_heads, n_kv_heads, d_head)
        self.mlp = SwiGLUMLP(rng, d_model, d_ff)
        self.norm1 = Tensor(np.ones(d_model))
        self.norm2 = Tensor(np.ones(d_model))

    def params(self):
        return self.attn.params() + self.mlp.params() + [self.norm1, self.norm2]

    def __call__(self, x, cos, sin, mask):
        x = x + self.attn(rmsnorm(x, self.norm1), cos, sin, mask)
        x = x + self.mlp(rmsnorm(x, self.norm2))
        return x


class ReasoningBlock:
    """
    Reference implementation of the x/y/z recursive pattern (spec Part 2/7),
    at toy scale, with weights SHARED across all recursive steps (this is the
    one design choice the TRM-style literature is fairly unanimous on: an
    unshared per-step network is just a deeper feedforward stack in disguise
    and loses the "recursion" property entirely).

    z lives in hidden-state space (not token space): it is the same width as
    the transformer's residual stream, is never projected back to token
    logits itself, and is discarded at the end of generation rather than
    persisted — see DESIGN.md Part 2 items 1, 12, 13 for the reasoning.

    y is the answer/residual-stream state (post-transformer hidden state),
    not a separate embedding — this is Architecture B from DESIGN.md.
    """
    def __init__(self, rng, d_model, n_sup=4):
        self.n_sup = n_sup
        # shared weights across every recursive step
        self.Wz = init_linear(rng, 3 * d_model, d_model)   # updates z from [x;y;z]
        self.Wy = init_linear(rng, 2 * d_model, d_model)   # updates y from [y;z]
        self.norm_z = Tensor(np.ones(d_model))
        self.norm_y = Tensor(np.ones(d_model))

    def params(self):
        return [self.Wz, self.Wy, self.norm_z, self.norm_y]

    def __call__(self, x: Tensor, y: Tensor):
        B, T, D = y.data.shape
        z = Tensor(np.zeros((B, T, D)))
        for _ in range(self.n_sup):
            zin = concat3(x, y, z)
            z = rmsnorm((zin @ self.Wz).silu(), self.norm_z)
            yin = concat2(y, z)
            y = y + rmsnorm((yin @ self.Wy).silu(), self.norm_y)
        return y


def concat2(a: Tensor, b: Tensor) -> Tensor:
    data = np.concatenate([a.data, b.data], axis=-1)
    out = Tensor(data, (a, b))
    da = a.data.shape[-1]
    def _bw():
        a._accum(out.grad[..., :da])
        b._accum(out.grad[..., da:])
    out._backward = _bw
    return out

def concat3(a: Tensor, b: Tensor, c: Tensor) -> Tensor:
    return concat2(concat2(a, b), c)


class TinyLM:
    def __init__(self, vocab_size, d_model=64, n_layers=2, n_heads=4, n_kv_heads=2,
                 d_ff=None, max_seq_len=128, use_recursive_reasoning=False,
                 n_sup=4, seed=0):
        # Config validation: catch shape-incompatible configs at construction
        # time with a clear message, instead of a cryptic numpy broadcast
        # error deep inside the first forward pass.
        if vocab_size <= 0:
            raise ValueError(f"vocab_size must be positive, got {vocab_size}")
        if d_model % n_heads != 0:
            raise ValueError(f"d_model ({d_model}) must be divisible by n_heads ({n_heads})")
        if n_heads % n_kv_heads != 0:
            raise ValueError(f"n_heads ({n_heads}) must be divisible by n_kv_heads ({n_kv_heads}) for GQA")
        if n_kv_heads > n_heads:
            raise ValueError(f"n_kv_heads ({n_kv_heads}) cannot exceed n_heads ({n_heads})")
        if n_layers <= 0:
            raise ValueError(f"n_layers must be positive, got {n_layers}")
        if max_seq_len <= 0:
            raise ValueError(f"max_seq_len must be positive, got {max_seq_len}")

        rng = np.random.default_rng(seed)
        self.d_head = d_model // n_heads
        d_ff = d_ff or int(d_model * 8 / 3)
        self.tok_emb = Tensor(rng.normal(scale=0.02, size=(vocab_size, d_model)))
        self.blocks = [Block(rng, d_model, n_heads, n_kv_heads, self.d_head, d_ff)
                        for _ in range(n_layers)]
        self.norm_f = Tensor(np.ones(d_model))
        self.cos, self.sin = rope_cos_sin(max_seq_len, self.d_head)
        self.use_recursive_reasoning = use_recursive_reasoning
        if use_recursive_reasoning:
            self.reasoner = ReasoningBlock(rng, d_model, n_sup=n_sup)
        self.max_seq_len = max_seq_len
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads

    def params(self):
        p = [self.tok_emb, self.norm_f]
        for b in self.blocks:
            p += b.params()
        if self.use_recursive_reasoning:
            p += self.reasoner.params()
        return p

    def __call__(self, input_ids: np.ndarray) -> Tensor:
        B, T = input_ids.shape
        if T > self.max_seq_len:
            raise ValueError(f"sequence length {T} exceeds model max_seq_len {self.max_seq_len}")
        if input_ids.size and (input_ids.min() < 0 or input_ids.max() >= self.vocab_size):
            raise ValueError(
                f"token id out of range [0, {self.vocab_size}): got min={input_ids.min()}, max={input_ids.max()}")
        x = embedding_lookup(self.tok_emb, input_ids)  # (B,T,D)
        mask = np.triu(np.full((T, T), -1e9), k=1)[None, None, :, :]
        cos, sin = self.cos[None, None, :T, :], self.sin[None, None, :T, :]
        h = x
        for blk in self.blocks:
            h = blk(h, cos, sin, mask)
        if self.use_recursive_reasoning:
            h = self.reasoner(x, h)   # x = original token embeddings, h plays role of y
        h = rmsnorm(h, self.norm_f)
        logits = h.reshape(B * T, self.d_model) @ self.tok_emb.transpose(1, 0)
        check_finite(logits.data, "final logits")
        return logits  # (B*T, V) — output head tied to input embedding

    def param_count(self) -> int:
        return sum(p.data.size for p in self.params())
