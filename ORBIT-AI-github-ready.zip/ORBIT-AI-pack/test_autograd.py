"""Numerical gradient checks for autograd.py. Run: python3 test_autograd.py"""
import numpy as np
from autograd import Tensor, embedding_lookup, cross_entropy

rng = np.random.default_rng(0)

def numeric_grad(f, x, eps=1e-5):
    g = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    for _ in it:
        idx = it.multi_index
        old = x[idx]
        x[idx] = old + eps
        f1 = f(x)
        x[idx] = old - eps
        f2 = f(x)
        x[idx] = old
        g[idx] = (f1 - f2) / (2 * eps)
    return g

def check(name, build_fn, x0, tol=1e-4):
    def f(xd):
        t = Tensor(xd.copy())
        out = build_fn(t)
        return out.data.sum() if out.data.ndim else float(out.data)

    t = Tensor(x0.copy())
    out = build_fn(t)
    scalar = out.sum() if out.data.ndim else out
    scalar.backward()
    analytic = t.grad
    numeric = numeric_grad(f, x0.copy())
    err = np.abs(analytic - numeric).max()
    status = "OK" if err < tol else "FAIL"
    print(f"[{status}] {name}: max abs err = {err:.2e}")
    assert err < tol, f"{name} gradient mismatch (err={err})"

x = rng.normal(size=(3, 4)).astype(np.float64)
y = rng.normal(size=(4, 5)).astype(np.float64)

check("add+mul", lambda t: (t * 2.0 + t * t), x)
check("matmul", lambda t: t.matmul(Tensor(y, requires_grad=False)), x)
check("sum/mean", lambda t: t.mean(axis=1), x)
check("pow/sqrt", lambda t: (t * t + 1.0).sqrt(), x)
check("softmax", lambda t: t.softmax(axis=-1), x)
check("silu", lambda t: t.silu(), x)
check("reshape/transpose", lambda t: t.reshape(2, 6).transpose(1, 0), x)

# embedding lookup
W = Tensor(rng.normal(size=(10, 4)))
idx = np.array([1, 3, 3, 7])
out = embedding_lookup(W, idx)
out.sum().backward()
expected = np.zeros_like(W.data)
np.add.at(expected, idx, np.ones((4, 4)))
assert np.allclose(W.grad, expected), "embedding grad mismatch"
print("[OK] embedding_lookup")

# cross entropy
logits = Tensor(rng.normal(size=(5, 6)))
targets = np.array([0, 1, 2, 3, 4])
def f_ce(xd):
    t = Tensor(xd.copy())
    return float(cross_entropy(t, targets).data)
loss = cross_entropy(logits, targets)
loss.backward()
numeric = numeric_grad(f_ce, logits.data.copy())
err = np.abs(logits.grad - numeric).max()
print(f"[{'OK' if err < 1e-4 else 'FAIL'}] cross_entropy: max abs err = {err:.2e}")
assert err < 1e-4

print("\nAll autograd gradient checks passed.")
