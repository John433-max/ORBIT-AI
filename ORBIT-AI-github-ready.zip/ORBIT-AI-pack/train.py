"""
Training loop. Uses the real BPE tokenizer (bpe_tokenizer.py) trained on
this repo's own dataset pipeline (dataset.py) — a step up from the earlier
byte-level fallback (still available in tokenizer.py for reference/round-
trip-safety comparisons). Configurable model size (spec Part 20's
progressive scaling), a held-out validation split, and real perplexity
evaluation.

Run: python3 train.py
"""
import time
import gc
import json
import numpy as np
from bpe_tokenizer import BPETokenizer
from model import TinyLM
from autograd import cross_entropy
from dataset import build_corpus

TRAIN_TEXT, VAL_TEXT, DATASET_REPORT = build_corpus()

# Train the tokenizer once on the full corpus (train+val text) — standard
# practice: tokenizer vocabulary construction is not the same thing as
# label leakage between train/val loss, so this isn't the contamination
# dataset.py's own pipeline checks for (that check is about the model
# learning to predict val content from train content, not about which
# sub-word units exist in the vocabulary).
TOKENIZER = BPETokenizer().train(TRAIN_TEXT + "\n" + VAL_TEXT, vocab_size=700, min_frequency=2)
TOKENIZER.save("bpe_tokenizer.json")

MODEL_CONFIGS = {
    # name: (d_model, n_layers, n_heads, n_kv_heads)
    # Kept for train.py's original loop. Prefer configs/*.yaml + model.config
    # for new work. Note: train.py's historical "tiny" is the development-scale
    # toy (d=64); YAML preset "tiny" is the ~914k experimental model (d=128).
    "development": (64, 2, 4, 2),
    "tiny": (64, 2, 4, 2),  # alias for scripts that still pass config="tiny"
    "small": (128, 4, 8, 2),
    "orbit_tiny": (128, 4, 8, 4),  # matches configs/tiny.yaml / checkpoint_large
}


def clip_grad_norm(params, max_norm: float) -> float:
    """Global L2 gradient-norm clipping across all params (standard practice:
    prevents any single bad batch from taking an oversized step). Returns the
    pre-clip norm so callers can log it."""
    total_sq = 0.0
    for p in params:
        if p.grad is not None:
            total_sq += float(np.sum(p.grad ** 2))
    total_norm = float(np.sqrt(total_sq))
    if total_norm > max_norm and total_norm > 0:
        scale = max_norm / (total_norm + 1e-6)
        for p in params:
            if p.grad is not None:
                p.grad *= scale
    return total_norm


def lr_at_step(step: int, base_lr: float, warmup_steps: int, max_steps: int, min_lr_ratio: float = 0.1) -> float:
    """Linear warmup, then cosine decay to `min_lr_ratio * base_lr`. Standard
    schedule; without warmup, Adam's early-step variance estimates are noisy
    and large steps at t=1 with a full-size LR can blow up initialization."""
    if warmup_steps > 0 and step < warmup_steps:
        return base_lr * step / max(1, warmup_steps)
    if max_steps <= warmup_steps:
        return base_lr
    progress = (step - warmup_steps) / max(1, max_steps - warmup_steps)
    progress = min(1.0, max(0.0, progress))
    cosine = 0.5 * (1 + np.cos(np.pi * progress))
    return base_lr * (min_lr_ratio + (1 - min_lr_ratio) * cosine)


class Adam:
    def __init__(self, params, lr=3e-3, betas=(0.9, 0.95), eps=1e-8, wd=0.01):
        self.params = params
        self.lr, self.b1, self.b2, self.eps, self.wd = lr, betas[0], betas[1], eps, wd
        self.m = [np.zeros_like(p.data) for p in params]
        self.v = [np.zeros_like(p.data) for p in params]
        self.t = 0

    def zero_grad(self):
        for p in self.params:
            p.zero_grad()

    def step(self, lr: float = None):
        self.t += 1
        lr = self.lr if lr is None else lr
        for i, p in enumerate(self.params):
            if p.grad is None:
                continue
            g = p.grad + self.wd * p.data
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * (g * g)
            mhat = self.m[i] / (1 - self.b1 ** self.t)
            vhat = self.v[i] / (1 - self.b2 ** self.t)
            p.data -= lr * mhat / (np.sqrt(vhat) + self.eps)


def make_batches(ids, seq_len, batch_size, rng):
    ids = np.array(ids)
    n = len(ids) - seq_len - 1
    if n <= 0:
        raise ValueError("corpus too short for this seq_len")
    while True:
        starts = rng.integers(0, n, size=batch_size)
        x = np.stack([ids[s: s + seq_len] for s in starts])
        y = np.stack([ids[s + 1: s + seq_len + 1] for s in starts])
        yield x, y


def eval_perplexity(model, ids, seq_len, n_windows=8):
    """Non-overlapping windows over held-out text, average cross-entropy -> perplexity."""
    ids = np.array(ids)
    n = min(n_windows, max(1, (len(ids) - 1) // seq_len))
    losses = []
    for i in range(n):
        s = i * seq_len
        x = ids[s: s + seq_len][None, :]
        y = ids[s + 1: s + seq_len + 1][None, :]
        if x.shape[1] < seq_len or y.shape[1] < seq_len:
            break
        logits = model(x)
        loss = cross_entropy(logits, y.reshape(-1))
        losses.append(float(loss.data))
    mean_loss = float(np.mean(losses)) if losses else float("nan")
    return mean_loss, float(np.exp(mean_loss))


def train(use_recursive_reasoning, config="tiny", steps=300, seq_len=32,
          batch_size=8, seed=0, log_every=100, lr=3e-3, warmup_steps=20,
          gradient_clip=1.0, early_stop_patience=None):
    d_model, n_layers, n_heads, n_kv_heads = MODEL_CONFIGS[config]
    train_ids = TOKENIZER.encode(TRAIN_TEXT, add_bos=False, add_eos=False)
    val_ids = TOKENIZER.encode(VAL_TEXT, add_bos=False, add_eos=False)
    rng = np.random.default_rng(seed)
    model = TinyLM(vocab_size=TOKENIZER.VOCAB_SIZE, d_model=d_model, n_layers=n_layers,
                    n_heads=n_heads, n_kv_heads=n_kv_heads, max_seq_len=seq_len,
                    use_recursive_reasoning=use_recursive_reasoning, n_sup=3, seed=seed)
    opt = Adam(model.params(), lr=lr)
    batches = make_batches(train_ids, seq_len, batch_size, rng)

    train_losses = []
    best_val_loss = float("inf")
    best_state = None
    steps_since_best = 0
    t0 = time.time()
    for step in range(1, steps + 1):
        x, y = next(batches)
        opt.zero_grad()
        logits = model(x)
        loss = cross_entropy(logits, y.reshape(-1))
        loss.backward()
        step_lr = lr_at_step(step, lr, warmup_steps, steps)
        grad_norm = clip_grad_norm(model.params(), gradient_clip)
        opt.step(lr=step_lr)
        train_losses.append(float(loss.data))
        if step % 200 == 0:
            # Defensive periodic collection: autograd.py's backward() now
            # breaks each graph's own reference cycles immediately (see that
            # module's comment), which fixed the unbounded per-step growth
            # this used to have. This periodic sweep is just a cheap
            # insurance policy against any other, unrelated cyclic garbage
            # (e.g. from third-party library internals) slowly building up
            # over a long run — verified harmless to correctness, negligible
            # cost at this interval.
            gc.collect()
        if step % log_every == 0 or step == 1:
            val_loss, val_ppl = eval_perplexity(model, val_ids, seq_len)
            tag = 'recursive' if use_recursive_reasoning else 'base    '
            print(f"  [{tag}/{config}] step {step:4d}/{steps}  "
                  f"train_loss {float(loss.data):.4f}  val_loss {val_loss:.4f}  val_ppl {val_ppl:.2f}  "
                  f"lr {step_lr:.2e}  grad_norm {grad_norm:.2f}")
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = [p.data.copy() for p in model.params()]
                steps_since_best = 0
            else:
                steps_since_best += log_every
            if early_stop_patience and steps_since_best >= early_stop_patience:
                print(f"  early stopping at step {step} (no val improvement for {steps_since_best} steps)")
                break
    dt = time.time() - t0
    # restore best-validation weights rather than returning the last step's
    # (which may have already started overfitting)
    if best_state is not None:
        for p, saved in zip(model.params(), best_state):
            p.data = saved
    final_val_loss, final_val_ppl = eval_perplexity(model, val_ids, seq_len)
    return model, train_losses, final_val_loss, final_val_ppl, dt


def save_checkpoint(model, path, metadata: dict = None):
    """Save weights (.npz) plus a metadata sidecar (.json) — config, step,
    val_loss, seed — so a checkpoint is self-describing enough to know what
    it is without re-reading the training script that produced it."""
    arrays = {f"param_{i}": p.data for i, p in enumerate(model.params())}
    np.savez(path, **arrays)
    if metadata is not None:
        import json
        meta_path = path[:-4] + ".json" if path.endswith(".npz") else path + ".json"
        with open(meta_path, "w") as f:
            json.dump(metadata, f, indent=2)


def load_into(model, path):
    """Load weights into `model`. Validates that the checkpoint's parameter
    shapes actually match the model's before writing anything -- without
    this, loading a checkpoint trained with different d_model/n_layers/etc.
    would silently overwrite each parameter slot with a wrong-shaped array
    (numpy allows this; the model would then look loaded but be corrupt,
    failing confusingly at inference time instead of at load time). This
    was a real, live bug: an earlier build of api.py hardcoded one
    architecture while checkpoint files trained with a different config
    (train_large.py's larger model) were also present in the same
    directory -- nothing enforced they matched."""
    data = np.load(path)
    params = model.params()
    if len(params) != len([k for k in data.files if k.startswith("param_")]):
        raise ValueError(
            f"checkpoint '{path}' has {len([k for k in data.files if k.startswith('param_')])} "
            f"parameter tensors but the model has {len(params)} -- this checkpoint was not "
            f"trained with this model's architecture.")
    for i, p in enumerate(params):
        saved = data[f"param_{i}"]
        if saved.shape != p.data.shape:
            raise ValueError(
                f"checkpoint '{path}' parameter {i} has shape {saved.shape} but the model "
                f"expects {p.data.shape} -- this checkpoint was trained with a different "
                f"model configuration (d_model/n_layers/n_heads/etc). Build the model from "
                f"the checkpoint's .json metadata (see build_model_from_checkpoint) rather "
                f"than a hardcoded config.")
        p.data = saved


def build_model_from_checkpoint(npz_path: str, json_path: str = None):
    """The robust way to load a checkpoint: read its metadata sidecar for
    the exact architecture it was trained with, construct a matching
    TinyLM, then load weights into it -- rather than assuming any fixed
    config and hoping it matches. Raises FileNotFoundError if either file
    is missing, ValueError (via load_into) if they're present but
    mismatched with each other."""
    if json_path is None:
        json_path = npz_path[:-4] + ".json" if npz_path.endswith(".npz") else npz_path + ".json"
    with open(json_path) as f:
        meta = json.load(f)
    required = ["d_model", "n_layers", "n_heads", "n_kv_heads", "vocab_size"]
    missing = [k for k in required if k not in meta]
    if missing:
        raise ValueError(
            f"checkpoint metadata '{json_path}' is missing required fields {missing} -- "
            f"cannot safely reconstruct the model architecture from it.")
    model = TinyLM(vocab_size=meta["vocab_size"], d_model=meta["d_model"], n_layers=meta["n_layers"],
                    n_heads=meta["n_heads"], n_kv_heads=meta["n_kv_heads"],
                    max_seq_len=meta.get("seq_len", 64),
                    use_recursive_reasoning=meta.get("recursive", False))
    load_into(model, npz_path)
    return model, meta


def full_checkpoint_metadata(model, **extra) -> dict:
    """Build a self-describing metadata dict from a model's actual
    attributes (not from whatever config name happened to be used to build
    it) -- the same format train_large.py's runs produce, so
    build_model_from_checkpoint works identically on any checkpoint this
    project writes, regardless of which script wrote it.

    Works for both the NumPy backend (model.py's TinyLM) and the PyTorch
    backend (model_torch.py's TinyLMTorch): d_model/n_heads/n_kv_heads/
    vocab_size/max_seq_len/use_recursive_reasoning/blocks/param_count() are
    all deliberately named identically on both classes for exactly this
    reason. First version of this function used
    `sum(p.data.size for p in model.params())` to count parameters, which
    is NumPy-Tensor-specific API (`.params()`/`.data.size`) that doesn't
    exist on an nn.Module -- found by actually running train_torch.py
    end-to-end, not by inspection; a claim in this function's own earlier
    docstring that it "works unmodified on either backend" was wrong and
    had not actually been tested against the torch backend at the time it
    was written."""
    meta = {
        "d_model": model.d_model, "n_layers": len(model.blocks),
        "n_heads": model.n_heads, "n_kv_heads": model.n_kv_heads,
        "vocab_size": model.vocab_size, "seq_len": model.max_seq_len,
        "recursive": model.use_recursive_reasoning,
        "n_params": model.param_count(),
    }
    meta.update(extra)
    return meta


if __name__ == "__main__":
    print("=== dataset pipeline (dataset.py) ===")
    print(f"train: {DATASET_REPORT['n_train_docs']} docs / {DATASET_REPORT['train_bytes']} bytes   "
          f"val: {DATASET_REPORT['n_val_docs']} docs / {DATASET_REPORT['val_bytes']} bytes")
    print(f"dedup removed: {len(DATASET_REPORT['dedup_removed'])}   "
          f"quality removed: {len(DATASET_REPORT['quality_removed'])}   "
          f"lang counts: {dict(DATASET_REPORT['lang_counts'])}")
    print(f"train/val contamination: {DATASET_REPORT['contamination_overlap_8gram_count']} shared 8-grams "
          f"({DATASET_REPORT['contamination_overlap_ratio']*100:.1f}% of val)")

    print("\n=== tokenizer (bpe_tokenizer.py) ===")
    train_ids_preview = TOKENIZER.encode(TRAIN_TEXT, add_bos=False, add_eos=False)
    byte_len = len(TRAIN_TEXT.encode("utf-8"))
    print(f"{len(TOKENIZER.merge_order)} merges learned, vocab size {TOKENIZER.VOCAB_SIZE}")
    print(f"train text: {byte_len} bytes -> {len(train_ids_preview)} tokens "
          f"({len(train_ids_preview) / byte_len * 100:.0f}% of byte-level length)")

    print("\n=== tiny config (d_model=64, 2 layers) ===")
    print("Training base decoder-only model (Architecture A)...")
    model_a, losses_a, val_a, ppl_a, dt_a = train(use_recursive_reasoning=False, config="tiny", steps=300)
    save_checkpoint(model_a, "checkpoint_base.npz",
                     metadata=full_checkpoint_metadata(model_a, config="tiny", val_loss=val_a, val_ppl=ppl_a, seed=0))

    print("\nTraining recursive-reasoning model (Architecture B)...")
    model_b, losses_b, val_b, ppl_b, dt_b = train(use_recursive_reasoning=True, config="tiny", steps=300)
    save_checkpoint(model_b, "checkpoint_recursive.npz",
                     metadata=full_checkpoint_metadata(model_b, config="tiny", val_loss=val_b, val_ppl=ppl_b, seed=0))

    print("\n=== small config (d_model=128, 4 layers) — one step up the Part 20 ladder ===")
    print("Training base decoder-only model at the next size up...")
    model_c, losses_c, val_c, ppl_c, dt_c = train(use_recursive_reasoning=False, config="small", steps=300)
    save_checkpoint(model_c, "checkpoint_small.npz",
                     metadata=full_checkpoint_metadata(model_c, config="small", val_loss=val_c, val_ppl=ppl_c, seed=0))

    print("\n--- Summary (held-out validation, never trained on) ---")
    for name, losses, val_loss, ppl, dt, m in [
        ("tiny/base     ", losses_a, val_a, ppl_a, dt_a, model_a),
        ("tiny/recursive", losses_b, val_b, ppl_b, dt_b, model_b),
        ("small/base    ", losses_c, val_c, ppl_c, dt_c, model_c),
    ]:
        n_params = sum(p.data.size for p in m.params())
        print(f"{name}: train_loss {losses[0]:.3f}->{np.mean(losses[-10:]):.3f}  "
              f"val_loss {val_loss:.3f}  val_ppl {ppl:.2f}  ({dt:.1f}s, {n_params:,} params)")

    print("\nReloading base checkpoint and confirming val loss matches...")
    val_ids = TOKENIZER.encode(VAL_TEXT, add_bos=False, add_eos=False)
    fresh = TinyLM(vocab_size=TOKENIZER.VOCAB_SIZE, d_model=64, n_layers=2,
                   n_heads=4, n_kv_heads=2, max_seq_len=32, use_recursive_reasoning=False, seed=999)
    load_into(fresh, "checkpoint_base.npz")
    reloaded_val_loss, reloaded_ppl = eval_perplexity(fresh, val_ids, 32)
    print(f"reloaded-model val_loss: {reloaded_val_loss:.4f}  ppl: {reloaded_ppl:.2f}  "
          f"(should match tiny/base above)")

    print("\nNOTE: this dataset is ~3.5KB train / ~0.7KB val across 9 hand-authored")
    print("categories, now tokenized with a real trained BPE vocab (700 tokens,")
    print("~38% shorter sequences than byte-level) instead of raw bytes — a real")
    print("step toward production tokenization, still far below even 'MODEL 1: 10M")
    print("param toy transformer' scale. Val perplexity numbers are real and")
    print("reproducible; still too small a model/corpus for architecture claims.")
