"""Lightweight system / process metrics (CPU, RAM). No fabricated numbers."""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional


@dataclass
class Snapshot:
    ts: float
    cpu_percent: Optional[float]
    rss_mb: Optional[float]
    threads: Optional[int]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SystemMonitor:
    def __init__(self):
        self._proc = None
        try:
            import psutil
            self._proc = psutil.Process(os.getpid())
        except Exception:
            self._proc = None

    def snapshot(self) -> Snapshot:
        cpu = rss = threads = None
        if self._proc is not None:
            try:
                cpu = self._proc.cpu_percent(interval=0.05)
                rss = self._proc.memory_info().rss / (1024 * 1024)
                threads = self._proc.num_threads()
            except Exception:
                pass
        else:
            # Fallback: RSS via resource on POSIX
            try:
                import resource
                rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
                # Linux reports KB, macOS bytes — approximate
                if rss > 10_000_000:  # likely bytes
                    rss = rss / (1024 * 1024)
                else:
                    rss = rss / 1024
            except Exception:
                pass
        return Snapshot(ts=time.time(), cpu_percent=cpu, rss_mb=rss, threads=threads)
