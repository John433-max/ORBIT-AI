"""
Record actual runtime metrics — no fabricated benchmarks.

Writes JSON lines under logs/metrics.jsonl so DEFINITION OF DONE
("Actual hardware performance is recorded") can be satisfied with evidence.
"""

from __future__ import annotations

import json
import os
import time
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional

_LOCK = threading.Lock()
_DEFAULT_PATH = Path(os.environ.get("ORBIT_METRICS_PATH", "logs/metrics.jsonl"))


class MetricsStore:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else _DEFAULT_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, event: str, **fields: Any) -> None:
        row = {"event": event, "ts": time.time(), **fields}
        line = json.dumps(row, default=str)
        with _LOCK:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line + "\n")

    def read_recent(self, n: int = 50) -> list:
        if not self.path.exists():
            return []
        lines = self.path.read_text(encoding="utf-8").strip().splitlines()
        out = []
        for line in lines[-n:]:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out


_STORE = MetricsStore()


@contextmanager
def timed(event: str, **fields):
    t0 = time.perf_counter()
    ok = True
    err = None
    try:
        yield
    except Exception as e:
        ok = False
        err = str(e)
        raise
    finally:
        ms = (time.perf_counter() - t0) * 1000
        payload = dict(fields)
        payload["latency_ms"] = round(ms, 3)
        payload["ok"] = ok
        if err:
            payload["error"] = err
        _STORE.write(event, **payload)


def record_generation(
    *,
    n_tokens: int,
    elapsed_s: float,
    model_params: Optional[int] = None,
    checkpoint: Optional[str] = None,
    prompt_len: Optional[int] = None,
) -> Dict[str, Any]:
    tok_s = (n_tokens / elapsed_s) if elapsed_s > 0 else 0.0
    row = {
        "n_tokens": n_tokens,
        "elapsed_s": round(elapsed_s, 4),
        "tokens_per_sec": round(tok_s, 2),
        "model_params": model_params,
        "checkpoint": checkpoint,
        "prompt_len": prompt_len,
    }
    _STORE.write("generation", **row)
    return row
