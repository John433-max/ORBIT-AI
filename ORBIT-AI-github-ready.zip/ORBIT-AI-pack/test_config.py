"""Tests for the ORBIT configuration system."""

import os
from pathlib import Path

import pytest

from model.config import (
    ModelConfig,
    TrainingConfig,
    RuntimeConfig,
    DatasetMixConfig,
    OrbitConfig,
    get_preset,
)


def test_model_config_defaults_and_validation():
    cfg = ModelConfig()
    assert cfg.d_model == 128
    assert cfg.d_ff is not None
    assert cfg.d_head == cfg.d_model // cfg.n_heads

    with pytest.raises(ValueError):
        ModelConfig(d_model=100, n_heads=8)  # not divisible

    with pytest.raises(ValueError):
        ModelConfig(n_heads=4, n_kv_heads=8)  # kv > heads


def test_parameter_estimate_matches_known_model():
    # Known experimental model from checkpoint_large.json
    cfg = ModelConfig(
        d_model=128, n_layers=4, n_heads=8, n_kv_heads=4,
        context_length=64, vocab_size=1500,
    )
    assert cfg.estimate_parameters() == 913536


def test_load_yaml_presets():
    for name in ("tiny", "small", "medium", "development"):
        path = Path("configs") / f"{name}.yaml"
        assert path.exists(), f"missing {path}"
        cfg = OrbitConfig.load(path)
        assert cfg.model.d_model > 0
        assert cfg.training.max_steps > 0


def test_get_preset():
    cfg = get_preset("tiny")
    assert cfg.model.d_model == 128
    assert cfg.model.n_layers == 4


def test_from_config_builds_model():
    from model import TinyLM
    cfg = get_preset("development")
    m = TinyLM.from_config(cfg)
    assert m.param_count() > 0
    assert m.d_model == 64


def test_dataset_mix_normalize():
    mix = DatasetMixConfig(books=2.0, code=2.0, documentation=0, instruction=0,
                           math=0, filipino=0, tool_use=0)
    mix.normalize()
    assert abs(mix.books - 0.5) < 1e-9
    assert abs(mix.code - 0.5) < 1e-9


def test_save_and_reload(tmp_path):
    cfg = get_preset("tiny")
    out = tmp_path / "roundtrip.yaml"
    cfg.save_yaml(out)
    cfg2 = OrbitConfig.load(out)
    assert cfg2.model.d_model == cfg.model.d_model
    assert cfg2.training.learning_rate == cfg.training.learning_rate


def test_large_presets_exist():
    from model.config import PRESET_NAMES, get_preset
    for name in ("large", "xlarge", "xxlarge"):
        assert name in PRESET_NAMES
        cfg = get_preset(name)
        assert cfg.model.d_model >= 512
        assert cfg.model.estimate_parameters() > 10_000_000


def test_model_summary_keys():
    from model.config import get_preset
    s = get_preset("tiny").model.summary()
    for k in ("parameters", "weight_memory_mb_fp32", "optimizer_memory_mb_fp32",
              "activation_memory_mb_b1", "d_ff", "d_head"):
        assert k in s


def test_generation_config_roundtrip(tmp_path):
    from model.config import OrbitConfig, get_preset
    cfg = get_preset("tiny")
    cfg.generation.temperature = 0.5
    cfg.generation.max_new_tokens = 64
    out = tmp_path / "g.yaml"
    cfg.save_yaml(out)
    cfg2 = OrbitConfig.load(out)
    assert cfg2.generation.temperature == 0.5
    assert cfg2.generation.max_new_tokens == 64
