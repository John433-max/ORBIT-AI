# Changelog

## Phase D–E (2026-09-19)
- Tool permissions: SAFE < READ_ONLY < WRITE < NETWORK < EXECUTION < PRIVILEGED (LIMITED/FULL legacy)
- `orbit/core/state.py` AgentRun state machine; Orchestrator.handle emits `run_id`
- Orchestrator.model_router + generate_via_provider
- `python run_orbit.py eval` smoke suite (math/science/chat)
- tests/unit/test_permissions_and_state.py

# Changelog

## Cycle 78 — NumPy INT4 mmap (2026-09-19)
- `orbit.n4m` pickle-free packed INT4 (`save_numpy_int4_mmap`, auto-detect in `load_numpy_checkpoint`)
- Shipped `checkpoints/tinylm_persona_bpe_l4_int4emb.n4m` (137728 B, 5.45× vs L4 FP32)

## Phase C — ModelProvider (2026-09-19)
- `orbit/core/config.py` env configuration
- `orbit/models/` : base, echo, tinylm, ollama, openai_compatible, router
- `run_orbit.py` : doctor | status | serve | chat
- tests/unit/test_model_providers.py (6 passed)

# ORBIT Changelog

## v2.0.0-dev (in progress)

### Added
- Configuration system: `model/config.py` + `configs/{tiny,small,medium,development}.yaml`
- Modular `model/` package (embeddings, rope, rmsnorm, attention, swiglu, transformer_block, generation)
- Structured tool interface: `tools/base.py` with `BaseTool`, `ToolCall`, `ToolResult`, `ToolRegistry`
- Concrete tools: calculator, filesystem, python sandbox, web (provider abstraction + stub)
- Permission levels: SAFE / LIMITED / FULL
- `agent/tool_router.py` — structured ToolCallingAgent
- `memory/` package with MemoryManager (short-term + long-term)
- `rag/` package with RAGPipeline and source tracking
- `chat/` package: ChatTemplate, Conversation history
- `tokenizer/` package scaffold + expanded special token list
- `monitoring/` package with SystemMonitor
- Formal CLI: `python -m orbit {version,chat,agent,generate,train,server}`
- `docs/ARCHITECTURE.md`, `docs/ORBIT_V2_AUDIT.md`

### Changed
- Top-level `model.py` → `model_numpy_legacy.py` (imported via `model` package)
- Top-level `tools.py` → `tools_legacy.py` (re-exported via `tools` package)
- PyYAML added to requirements.txt

### Preserved
- All original tests, agents, API, NumPy + PyTorch models, BPE tokenizer, dataset pipeline, RAG extractive path, memory store, sandbox, paper trading

### Known limitations
- Keyword routing in `agents.py` still present (migration to structured tool calls is incremental)
- Web search remains an honest stub until a real provider is plugged in
- No Web UI yet
- No GGUF export yet
- KV cache not fully implemented in generation path

### Added (continued)
- Web UI at `/` and `/ui` (streaming chat, temperature, max tokens, system prompt)
- `training/checkpoint.py` — latest/best/archives layout + metadata
- `tokenizer/train_tokenizer.py` and `tokenizer/inspect_tokenizer.py`

### Added — more parameters / scale ladder
- Model presets: **large** (~39.5M), **xlarge** (~113M), **xxlarge** (~311M)
- Expanded `ModelConfig`: multiple_of, rope_scaling, attention/residual dropout, bias, flash flag, residual_init_scale
- Expanded `TrainingConfig`: optimizer choice, betas, eps, seq_len, workers, early stopping, checkpoint retention
- New `GenerationConfig`: temperature, top_k, top_p, repetition_penalty, max_new_tokens, KV cache flag
- Expanded `RuntimeConfig`: mps, compile, deterministic
- Memory estimates: weights, AdamW optimizer state, activations

### Improved
- Config-driven `training/trainer.py` with AdamW, warmup, cosine LR, grad clip, val eval, checkpoint promotion
- `evaluation/` package with measured loss/ppl/generation speed and repeatable prompts
- `agent/planner.py` multi-step heuristic planner wired into ToolCallingAgent
- `model/generation.py` unified generate() with full decoding controls
- `run_orbit.py` one-command launcher (env check + API + Web UI URL)

### Added — instruction tuning, API v2 routes, UI polish
- `datasets/instruction/` Alpaca + messages JSONL samples
- `training/finetune.py` — instruction fine-tune → `checkpoints/instruct/`
- Modular API: `/v2/generate`, `/v2/embed`, `/v2/memory/search`, `/v2/rag/query`, `/v2/agent/run`
- Web UI **Agent** button for structured tool calls + tool observation display
- CLI: `python -m orbit finetune --data ...`

### Improved — OpenAI API compatibility
- `GET /v1/models` richer catalog (`orbit-toy`, `orbit-tiny`, `text-embedding-orbit-hash`)
- `GET /v1/models/{model_id}`
- `POST /v1/completions` (legacy text completions, stream + non-stream, usage)
- `POST /v1/embeddings` (OpenAI shape, batch input, optional dimensions)
- Chat completions responses include `usage` + `system_fingerprint`
- Message roles accept `tool` / `function`
- Docs: `docs/API.md`
- Example: `examples/openai_client_smoke.py`

### Fixed
- **test_dataset contamination test**: no longer fails when GITenberg external corpus is absent (slim checkouts)
- **dataset.py**: reports `external_requested` / `external_docs_loaded` / note when external dir is empty
- **CalculatorTool**: returns clean numeric string instead of stringified dict
- **FilesystemTool**: unwraps `read_sandboxed_file` dict (`ok`/`content`) correctly
- **RAGPipeline**: uses `k=` (not `top_k=`) for `answer_from_documents` and `DocumentStore.search`
- **Planner**: rejects math-looking strings with no digits (e.g. `+ -`)
- **ToolCallingAgent**: always returns string `content`

### Fixed — missing top-level model.py / tools.py
- Restored **compatibility shims** `model.py` and `tools.py` so classic paths exist again
- Implementations remain in `model_numpy_legacy.py` / `tools_legacy.py`
- Active API is the packages `model/` and `tools/` (Python imports the packages)
- Docs/scripts that `ls model.py` or open those paths no longer fail

### Research-driven improvements (2026-09-17)
- Documented architecture alignment with modern small-LLM stack (`docs/RESEARCH_NOTES.md`)
- `ToolRegistry.openai_tools()` — OpenAI Chat Completions tool schema format
- `GET /v2/tools` — list tools for clients / agents
- Multi-step tool loop: planner → execute → observations (app executes tools, not the model)
- `export/checkpoint_export.py` — portable checkpoint package + honest GGUF path notes

### Improved (more fixes)
- **generate.py**: no longer hard-codes d_model=64; loads architecture from checkpoint metadata / preset; CLI flags for prompt, sampling, checkpoint
- **api.py** fallback: uses `get_preset("development")` instead of hard-coded dims
- **train.py** `MODEL_CONFIGS`: added `development`, `orbit_tiny` (d=128/GQA-4) with naming notes vs YAML presets
- **data/prepare.py**: write train/val text + report.json from build_corpus
- Web search result line formatting when URL is empty

### Feature — live web search
- `tools/web.py`: **DuckDuckGoSearchProvider** (HTML + Instant Answer, no API key)
- **AutoSearchProvider**: live search with honest stub fallback on failure
- **WebFetchTool**: fetch readable text from public URLs
- `MockSearchProvider` / **ResearchAgent**: use live results when available
- Agent / tool paths: `web.search`, `search: <query>`, ResearchAgent routing

### Continued improvements
- **memory.add / memory.search** tools (shared SQLite-backed MemoryManager)
- Planner intents: "remember that…", "recall…", "search memory"
- **test_web.py** — stub, schema, live/auto search shape tests
- **POST /v2/search** — HTTP web search endpoint
- **CLI** `python -m orbit search "query"`

### Research-driven improvements (round 2)
- **monitoring/** — `record_generation` writes real tok/s to `logs/metrics.jsonl`
- **evaluation/bench_generate.py** — multi-run generation throughput (measured ~110–160 tok/s on this host for 913k model)
- Tool output capped at **4000 chars** (agent context efficiency)
- Richer tool descriptions for calculator + web.search
- `ToolCallingAgent.execute_parallel` helper for multi-tool plans
- Research notes: KV-cache deferred with rationale; agent tool design checklist
