"""
Tests for model.py: shape correctness, config validation, and the NaN/Inf
guards added in this pass. Complements test_autograd.py, which already
checks the underlying gradient ops numerically — these tests check the
model built on top of them, not the autograd primitives themselves.
"""
import numpy as np
import pytest

from model import TinyLM, check_finite


def test_forward_shape():
    m = TinyLM(vocab_size=40, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    x = np.random.default_rng(0).integers(0, 40, size=(3, 8))
    out = m(x)
    assert out.data.shape == (3 * 8, 40)


def test_forward_backward_finite():
    m = TinyLM(vocab_size=30, d_model=16, n_layers=1, n_heads=2, n_kv_heads=1, max_seq_len=6, seed=1)
    x = np.random.default_rng(1).integers(0, 30, size=(2, 6))
    out = m(x)
    loss = out.sum()
    loss.backward()
    for p in m.params():
        assert p.grad is not None
        assert np.all(np.isfinite(p.grad))


def test_recursive_reasoning_variant_runs():
    m = TinyLM(vocab_size=20, d_model=8, n_layers=1, n_heads=2, n_kv_heads=1,
               max_seq_len=4, use_recursive_reasoning=True, n_sup=2, seed=2)
    x = np.random.default_rng(2).integers(0, 20, size=(1, 4))
    out = m(x)
    assert out.data.shape == (4, 20)
    out.sum().backward()


@pytest.mark.parametrize("kwargs", [
    dict(vocab_size=10, d_model=15, n_heads=4, n_kv_heads=2, max_seq_len=4),   # d_model % n_heads != 0
    dict(vocab_size=10, d_model=16, n_heads=4, n_kv_heads=3, max_seq_len=4),   # n_heads % n_kv_heads != 0
    dict(vocab_size=10, d_model=16, n_heads=2, n_kv_heads=4, max_seq_len=4),   # n_kv_heads > n_heads
    dict(vocab_size=0, d_model=16, n_heads=2, n_kv_heads=2, max_seq_len=4),    # vocab_size <= 0
    dict(vocab_size=10, d_model=16, n_heads=2, n_kv_heads=2, max_seq_len=0),   # max_seq_len <= 0
])
def test_invalid_configs_rejected(kwargs):
    with pytest.raises(ValueError):
        TinyLM(**kwargs)


def test_sequence_too_long_rejected():
    m = TinyLM(vocab_size=10, d_model=8, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    with pytest.raises(ValueError):
        m(np.zeros((1, 10), dtype=int))


def test_out_of_range_token_id_rejected():
    m = TinyLM(vocab_size=10, d_model=8, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    with pytest.raises(ValueError):
        m(np.array([[0, 1, 2, 999]]))


def test_check_finite_raises_on_nan():
    with pytest.raises(FloatingPointError):
        check_finite(np.array([1.0, np.nan]), "test_tensor")


def test_check_finite_raises_on_inf():
    with pytest.raises(FloatingPointError):
        check_finite(np.array([1.0, np.inf]), "test_tensor")


def test_check_finite_passes_on_clean_data():
    check_finite(np.array([1.0, 2.0, -3.5]), "test_tensor")  # should not raise


def test_param_count_matches_manual_sum():
    m = TinyLM(vocab_size=25, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    manual = sum(p.data.size for p in m.params())
    assert m.param_count() == manual
    assert m.param_count() > 0
