"""Tests for bpe_tokenizer.py: lossless round-trip across English, Filipino/
Ilocano, code, JSON, and arbitrary Unicode; save/load; deterministic
training. Because the base alphabet is raw UTF-8 bytes, round-trip
correctness should hold even for text/vocab combinations never seen during
training — that's the property under test, not memorization."""
import os
import pytest

from bpe_tokenizer import BPETokenizer


@pytest.fixture(scope="module")
def trained_tokenizer():
    corpus = (
        "the quick brown fox jumps over the lazy dog. "
        "a recursive function calls itself until it reaches a base case. "
        "ang pusa ay natutulog sa ibabaw ng mesa. kumusta ka ita nga aldaw. "
        "adda balay mi idiay away. "
        'def foo(x):\n    return x + 1\n{"key": "value", "n": 42}\n'
        "attention is all you need for transformer models."
    )
    return BPETokenizer().train(corpus, vocab_size=400, min_frequency=2)


@pytest.mark.parametrize("text", [
    "hello world",
    "the quick brown fox",
    "ang pusa ay natutulog sa ibabaw ng mesa",       # Tagalog, in training corpus
    "adda balay mi idiay away",                       # Ilocano, in training corpus
    "kumusta ka",                                     # Ilocano, unseen combination
    "def factorial(n):\n    return 1 if n <= 1 else n * factorial(n-1)",
    '{"nested": {"a": [1, 2, 3]}, "flag": true}',
    "emoji test \U0001F600 \U0001F680 and accents: caf\u00e9, na\u00efve",
    "",  # empty string edge case
    "     ",  # whitespace only
    "\t\n\r special whitespace",
])
def test_round_trip_lossless(trained_tokenizer, text):
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    decoded = trained_tokenizer.decode(ids)
    assert decoded == text


def test_round_trip_on_completely_unseen_unicode(trained_tokenizer):
    """Text/scripts never present in training should still round-trip
    losslessly — that's the point of a byte-level base alphabet."""
    text = "\u4e2d\u6587\u6d4b\u8bd5 \u0645\u0631\u062d\u0628\u0627 \u0e2a\u0e27\u0e31\u0e2a\u0e14\u0e35"  # Chinese, Arabic, Thai
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    assert trained_tokenizer.decode(ids) == text


def test_bos_eos_added_by_default(trained_tokenizer):
    ids = trained_tokenizer.encode("hi")
    assert ids[0] == trained_tokenizer.BOS
    assert ids[-1] == trained_tokenizer.EOS


def test_vocab_size_is_configurable():
    corpus = "the quick brown fox jumps over the lazy dog many many times over"
    small = BPETokenizer().train(corpus, vocab_size=270)
    large = BPETokenizer().train(corpus, vocab_size=290)
    assert large.VOCAB_SIZE >= small.VOCAB_SIZE


def test_training_is_deterministic():
    corpus = "the quick brown fox jumps over the lazy dog repeatedly and often"
    tok1 = BPETokenizer().train(corpus, vocab_size=280)
    tok2 = BPETokenizer().train(corpus, vocab_size=280)
    assert tok1.merge_order == tok2.merge_order


def test_compression_vs_byte_level(trained_tokenizer):
    text = "the quick brown fox jumps over the lazy dog"
    ids = trained_tokenizer.encode(text, add_bos=False, add_eos=False)
    byte_len = len(text.encode("utf-8"))
    assert len(ids) <= byte_len  # BPE should never be longer than raw bytes


def test_save_and_load_round_trip(trained_tokenizer, tmp_path):
    path = str(tmp_path / "tok.json")
    trained_tokenizer.save(path)
    assert os.path.exists(path)
    reloaded = BPETokenizer.load(path)
    text = "the quick brown fox and ang pusa"
    assert trained_tokenizer.encode(text) == reloaded.encode(text)
    assert reloaded.VOCAB_SIZE == trained_tokenizer.VOCAB_SIZE


def test_decode_of_empty_id_list(trained_tokenizer):
    assert trained_tokenizer.decode([]) == ""
