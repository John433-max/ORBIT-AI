"""
Generation helpers with full decoding controls.

Supports temperature, top-k, top-p, repetition penalty, max tokens, seed,
stop tokens. KV cache is optional and only used when the model implements it.
"""

from __future__ import annotations

from typing import List, Optional, Sequence

import numpy as np

from sampling import sample_next_token
from model.config import GenerationConfig


def generate(
    model,
    tokenizer,
    prompt: str,
    *,
    max_new_tokens: int = 64,
    temperature: float = 0.8,
    top_k: int = 0,
    top_p: float = 0.9,
    repetition_penalty: float = 1.1,
    seed: Optional[int] = None,
    stop_tokens: Optional[Sequence[str]] = None,
    config: Optional[GenerationConfig] = None,
) -> str:
    """Generate text from prompt; returns full decoded string (prompt + completion)."""
    if config is not None:
        max_new_tokens = config.max_new_tokens
        temperature = config.temperature
        top_k = config.top_k
        top_p = config.top_p
        repetition_penalty = config.repetition_penalty
        seed = config.seed if seed is None else seed
        stop_tokens = config.stop_tokens or stop_tokens

    rng = np.random.default_rng(seed)
    ids: List[int] = list(tokenizer.encode(prompt, add_bos=False, add_eos=False))
    max_seq = getattr(model, "max_seq_len", 128)

    stop_ids: List[List[int]] = []
    if stop_tokens:
        for s in stop_tokens:
            stop_ids.append(list(tokenizer.encode(s, add_bos=False, add_eos=False)))

    for _ in range(max_new_tokens):
        window = ids[-max_seq:]
        logits = model(np.array([window]))
        data = logits.data if hasattr(logits, "data") else logits
        row = data[0, -1] if getattr(data, "ndim", 1) == 3 else data[-1]
        nxt = sample_next_token(
            row,
            ids,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            rng=rng,
        )
        ids.append(int(nxt))
        for seq in stop_ids:
            if len(seq) and ids[-len(seq) :] == seq:
                return tokenizer.decode(ids)
    return tokenizer.decode(ids)


__all__ = ["generate", "sample_next_token", "GenerationConfig"]
