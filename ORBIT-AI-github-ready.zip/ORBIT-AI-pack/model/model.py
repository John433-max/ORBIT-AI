"""
High-level ORBIT language model assembly.

Wraps the educational NumPy/autograd TinyLM and provides a Config-driven
constructor so callers never need to hard-code dimensions.
"""

from __future__ import annotations

from typing import Optional, Union

from .config import ModelConfig, OrbitConfig
from model_numpy_legacy import TinyLM as _TinyLM


class TinyLM(_TinyLM):
    """
    Decoder-only Transformer (RMSNorm, RoPE, GQA, SwiGLU, tied embeddings)
    with optional recursive reasoning module.

    Preferred construction:
        cfg = ModelConfig(...) or OrbitConfig.load("configs/tiny.yaml")
        model = TinyLM.from_config(cfg)
    """

    @classmethod
    def from_config(cls, config: Union[ModelConfig, OrbitConfig], **overrides):
        if isinstance(config, OrbitConfig):
            mc = config.model
        else:
            mc = config
        kwargs = dict(
            vocab_size=mc.vocab_size,
            d_model=mc.d_model,
            n_layers=mc.n_layers,
            n_heads=mc.n_heads,
            n_kv_heads=mc.n_kv_heads,
            d_ff=mc.d_ff,
            max_seq_len=mc.context_length,
            use_recursive_reasoning=mc.use_recursive_reasoning,
            n_sup=mc.n_sup,
            seed=mc.seed,
        )
        kwargs.update(overrides)
        return cls(**kwargs)


# Keep the name expected by the rest of the codebase
__all__ = ["TinyLM"]
