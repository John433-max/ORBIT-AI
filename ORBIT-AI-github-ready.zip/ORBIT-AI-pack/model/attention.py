"""Causal Grouped-Query Attention (GQA)."""

from __future__ import annotations

# Re-export the battle-tested implementation from the educational model.
# This keeps the modular package layout required by ORBIT v2 while
# preserving exact numerical behaviour and gradient correctness.
from model_numpy_legacy import CausalSelfAttentionGQA

__all__ = ["CausalSelfAttentionGQA"]
