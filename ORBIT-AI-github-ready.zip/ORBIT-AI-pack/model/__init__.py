"""
ORBIT model package.

Provides:
- ModelConfig / OrbitConfig (configuration)
- Modular building blocks (embeddings, rope, rmsnorm, attention, swiglu, ...)
- TinyLM (NumPy/autograd educational implementation)
- Re-exports for backward compatibility with the old flat model.py
"""

from .config import (
    ModelConfig,
    TrainingConfig,
    RuntimeConfig,
    DatasetMixConfig,
    OrbitConfig,
    get_preset,
    Config,
)

# Prefer the config-aware wrapper; it subclasses the legacy implementation
# so all existing methods (param_count, params, forward, etc.) remain.
from .model import TinyLM

# Building blocks
from .embeddings import init_token_embeddings, tied_lm_head
from .rope import rope_cos_sin, apply_rope
from .rmsnorm import rmsnorm
from .attention import CausalSelfAttentionGQA
from .swiglu import SwiGLUMLP
from .transformer_block import Block, ReasoningBlock

# Extra helpers still used by tests / training
from model_numpy_legacy import check_finite, init_linear

__all__ = [
    # config
    "ModelConfig",
    "TrainingConfig",
    "RuntimeConfig",
    "DatasetMixConfig",
    "OrbitConfig",
    "get_preset",
    "Config",
    # model
    "TinyLM",
    "CausalSelfAttentionGQA",
    "SwiGLUMLP",
    "Block",
    "ReasoningBlock",
    "rmsnorm",
    "rope_cos_sin",
    "apply_rope",
    "check_finite",
    "init_linear",
    "init_token_embeddings",
    "tied_lm_head",
]
