"""Transformer block = pre-norm Attention + pre-norm SwiGLU + residuals."""

from __future__ import annotations

from model_numpy_legacy import Block, ReasoningBlock

__all__ = ["Block", "ReasoningBlock"]
