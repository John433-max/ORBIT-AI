"""
Smoke-test ORBIT's OpenAI-compatible endpoints with plain urllib (no openai pkg required).

  uvicorn api:app --port 8000
  python examples/openai_client_smoke.py
"""

from __future__ import annotations

import json
import urllib.request

BASE = "http://127.0.0.1:8000"


def post(path: str, payload: dict) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE + path,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get(path: str) -> dict:
    with urllib.request.urlopen(BASE + path, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main():
    models = get("/v1/models")
    print("models:", [m["id"] for m in models.get("data", [])])

    chat = post("/v1/chat/completions", {
        "model": "orbit-toy",
        "messages": [{"role": "user", "content": "what is your name"}],
        "max_tokens": 32,
        "stream": False,
    })
    print("chat:", chat["choices"][0]["message"]["content"][:120])
    print("usage:", chat.get("usage"))

    cmp = post("/v1/completions", {
        "model": "orbit-toy",
        "prompt": "ORBIT stands for",
        "max_tokens": 24,
    })
    print("completion:", cmp["choices"][0]["text"][:120])
    print("usage:", cmp.get("usage"))

    emb = post("/v1/embeddings", {
        "model": "text-embedding-orbit-hash",
        "input": ["hello", "world"],
    })
    print("embeddings:", len(emb["data"]), "dim", len(emb["data"][0]["embedding"]))

    print("OK")


if __name__ == "__main__":
    main()
