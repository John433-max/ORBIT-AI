"""Benchmark + QK-Norm ablation runner."""

from __future__ import annotations

import json

import numpy as np
import torch

from .config import TinyLMConfig
from .eval_harness import nll_numpy, synthetic_copy_batch
from .generate import bench_numpy, bench_torch
from .numpy_model import TinyLMNumPy
from .torch_model import TinyLMTorch
from .generate import bench_torch_compile
from .quantize import (
    quantize_and_eval,
    quantize_and_eval_int4,
    train_then_quant_nll,
    bench_fused_int4,
    eval_packed_vs_dequant,
    bench_packed_int4_decode,
    bench_int4_checkpoint_roundtrip,
    bench_int4_mmap_roundtrip,
    bench_int4_embeddings,
)
from .train import compare_qk_norm, multi_seed_qk_norm, train_rope_context_probe


def main() -> dict:
    cfg = TinyLMConfig(
        vocab_size=64,
        n_layer=4,
        n_embd=64,
        n_head=4,
        block_size=64,
        qk_norm=False,
        residual_init_scale=True,
    )
    np_m = TinyLMNumPy.from_config(cfg, seed=0)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)

    tok_np_full = bench_numpy(np_m, prompt_len=8, n_new=40, use_cache=False)
    tok_np_concat = bench_numpy(np_m, prompt_len=8, n_new=40, use_cache=True, prealloc=False)
    tok_np_cache = bench_numpy(np_m, prompt_len=8, n_new=40, use_cache=True, prealloc=True)
    tok_t_full = bench_torch(t_m, prompt_len=8, n_new=40, use_cache=False)
    tok_t_concat = bench_torch(t_m, prompt_len=8, n_new=40, use_cache=True, prealloc=False)
    tok_t_cache = bench_torch(t_m, prompt_len=8, n_new=40, use_cache=True, prealloc=True)

    long_cfg = TinyLMConfig(
        vocab_size=64,
        n_layer=4,
        n_embd=64,
        n_head=4,
        block_size=256,
        qk_norm=False,
        residual_init_scale=True,
    )
    np_long = TinyLMNumPy.from_config(long_cfg, seed=0)
    t_long = TinyLMTorch.from_config(long_cfg)
    t_long.load_numpy_state(np_long)
    tok_np_long_full = bench_numpy(np_long, prompt_len=8, n_new=200, use_cache=False, warmup=0)
    tok_np_long_cache = bench_numpy(np_long, prompt_len=8, n_new=200, use_cache=True, prealloc=True, warmup=0)
    tok_t_long_full = bench_torch(t_long, prompt_len=8, n_new=200, use_cache=False, warmup=0)
    tok_t_long_cache = bench_torch(t_long, prompt_len=8, n_new=200, use_cache=True, prealloc=True, warmup=0)

    rope_cfg = TinyLMConfig.preset(
        "rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=256
    )
    np_rope = TinyLMNumPy.from_config(rope_cfg, seed=0)
    t_rope = TinyLMTorch.from_config(rope_cfg)
    t_rope.load_numpy_state(np_rope)
    tok_np_rope = bench_numpy(np_rope, prompt_len=8, n_new=40, use_cache=True, prealloc=True)
    tok_t_rope = bench_torch(t_rope, prompt_len=8, n_new=40, use_cache=True, prealloc=True)
    x = np.array([[1, 2, 3, 4, 5]], dtype=np.int64)
    n_log, _ = np_rope.forward(x)
    with torch.no_grad():
        t_log, _ = t_rope.forward(torch.from_numpy(x))
    rope_max_abs = float(np.max(np.abs(n_log - t_log.numpy())))

    yarn_cfg = TinyLMConfig.preset(
        "yarn", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=32
    )
    np_yarn = TinyLMNumPy.from_config(yarn_cfg, seed=0)
    t_yarn = TinyLMTorch.from_config(yarn_cfg)
    t_yarn.load_numpy_state(np_yarn)
    # 48 tokens > train block_size 32, allowed by factor=2
    long_idx = np.arange(48, dtype=np.int64)[None, :] % 64
    y_log, _ = np_yarn.forward(long_idx)
    with torch.no_grad():
        yt_log, _ = t_yarn.forward(torch.from_numpy(long_idx))
    yarn_max_abs = float(np.max(np.abs(y_log - yt_log.numpy())))
    yarn_finite = bool(np.isfinite(y_log).all())
    tok_np_yarn = bench_numpy(np_yarn, prompt_len=8, n_new=40, use_cache=True, prealloc=True)
    tok_t_yarn = bench_torch(t_yarn, prompt_len=8, n_new=40, use_cache=True, prealloc=True)

    tokens = synthetic_copy_batch(cfg.vocab_size, 8, 32, seed=1)
    ev = nll_numpy(np_m, tokens)

    abl = compare_qk_norm(steps=60, lr=2e-2, batch=16, seq=24, seed=1, n_layer=2, n_embd=32)
    multi = multi_seed_qk_norm(seeds=(0, 1, 2), steps=40, lr=3e-2, batch=8, seq=16, n_layer=2, n_embd=32)

    # Cycle 10: torch.compile cached decode + YaRN long-ctx train probe
    rope_cfg_c = TinyLMConfig.preset(
        "rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64
    )
    t_compile = TinyLMTorch.from_config(rope_cfg_c)
    t_compile.load_numpy_state(TinyLMNumPy.from_config(rope_cfg_c, seed=0))
    compile_bench = bench_torch_compile(t_compile, prompt_len=8, n_new=40, warmup=2)

    rope_probe = train_rope_context_probe(
        steps=40, lr=2e-2, batch=12, train_seq=20, block_size=20, long_seq=36,
        seed=2, n_layer=2, n_embd=32, n_head=4, vocab=32,
    )

    out = {
        "numpy_tok_s_full": tok_np_full,
        "numpy_tok_s_concat": tok_np_concat,
        "numpy_tok_s_cache": tok_np_cache,
        "numpy_speedup": tok_np_cache / tok_np_full,
        "torch_tok_s_full": tok_t_full,
        "torch_tok_s_concat": tok_t_concat,
        "torch_tok_s_cache": tok_t_cache,
        "torch_speedup": tok_t_cache / tok_t_full,
        "torch_prealloc_vs_concat": tok_t_cache / tok_t_concat,
        "numpy_tok_s_long_full": tok_np_long_full,
        "numpy_tok_s_long_cache": tok_np_long_cache,
        "numpy_long_speedup": tok_np_long_cache / tok_np_long_full,
        "torch_tok_s_long_full": tok_t_long_full,
        "torch_tok_s_long_cache": tok_t_long_cache,
        "torch_long_speedup": tok_t_long_cache / tok_t_long_full,
        "numpy_tok_s_rope_cache": tok_np_rope,
        "torch_tok_s_rope_cache": tok_t_rope,
        "rope_numpy_torch_max_abs": rope_max_abs,
        "yarn_numpy_torch_max_abs": yarn_max_abs,
        "yarn_long_ctx_finite": yarn_finite,
        "yarn_max_seq": yarn_cfg.max_seq_len(),
        "numpy_tok_s_yarn_cache": tok_np_yarn,
        "torch_tok_s_yarn_cache": tok_t_yarn,
        "untrained_nll": ev.nll,
        "ablation_off_last10": float(np.mean(abl["off"].losses[-10:])),
        "ablation_on_last10": float(np.mean(abl["on"].losses[-10:])),
        "ablation_loss_delta": abl["loss_delta_last10"],
        "ablation_nll_delta": abl["nll_delta"],
        "off_max_qk_param": abl["off"].max_param_qk,
        "on_max_qk_param": abl["on"].max_param_qk,
        "off_logit_end": abl["off_logit_end"],
        "on_logit_end": abl["on_logit_end"],
        "multi_mean_off_logit": multi["mean_off_logit_end"],
        "multi_mean_on_logit": multi["mean_on_logit_end"],
        "multi_mean_nll_delta": multi["mean_nll_delta"],
        "torch_compile_ok": compile_bench["compiled_ok"],
        "torch_compile_error": compile_bench["compile_error"],
        "torch_eager_tok_s": compile_bench["eager_tok_s"],
        "torch_compiled_tok_s": compile_bench["compiled_tok_s"],
        "torch_compile_speedup": compile_bench["speedup"],
        "torch_compile_greedy_match": compile_bench["greedy_match"],
        "rope_probe_plain_short_nll": rope_probe["plain_short_nll"],
        "rope_probe_yarn_short_nll": rope_probe["yarn_short_nll"],
        "rope_probe_yarn_long_nll": rope_probe["yarn_long_nll"],
        "rope_probe_plain_long_allowed": rope_probe["plain_long_allowed"],
        "rope_probe_yarn_max_seq": rope_probe["yarn_max_seq"],
        "int8_compression": quantize_and_eval(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
        ).__dict__,
        "int4_compression": quantize_and_eval_int4(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
            group_size=32,
        ).__dict__,
        "trained_quant_nll": train_then_quant_nll(
            steps=30, lr=2e-2, batch=8, seq=24, seed=0, n_layer=2, n_embd=32
        ).__dict__,
        "fused_int4": bench_fused_int4(
            out_features=256, in_features=256, batch=64, group_size=32, repeats=15, warmup=4
        ).__dict__,
        "packed_vs_dequant": eval_packed_vs_dequant(
            TinyLMConfig.preset("rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32),
            seed=0,
        ).__dict__,
        "packed_decode": bench_packed_int4_decode(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
            prompt_len=8,
            n_new=24,
            warmup=1,
        ).__dict__,
        "int4_checkpoint": bench_int4_checkpoint_roundtrip(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
        ).__dict__,
        "int4_mmap": bench_int4_mmap_roundtrip(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
        ).__dict__,
        "int4_embeddings": bench_int4_embeddings(
            TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64),
            seed=0,
        ).__dict__,
    }
    print(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    main()
