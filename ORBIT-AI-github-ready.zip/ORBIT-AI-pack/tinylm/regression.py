"""Cycle 50: lightweight regression against documented baseline expectations."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from .config import TinyLMConfig
from .generate import generate_numpy, generate_torch, bench_numpy
from .numpy_model import TinyLMNumPy
from .torch_model import TinyLMTorch
import numpy as np
import torch


def run_regression() -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []

    # 1) RoPE parity NumPy↔Torch
    cfg = TinyLMConfig.preset("rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32)
    np_m = TinyLMNumPy.from_config(cfg, seed=7)
    t_m = TinyLMTorch.from_config(cfg)
    t_m.load_numpy_state(np_m)
    x = np.array([[1, 2, 3, 4, 5]], dtype=np.int64)
    n_log, _ = np_m.forward(x)
    with torch.no_grad():
        t_log, _ = t_m.forward(torch.from_numpy(x))
    max_abs = float(np.max(np.abs(n_log - t_log.numpy())))
    checks.append({"name": "rope_numpy_torch_logits", "max_abs": max_abs, "ok": max_abs < 2e-5})

    # 2) GQA parity
    cfg_g = TinyLMConfig.preset("gqa", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32)
    np_g = TinyLMNumPy.from_config(cfg_g, seed=3)
    t_g = TinyLMTorch.from_config(cfg_g)
    t_g.load_numpy_state(np_g)
    n_log, _ = np_g.forward(x)
    with torch.no_grad():
        t_log, _ = t_g.forward(torch.from_numpy(x))
    max_abs = float(np.max(np.abs(n_log - t_log.numpy())))
    checks.append({"name": "gqa_numpy_torch_logits", "max_abs": max_abs, "ok": max_abs < 2e-5})

    # 3) Greedy cache == full
    tokens = generate_numpy(np_m, x, 8, use_cache=True)
    tokens_full = generate_numpy(np_m, x, 8, use_cache=False)
    checks.append(
        {
            "name": "numpy_cache_vs_full_greedy",
            "match": bool(np.array_equal(tokens, tokens_full)),
            "ok": bool(np.array_equal(tokens, tokens_full)),
        }
    )

    # 4) RoPE state_dict has no pos_emb
    sd = t_m.state_dict()
    checks.append(
        {
            "name": "rope_state_dict_no_pos_emb",
            "ok": not any("pos_emb" in k for k in sd.keys()),
        }
    )

    # 5) Cached decode is faster than full (soft: ratio > 1.2 on tiny model)
    cfg_b = TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64)
    m_b = TinyLMNumPy.from_config(cfg_b, seed=0)
    tps_c = bench_numpy(m_b, prompt_len=8, n_new=40, use_cache=True)
    tps_f = bench_numpy(m_b, prompt_len=8, n_new=40, use_cache=False)
    ratio = tps_c / max(tps_f, 1e-9)
    checks.append(
        {
            "name": "cache_speedup",
            "cached_tok_s": tps_c,
            "full_tok_s": tps_f,
            "ratio": ratio,
            "ok": ratio > 1.5,
        }
    )

    # 6) GQA kv heads smaller
    checks.append(
        {
            "name": "gqa_kv_heads",
            "n_kv": cfg_g.n_kv_head,
            "n_head": cfg_g.n_head,
            "ok": cfg_g.n_kv_head < cfg_g.n_head and cfg_g.n_head % cfg_g.n_kv_head == 0,
        }
    )

    all_ok = all(c.get("ok") for c in checks)
    return {"ok": all_ok, "checks": checks}


def main() -> int:
    report = run_regression()
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
