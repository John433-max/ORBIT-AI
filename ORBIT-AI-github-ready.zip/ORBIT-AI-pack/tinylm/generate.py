from __future__ import annotations

import time
from typing import Optional, Sequence

import numpy as np
import torch


def apply_repetition_penalty_np(
    logits: np.ndarray, tokens: Sequence[int], penalty: float
) -> np.ndarray:
    """Cycle 37: down-weight logits of tokens already in the sequence."""
    if penalty is None or abs(penalty - 1.0) < 1e-9 or not len(tokens):
        return logits
    x = logits.astype(np.float64).copy()
    for t in set(int(i) for i in tokens):
        if 0 <= t < x.shape[-1]:
            if x[t] > 0:
                x[t] /= penalty
            else:
                x[t] *= penalty
    return x


def apply_repetition_penalty_torch(
    logits: torch.Tensor, tokens: torch.Tensor, penalty: float
) -> torch.Tensor:
    if penalty is None or abs(penalty - 1.0) < 1e-9 or tokens.numel() == 0:
        return logits
    x = logits.clone()
    for t in torch.unique(tokens):
        ti = int(t.item())
        if x[ti] > 0:
            x[ti] = x[ti] / penalty
        else:
            x[ti] = x[ti] * penalty
    return x


def apply_presence_frequency_np(
    logits: np.ndarray,
    tokens: Sequence[int],
    presence_penalty: float = 0.0,
    frequency_penalty: float = 0.0,
) -> np.ndarray:
    """OpenAI / HF additive penalties on already-seen tokens.

    presence: subtract ``presence_penalty`` once if the token appeared at all.
    frequency: subtract ``frequency_penalty * count`` for each occurrence.
    Zero penalties are a no-op. Counts include the prompt + tokens so far.
    """
    pres = float(presence_penalty or 0.0)
    freq = float(frequency_penalty or 0.0)
    if (pres == 0.0 and freq == 0.0) or not len(tokens):
        return logits
    x = np.asarray(logits, dtype=np.float64).copy()
    counts: dict = {}
    for t in tokens:
        ti = int(t)
        counts[ti] = counts.get(ti, 0) + 1
    v = x.shape[-1]
    for ti, c in counts.items():
        if 0 <= ti < v:
            x[ti] -= pres * (1.0 if c > 0 else 0.0) + freq * float(c)
    return x


def apply_presence_frequency_torch(
    logits: torch.Tensor,
    tokens: torch.Tensor,
    presence_penalty: float = 0.0,
    frequency_penalty: float = 0.0,
) -> torch.Tensor:
    pres = float(presence_penalty or 0.0)
    freq = float(frequency_penalty or 0.0)
    if (pres == 0.0 and freq == 0.0) or tokens.numel() == 0:
        return logits
    x = logits.clone()
    seq = tokens.view(-1).tolist() if hasattr(tokens, "view") else list(tokens)
    counts: dict = {}
    for t in seq:
        ti = int(t)
        counts[ti] = counts.get(ti, 0) + 1
    v = x.shape[-1]
    for ti, c in counts.items():
        if 0 <= ti < v:
            x[ti] = x[ti] - (pres * (1.0 if c > 0 else 0.0) + freq * float(c))
    return x


def apply_min_p_np(logits: np.ndarray, min_p: float) -> np.ndarray:
    """Keep tokens with p >= min_p * p_max (Nguyen et al. / llama.cpp min_p).

    Applied on the current logit row after other warps. min_p<=0 is a no-op.
    The mode token is always kept so the distribution cannot collapse empty.
    """
    if min_p is None or float(min_p) <= 0.0:
        return logits
    x = np.asarray(logits, dtype=np.float64).copy()
    z = x - np.max(x)
    p = np.exp(z)
    p = p / max(p.sum(), 1e-12)
    thresh = float(min_p) * float(p.max())
    drop = p < thresh
    drop[int(np.argmax(p))] = False
    x[drop] = -1e9
    return x


def apply_min_p_torch(logits: torch.Tensor, min_p: float) -> torch.Tensor:
    if min_p is None or float(min_p) <= 0.0:
        return logits
    x = logits.float().clone()
    p = torch.softmax(x, dim=-1)
    thresh = float(min_p) * float(p.max().item())
    drop = p < thresh
    drop[int(torch.argmax(p).item())] = False
    x = x.masked_fill(drop, float("-inf"))
    return x


def apply_typical_p_np(logits: np.ndarray, typical_p: float) -> np.ndarray:
    """Keep the locally-typical mass (Meister et al. 2022 / HF typical_p).

    Tokens are ranked by |−log p − H(p)| and kept until cumulative probability
    reaches ``typical_p``. Values of None / <=0 / >=1 are a no-op. The lowest-
    surprise token is always kept so the support cannot empty.
    """
    if typical_p is None:
        return logits
    mass = float(typical_p)
    if mass <= 0.0 or mass >= 1.0:
        return logits
    x = np.asarray(logits, dtype=np.float64).copy()
    z = x - np.max(x)
    p = np.exp(z)
    p = p / max(p.sum(), 1e-12)
    logp = np.log(np.maximum(p, 1e-12))
    entropy = float(-(p * logp).sum())
    shifted = np.abs(-logp - entropy)
    order = np.argsort(shifted)
    csum = np.cumsum(p[order])
    # include the token that crosses the mass threshold
    last = int(np.searchsorted(csum, mass, side="left"))
    last = min(last, order.size - 1)
    keep = order[: last + 1]
    mask = np.ones(x.shape[-1], dtype=bool)
    mask[keep] = False
    mask[int(order[0])] = False
    x[mask] = -1e9
    return x


def dry_max_match_lengths(
    tokens: Sequence[int],
    last_n: int = 64,
    breaker_ids: Optional[Sequence[int]] = None,
) -> dict:
    """Longest suffix-match length that each next-token would extend.

    For every earlier occurrence of the current last token inside the last
    ``last_n`` tokens, walk backward while tokens stay equal (and are not
    sequence breakers). The token that followed that occurrence is a
    candidate continuation of match length ``k``. ``last_n<=0`` searches
    the full sequence (llama.cpp ``-1`` / ``0`` conventions: we treat
    ``<=0`` as full context here; disable DRY via multiplier=0 instead).
    """
    seq = [int(t) for t in tokens]
    n = len(seq)
    if n < 2:
        return {}
    breakers = {int(b) for b in (breaker_ids or ())}
    window = n if last_n is None or int(last_n) <= 0 else min(n, int(last_n))
    start = n - window
    last = seq[-1]
    if last in breakers:
        return {}
    best: dict = {}
    # Occurrences of `last` in [start, n-1) — exclude the current end token.
    for i in range(start, n - 1):
        if seq[i] != last:
            continue
        k = 1
        while i - k >= start and n - 1 - k >= start:
            prev = seq[i - k]
            cur = seq[n - 1 - k]
            if prev != cur:
                break
            if prev in breakers:
                break
            k += 1
        nxt = seq[i + 1]
        if nxt in breakers:
            continue
        prev_best = best.get(nxt, 0)
        if k > prev_best:
            best[nxt] = k
    return best


def apply_dry_np(
    logits: np.ndarray,
    tokens: Sequence[int],
    multiplier: float = 0.0,
    base: float = 1.75,
    allowed_length: int = 2,
    last_n: int = 64,
    breaker_ids: Optional[Sequence[int]] = None,
) -> np.ndarray:
    """Subtract llama.cpp DRY penalty from logits (p-e-w / Weidmann).

    ``penalty = multiplier * base ** (match_len - allowed_length)`` when
    ``match_len > allowed_length``. ``multiplier<=0`` is a no-op.
    """
    mult = float(multiplier or 0.0)
    if mult <= 0.0:
        return logits
    b = float(base if base and base > 1.0 else 1.75)
    allow = max(0, int(allowed_length or 0))
    matches = dry_max_match_lengths(tokens, last_n=last_n, breaker_ids=breaker_ids)
    if not matches:
        return logits
    x = np.asarray(logits, dtype=np.float64).copy()
    v = x.shape[-1]
    for tok, k in matches.items():
        if k <= allow:
            continue
        if 0 <= int(tok) < v:
            x[int(tok)] -= mult * (b ** (k - allow))
    return x


def apply_dry_torch(
    logits: torch.Tensor,
    tokens,
    multiplier: float = 0.0,
    base: float = 1.75,
    allowed_length: int = 2,
    last_n: int = 64,
    breaker_ids: Optional[Sequence[int]] = None,
) -> torch.Tensor:
    mult = float(multiplier or 0.0)
    if mult <= 0.0:
        return logits
    if hasattr(tokens, "detach"):
        seq = [int(t) for t in tokens.detach().cpu().tolist()]
    else:
        seq = [int(t) for t in tokens]
    b = float(base if base and base > 1.0 else 1.75)
    allow = max(0, int(allowed_length or 0))
    matches = dry_max_match_lengths(seq, last_n=last_n, breaker_ids=breaker_ids)
    if not matches:
        return logits
    x = logits.clone()
    v = x.shape[-1]
    for tok, k in matches.items():
        if k <= allow:
            continue
        if 0 <= int(tok) < v:
            x[int(tok)] = x[int(tok)] - (mult * (b ** (k - allow)))
    return x


def apply_typical_p_torch(logits: torch.Tensor, typical_p: float) -> torch.Tensor:
    if typical_p is None:
        return logits
    mass = float(typical_p)
    if mass <= 0.0 or mass >= 1.0:
        return logits
    x = logits.float().clone()
    p = torch.softmax(x, dim=-1)
    logp = torch.log(p.clamp_min(1e-12))
    entropy = -(p * logp).sum()
    shifted = (-logp - entropy).abs()
    order = torch.argsort(shifted)
    csum = torch.cumsum(p[order], dim=-1)
    last = int(torch.searchsorted(csum, torch.tensor(mass, device=csum.device), right=False).item())
    last = min(last, order.numel() - 1)
    keep = order[: last + 1]
    mask = torch.ones_like(x, dtype=torch.bool)
    mask[keep] = False
    mask[order[0]] = False
    x = x.masked_fill(mask, float("-inf"))
    return x


def apply_xtc_np(
    logits: np.ndarray,
    probability: float,
    threshold: float = 0.1,
    rng: Optional[np.random.Generator] = None,
) -> np.ndarray:
    """XTC — exclude top choices (llama.cpp / SillyTavern).

    With chance ``probability``, drop every token whose softmax mass exceeds
    ``threshold`` except the *least* probable token in that set (so the
    support is never emptied). ``probability<=0`` is a no-op.
    """
    if probability is None or float(probability) <= 0.0:
        return logits
    if threshold is None:
        threshold = 0.1
    thr = float(threshold)
    if thr >= 1.0:
        return logits
    rng = rng or np.random.default_rng()
    if float(rng.random()) >= float(probability):
        return logits
    x = np.asarray(logits, dtype=np.float64)
    z = x - np.max(x)
    p = np.exp(z)
    p = p / p.sum()
    above = p > thr
    n_above = int(above.sum())
    if n_above <= 1:
        return logits
    cand = np.where(above, p, np.inf)
    keep = int(np.argmin(cand))
    out = x.copy()
    drop = above.copy()
    drop[keep] = False
    out[drop] = -1e9
    return out


def apply_xtc_torch(
    logits: torch.Tensor,
    probability: float,
    threshold: float = 0.1,
) -> torch.Tensor:
    if probability is None or float(probability) <= 0.0:
        return logits
    if threshold is None:
        threshold = 0.1
    thr = float(threshold)
    if thr >= 1.0:
        return logits
    if float(torch.rand((), device=logits.device).item()) >= float(probability):
        return logits
    x = logits.float()
    p = torch.softmax(x, dim=-1)
    above = p > thr
    if int(above.sum().item()) <= 1:
        return logits
    cand = torch.where(above, p, torch.full_like(p, float("inf")))
    keep = int(torch.argmin(cand).item())
    out = x.clone()
    drop = above.clone()
    drop[keep] = False
    out = out.masked_fill(drop, float("-inf"))
    return out


def sample_mirostat_v2_np(
    logits: np.ndarray,
    mu: float,
    tau: float = 5.0,
    eta: float = 0.1,
    rng: Optional[np.random.Generator] = None,
):
    """Mirostat 2.0 (Basu et al. 2020 / llama.cpp ``--mirostat 2``).

    Softmax → surprise ``s_i = -log2(p_i)`` → drop tokens with ``s_i > mu``
    → renormalize → sample → ``mu ← mu - eta * (s_obs - tau)``.
    Always keeps the lowest-surprise token so the support cannot empty.
    Returns ``(token_id, new_mu)``.
    """
    rng = rng or np.random.default_rng()
    x = np.asarray(logits, dtype=np.float64)
    z = x - np.max(x)
    p = np.exp(z)
    p = p / max(float(p.sum()), 1e-12)
    surprise = -np.log2(np.maximum(p, 1e-12))
    keep = surprise <= float(mu)
    if not bool(keep.any()):
        keep[int(np.argmin(surprise))] = True
    else:
        keep[int(np.argmin(surprise))] = True
    p2 = np.where(keep, p, 0.0)
    mass = float(p2.sum())
    if mass <= 1e-15:
        p2 = p
        mass = float(p2.sum())
    p2 = p2 / max(mass, 1e-12)
    tok = int(rng.choice(len(p2), p=p2))
    observed = float(-np.log2(max(float(p2[tok]), 1e-12)))
    mu_new = float(mu) - float(eta) * (observed - float(tau))
    return tok, mu_new


def sample_mirostat_v2_torch(
    logits: torch.Tensor,
    mu: float,
    tau: float = 5.0,
    eta: float = 0.1,
):
    x = logits.float()
    p = torch.softmax(x, dim=-1)
    surprise = -torch.log2(p.clamp_min(1e-12))
    keep = surprise <= float(mu)
    lowest = int(torch.argmin(surprise).item())
    keep = keep.clone()
    keep[lowest] = True
    p2 = torch.where(keep, p, torch.zeros_like(p))
    mass = float(p2.sum().item())
    if mass <= 1e-15:
        p2 = p
    else:
        p2 = p2 / p2.sum()
    tok_t = torch.multinomial(p2, num_samples=1).squeeze(-1)
    tok = int(tok_t.item()) if tok_t.ndim == 0 else int(tok_t.view(-1)[0].item())
    observed = float(-torch.log2(p2.view(-1)[tok].clamp_min(1e-12)).item())
    mu_new = float(mu) - float(eta) * (observed - float(tau))
    return tok_t if tok_t.ndim > 0 else torch.tensor(tok, device=logits.device, dtype=torch.long), mu_new


def sample_numpy(
    logits: np.ndarray,
    temperature: float = 0.0,
    top_k: int = 0,
    top_p: float = 1.0,
    min_p: float = 0.0,
    typical_p: float = 1.0,
    xtc_probability: float = 0.0,
    xtc_threshold: float = 0.1,
    rng: Optional[np.random.Generator] = None,
) -> int:
    """Greedy if temperature<=0; else softmax with optional top-k / top-p / min-p / typical-p / XTC."""
    if temperature is None or temperature <= 0:
        return int(np.argmax(logits))
    rng = rng or np.random.default_rng()
    x = logits.astype(np.float64).copy()
    if top_k and top_k > 0 and top_k < x.size:
        thresh = np.partition(x, -top_k)[-top_k]
        x[x < thresh] = -1e9
    if top_p is not None and 0 < top_p < 1.0:
        order = np.argsort(-x)
        sorted_x = x[order]
        sorted_x = sorted_x - sorted_x.max()
        p = np.exp(sorted_x)
        p = p / p.sum()
        cdf = np.cumsum(p)
        cutoff = int(np.searchsorted(cdf, top_p, side="right")) + 1
        keep = order[:cutoff]
        mask = np.ones_like(x, dtype=bool)
        mask[keep] = False
        x[mask] = -1e9
    x = x / float(temperature)
    x = apply_min_p_np(x, min_p)
    x = apply_typical_p_np(x, typical_p)
    x = apply_xtc_np(x, xtc_probability, xtc_threshold, rng=rng)
    x = x - x.max()
    p = np.exp(x)
    p = p / p.sum()
    return int(rng.choice(len(p), p=p))


def sample_torch(
    logits: torch.Tensor,
    temperature: float = 0.0,
    top_k: int = 0,
    top_p: float = 1.0,
    min_p: float = 0.0,
    typical_p: float = 1.0,
    xtc_probability: float = 0.0,
    xtc_threshold: float = 0.1,
) -> torch.Tensor:
    if temperature is None or temperature <= 0:
        return torch.argmax(logits, dim=-1)
    x = logits.float().clone()
    if top_k and top_k > 0 and top_k < x.numel():
        v, _ = torch.topk(x, top_k)
        x[x < v[-1]] = float("-inf")
    if top_p is not None and 0 < top_p < 1.0:
        sorted_logits, sorted_idx = torch.sort(x, descending=True)
        probs = torch.softmax(sorted_logits, dim=-1)
        cdf = torch.cumsum(probs, dim=-1)
        mask = cdf > top_p
        mask[..., 1:] = mask[..., :-1].clone()
        mask[..., 0] = False
        sorted_logits = sorted_logits.masked_fill(mask, float("-inf"))
        x = torch.full_like(x, float("-inf"))
        x.scatter_(0, sorted_idx, sorted_logits)
    x = x / float(temperature)
    x = apply_min_p_torch(x, min_p)
    x = apply_typical_p_torch(x, typical_p)
    x = apply_xtc_torch(x, xtc_probability, xtc_threshold)
    probs = torch.softmax(x, dim=-1)
    return torch.multinomial(probs, num_samples=1).squeeze(-1)


def _stop_set(eos_id, stop_ids):
    s = set()
    if eos_id is not None:
        s.add(int(eos_id))
    if stop_ids:
        for i in stop_ids:
            if i is not None:
                s.add(int(i))
    return s


def banned_ngram_tokens(tokens: Sequence[int], ngram_size: int) -> list:
    """HF-style no_repeat_ngram: tokens that would complete a seen n-gram.

    If the last (n-1) tokens already appeared as a prefix, ban the token that
    previously followed that prefix. ngram_size<=1 disables the rule.
    """
    if ngram_size is None or int(ngram_size) <= 1:
        return []
    n = int(ngram_size)
    seq = [int(t) for t in tokens]
    if len(seq) < n:
        return []
    follow: dict = {}
    for i in range(len(seq) - n + 1):
        prefix = tuple(seq[i : i + n - 1])
        nxt = seq[i + n - 1]
        follow.setdefault(prefix, set()).add(nxt)
    cur = tuple(seq[-(n - 1) :])
    return list(follow.get(cur, ()))


def _ban_ngrams_np(logits: np.ndarray, tokens: Sequence[int], ngram_size: int) -> np.ndarray:
    banned = banned_ngram_tokens(tokens, ngram_size)
    if not banned:
        return logits
    x = np.asarray(logits).copy()
    for t in banned:
        if 0 <= int(t) < x.shape[-1]:
            x[int(t)] = -1e9
    return x


def _ban_ngrams_torch(logits: torch.Tensor, tokens, ngram_size: int) -> torch.Tensor:
    if hasattr(tokens, "tolist"):
        seq = tokens.tolist() if tokens.dim() == 1 else tokens.view(-1).tolist()
    else:
        seq = list(tokens)
    banned = banned_ngram_tokens(seq, ngram_size)
    if not banned:
        return logits
    x = logits.clone()
    for t in banned:
        if 0 <= int(t) < x.shape[-1]:
            x[int(t)] = float("-inf")
    return x


def _mask_stops_np(logits: np.ndarray, stops: set, emitted: int, min_new: int) -> np.ndarray:
    """Cycle 85: hide EOS/stop logits until min_new_tokens have been produced."""
    if not stops or emitted >= min_new:
        return logits
    x = np.asarray(logits).copy()
    for s in stops:
        if 0 <= int(s) < x.shape[-1]:
            x[int(s)] = -1e9
    return x


def _mask_stops_torch(logits, stops: set, emitted: int, min_new: int):
    if not stops or emitted >= min_new:
        return logits
    x = logits.clone()
    for s in stops:
        if 0 <= int(s) < x.shape[-1]:
            x[int(s)] = float("-inf")
    return x


def generate_numpy(
    model,
    idx: np.ndarray,
    n_new: int,
    use_cache: bool = True,
    prealloc: bool = True,
    temperature: float = 0.0,
    top_k: int = 0,
    top_p: float = 1.0,
    repetition_penalty: float = 1.0,
    seed: Optional[int] = None,
    eos_id: Optional[int] = None,
    stop_ids: Optional[Sequence[int]] = None,
    min_new_tokens: int = 0,
    no_repeat_ngram_size: int = 0,
    min_p: float = 0.0,
    presence_penalty: float = 0.0,
    frequency_penalty: float = 0.0,
    typical_p: float = 1.0,
    dry_multiplier: float = 0.0,
    dry_base: float = 1.75,
    dry_allowed_length: int = 2,
    dry_last_n: int = 64,
    dry_breaker_ids: Optional[Sequence[int]] = None,
    mirostat: int = 0,
    mirostat_tau: float = 5.0,
    mirostat_eta: float = 0.1,
    mirostat_mu: Optional[float] = None,
    xtc_probability: float = 0.0,
    xtc_threshold: float = 0.1,
):
    """Decode. temperature<=0 => greedy. idx shape (1, T). Cycle 31/37/69 wiring.

    Cycle 69: optional `eos_id` / `stop_ids` halt after emitting a stop token
    so chat decode does not pad to n_new with leftover garbage.

    Cycle 85: `min_new_tokens` suppresses stop logits and ignores halt until
    that many new tokens have been emitted (HF-style min_new_tokens). Default 0.

    Cycle 86: `no_repeat_ngram_size` bans tokens that would complete an
    already-seen n-gram (HF GenerationConfig.no_repeat_ngram_size). Default 0.

    Cycle 87: `min_p` drops tokens with p < min_p * p_max after temperature
    (Nguyen et al. 2024 / llama.cpp). Default 0 disables. Ignored when greedy.

    Cycle 88: `presence_penalty` / `frequency_penalty` are OpenAI/HF additive
    logit offsets on tokens already in the sequence. Default 0 disables.
    Applied after multiplicative `repetition_penalty`.

    Cycle 89: `typical_p` keeps tokens whose information content is close to
    the distribution entropy (Meister et al. 2022 / HF typical_p). Default 1
    disables. Ignored when greedy.

    Cycle 90: DRY (Don't Repeat Yourself, Weidmann / llama.cpp) subtracts
    ``dry_multiplier * dry_base ** (match_len - dry_allowed_length)`` from
    any token that would extend a verbatim suffix already seen in the last
    ``dry_last_n`` tokens. Default multiplier 0 disables.

    Cycle 91: ``mirostat=2`` selects Mirostat 2.0 (Basu et al. / llama.cpp).
    ``mirostat_tau`` is target surprise (default 5), ``mirostat_eta`` the
    learning rate (default 0.1). ``mu`` starts at ``2 * tau``. Mode 0
    (default) leaves greedy / temperature sampling unchanged.

    Cycle 92: ``xtc_probability`` / ``xtc_threshold`` implement llama.cpp
    XTC (exclude top choices). Probability 0 (default) disables.
    """
    rng = np.random.default_rng(seed)
    caches = None
    tokens = idx.copy()
    stops = _stop_set(eos_id, stop_ids)
    min_new = max(0, int(min_new_tokens or 0))
    ngram_n = max(0, int(no_repeat_ngram_size or 0))
    emitted = 0
    m_mode = int(mirostat or 0)
    m_tau = float(mirostat_tau if mirostat_tau is not None else 5.0)
    m_eta = float(mirostat_eta if mirostat_eta is not None else 0.1)
    mu_state = [float(mirostat_mu) if mirostat_mu is not None else (2.0 * m_tau)]

    def _next(logits_row):
        seq = tokens[0].tolist()
        x = apply_repetition_penalty_np(logits_row, seq, repetition_penalty)
        x = apply_presence_frequency_np(x, seq, presence_penalty, frequency_penalty)
        x = apply_dry_np(
            x,
            seq,
            multiplier=dry_multiplier,
            base=dry_base,
            allowed_length=dry_allowed_length,
            last_n=dry_last_n,
            breaker_ids=dry_breaker_ids,
        )
        x = _ban_ngrams_np(x, seq, ngram_n)
        x = _mask_stops_np(x, stops, emitted, min_new)
        if m_mode == 2:
            xx = np.asarray(x, dtype=np.float64)
            if temperature and float(temperature) > 0:
                xx = xx / float(temperature)
            tok, mu_state[0] = sample_mirostat_v2_np(
                xx, mu_state[0], tau=m_tau, eta=m_eta, rng=rng
            )
            return tok
        return sample_numpy(
            x,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            min_p=min_p,
            typical_p=typical_p,
            xtc_probability=xtc_probability,
            xtc_threshold=xtc_threshold,
            rng=rng,
        )

    def _hit(tok: int) -> bool:
        if emitted < min_new:
            return False
        return bool(stops) and int(tok) in stops

    if use_cache:
        t0 = tokens.shape[1]
        if prealloc:
            caches = model.alloc_kv_caches(tokens.shape[0], t0 + n_new)
            logits, caches = model.forward(tokens, kv_caches=caches, cache_pos=0)
        else:
            logits, caches = model.forward(tokens)
        nxt = _next(logits[0, -1])
        tokens = np.concatenate([tokens, np.array([[nxt]], dtype=tokens.dtype)], axis=1)
        emitted += 1
        if _hit(nxt):
            return tokens
        pos = t0
        for _ in range(n_new - 1):
            if prealloc:
                logits, caches = model.forward(tokens[:, -1:], kv_caches=caches, cache_pos=pos)
            else:
                logits, caches = model.forward(tokens[:, -1:], kv_caches=caches)
            nxt = _next(logits[0, -1])
            tokens = np.concatenate([tokens, np.array([[nxt]], dtype=tokens.dtype)], axis=1)
            emitted += 1
            if _hit(nxt):
                return tokens
            pos += 1
    else:
        for _ in range(n_new):
            logits, _ = model.forward(tokens)
            nxt = _next(logits[0, -1])
            tokens = np.concatenate([tokens, np.array([[nxt]], dtype=tokens.dtype)], axis=1)
            emitted += 1
            if _hit(nxt):
                return tokens
    return tokens


def generate_torch(
    model,
    idx: torch.Tensor,
    n_new: int,
    use_cache: bool = True,
    prealloc: bool = True,
    temperature: float = 0.0,
    top_k: int = 0,
    top_p: float = 1.0,
    repetition_penalty: float = 1.0,
    eos_id: Optional[int] = None,
    stop_ids: Optional[Sequence[int]] = None,
    min_new_tokens: int = 0,
    no_repeat_ngram_size: int = 0,
    min_p: float = 0.0,
    presence_penalty: float = 0.0,
    frequency_penalty: float = 0.0,
    typical_p: float = 1.0,
    dry_multiplier: float = 0.0,
    dry_base: float = 1.75,
    dry_allowed_length: int = 2,
    dry_last_n: int = 64,
    dry_breaker_ids: Optional[Sequence[int]] = None,
    mirostat: int = 0,
    mirostat_tau: float = 5.0,
    mirostat_eta: float = 0.1,
    mirostat_mu: Optional[float] = None,
    xtc_probability: float = 0.0,
    xtc_threshold: float = 0.1,
):
    model.eval()
    tokens = idx.clone()
    stops = _stop_set(eos_id, stop_ids)
    min_new = max(0, int(min_new_tokens or 0))
    ngram_n = max(0, int(no_repeat_ngram_size or 0))
    emitted = 0
    m_mode = int(mirostat or 0)
    m_tau = float(mirostat_tau if mirostat_tau is not None else 5.0)
    m_eta = float(mirostat_eta if mirostat_eta is not None else 0.1)
    mu_state = [float(mirostat_mu) if mirostat_mu is not None else (2.0 * m_tau)]

    def _next(logits_row):
        x = apply_repetition_penalty_torch(logits_row, tokens[0], repetition_penalty)
        x = apply_presence_frequency_torch(x, tokens[0], presence_penalty, frequency_penalty)
        x = apply_dry_torch(
            x,
            tokens[0],
            multiplier=dry_multiplier,
            base=dry_base,
            allowed_length=dry_allowed_length,
            last_n=dry_last_n,
            breaker_ids=dry_breaker_ids,
        )
        x = _ban_ngrams_torch(x, tokens[0], ngram_n)
        x = _mask_stops_torch(x, stops, emitted, min_new)
        if m_mode == 2:
            xx = x.float()
            if temperature and float(temperature) > 0:
                xx = xx / float(temperature)
            tok_t, mu_state[0] = sample_mirostat_v2_torch(
                xx, mu_state[0], tau=m_tau, eta=m_eta
            )
            if tok_t.ndim == 0:
                return tok_t.view(1, 1)
            return tok_t.view(1, 1)
        return sample_torch(
            x,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            min_p=min_p,
            typical_p=typical_p,
            xtc_probability=xtc_probability,
            xtc_threshold=xtc_threshold,
        ).view(1, 1)

    def _hit(tok_t) -> bool:
        if emitted < min_new:
            return False
        return bool(stops) and int(tok_t.view(-1)[0].item()) in stops

    with torch.no_grad():
        if use_cache:
            t0 = tokens.size(1)
            if prealloc:
                caches = model.alloc_kv_caches(tokens.size(0), t0 + n_new, device=tokens.device)
                logits, caches = model.forward(tokens, kv_caches=caches, cache_pos=0)
            else:
                logits, caches = model.forward(tokens)
            nxt = _next(logits[0, -1])
            tokens = torch.cat([tokens, nxt], dim=1)
            emitted += 1
            if _hit(nxt):
                return tokens
            pos = t0
            for _ in range(n_new - 1):
                if prealloc:
                    logits, caches = model.forward(tokens[:, -1:], kv_caches=caches, cache_pos=pos)
                else:
                    logits, caches = model.forward(tokens[:, -1:], kv_caches=caches)
                nxt = _next(logits[0, -1])
                tokens = torch.cat([tokens, nxt], dim=1)
                emitted += 1
                if _hit(nxt):
                    return tokens
                pos += 1
        else:
            for _ in range(n_new):
                logits, _ = model.forward(tokens)
                nxt = _next(logits[0, -1])
                tokens = torch.cat([tokens, nxt], dim=1)
                emitted += 1
                if _hit(nxt):
                    return tokens
    return tokens


def bench_numpy(model, prompt_len=8, n_new=40, use_cache=True, warmup=1, prealloc=True):
    idx = np.arange(prompt_len, dtype=np.int64)[None, :] % model.config.vocab_size
    for _ in range(warmup):
        generate_numpy(model, idx, n_new, use_cache=use_cache, prealloc=prealloc)
    t0 = time.perf_counter()
    generate_numpy(model, idx, n_new, use_cache=use_cache, prealloc=prealloc)
    dt = time.perf_counter() - t0
    return n_new / dt


def bench_torch(model, prompt_len=8, n_new=40, use_cache=True, warmup=1, device="cpu", prealloc=True):
    model = model.to(device)
    idx = torch.arange(prompt_len, device=device)[None, :] % model.config.vocab_size
    for _ in range(warmup):
        generate_torch(model, idx, n_new, use_cache=use_cache, prealloc=prealloc)
    t0 = time.perf_counter()
    generate_torch(model, idx, n_new, use_cache=use_cache, prealloc=prealloc)
    dt = time.perf_counter() - t0
    return n_new / dt


def try_compile_torch(model, mode: str = "reduce-overhead"):
    """Best-effort torch.compile wrapper. Returns (model, compiled: bool, error: str|None)."""
    compile_fn = getattr(torch, "compile", None)
    if compile_fn is None:
        return model, False, "torch.compile unavailable"
    try:
        compiled = compile_fn(model, mode=mode, dynamic=True)
        return compiled, True, None
    except Exception as e:
        return model, False, str(e)


def bench_torch_compile(
    model,
    prompt_len: int = 8,
    n_new: int = 40,
    device: str = "cpu",
    warmup: int = 2,
    prealloc: bool = True,
):
    model = model.to(device)
    model.eval()
    idx = torch.arange(prompt_len, device=device)[None, :] % model.config.vocab_size

    for _ in range(warmup):
        generate_torch(model, idx, n_new, use_cache=True, prealloc=prealloc)
    t0 = time.perf_counter()
    generate_torch(model, idx, n_new, use_cache=True, prealloc=prealloc)
    eager_dt = time.perf_counter() - t0
    eager_tps = n_new / eager_dt

    compiled, ok, err = try_compile_torch(model)
    compiled_tps = None
    match = None
    if ok:
        for _ in range(max(warmup, 3)):
            try:
                generate_torch(compiled, idx, n_new, use_cache=True, prealloc=prealloc)
            except Exception as e:
                ok = False
                err = f"compiled generate failed: {e}"
                break
        if ok:
            t1 = time.perf_counter()
            generate_torch(compiled, idx, n_new, use_cache=True, prealloc=prealloc)
            compiled_dt = time.perf_counter() - t1
            compiled_tps = n_new / compiled_dt
            with torch.no_grad():
                a = generate_torch(model, idx, min(n_new, 12), use_cache=True, prealloc=prealloc)
                b = generate_torch(compiled, idx, min(n_new, 12), use_cache=True, prealloc=prealloc)
            match = bool(torch.equal(a, b))

    return {
        "compiled_ok": ok,
        "compile_error": err,
        "eager_tok_s": eager_tps,
        "compiled_tok_s": compiled_tps,
        "speedup": (compiled_tps / eager_tps) if (ok and compiled_tps) else None,
        "greedy_match": match,
    }
