"""Educational weight-only quantization.

INT8: symmetric absmax, per-output-channel.
INT4: symmetric absmax, group-wise along the input dim (GPTQ/Q4-style teaching).

Stores quantized Linear weights + float scales; dequantizes before matmul.
Not a production kernel — footprint vs fidelity, not fused GEMM speed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import TinyLMConfig
from .torch_model import TinyLMTorch


@dataclass
class QuantStats:
    fp32_bytes: int
    weight_bytes: int
    scale_bytes: int
    compression_ratio: float
    max_abs_logit_err: float
    mean_abs_logit_err: float
    greedy_match_rate: float
    bits: int = 8
    group_size: int = 0

    @property
    def int8_bytes(self) -> int:
        """Alias for Cycle 11 field name."""
        return self.weight_bytes


def _quant_weight_per_channel(w: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """w: (out, in) -> int8 weight, float32 scales (out,)."""
    # per-output-channel absmax
    amax = w.detach().abs().amax(dim=1).clamp(min=1e-8)
    scales = amax / 127.0
    q = torch.round(w.detach() / scales[:, None]).clamp(-127, 127).to(torch.int8)
    return q, scales


def quantize_state_dict_int8(model: TinyLMTorch) -> Dict[str, torch.Tensor]:
    """Return a dict of quantized linear weights + scales (embeddings stay fp32)."""
    out: Dict[str, torch.Tensor] = {}
    with torch.no_grad():
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                q, s = _quant_weight_per_channel(module.weight)
                out[f"{name}.weight_int8"] = q.cpu()
                out[f"{name}.weight_scale"] = s.cpu()
        # keep embeddings + norms in fp32 copies for reconstruction
        out["tok_emb.weight"] = model.tok_emb.weight.detach().cpu().clone()
        if model.pos_emb is not None:
            out["pos_emb.weight"] = model.pos_emb.weight.detach().cpu().clone()
        out["ln_f_w"] = model.ln_f_w.detach().cpu().clone()
        for i, layer in enumerate(model.layers):
            out[f"layers.{i}.ln1_w"] = layer.ln1_w.detach().cpu().clone()
            out[f"layers.{i}.ln2_w"] = layer.ln2_w.detach().cpu().clone()
            out[f"layers.{i}.q_norm"] = layer.q_norm.detach().cpu().clone()
            out[f"layers.{i}.k_norm"] = layer.k_norm.detach().cpu().clone()
    return out


def load_int8_into_model(model: TinyLMTorch, qsd: Dict[str, torch.Tensor]) -> None:
    """Dequantize int8 weights into a model (in-place) for inference."""
    with torch.no_grad():
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                q = qsd[f"{name}.weight_int8"].to(module.weight.device)
                s = qsd[f"{name}.weight_scale"].to(module.weight.device)
                module.weight.copy_(q.float() * s[:, None])
        model.tok_emb.weight.copy_(qsd["tok_emb.weight"].to(model.tok_emb.weight.device))
        if model.pos_emb is not None and "pos_emb.weight" in qsd:
            model.pos_emb.weight.copy_(qsd["pos_emb.weight"].to(model.pos_emb.weight.device))
        model.ln_f_w.copy_(qsd["ln_f_w"].to(model.ln_f_w.device))
        for i, layer in enumerate(model.layers):
            layer.ln1_w.copy_(qsd[f"layers.{i}.ln1_w"].to(layer.ln1_w.device))
            layer.ln2_w.copy_(qsd[f"layers.{i}.ln2_w"].to(layer.ln2_w.device))
            layer.q_norm.copy_(qsd[f"layers.{i}.q_norm"].to(layer.q_norm.device))
            layer.k_norm.copy_(qsd[f"layers.{i}.k_norm"].to(layer.k_norm.device))


def measure_int8_footprint(model: TinyLMTorch) -> Tuple[int, int, int]:
    """fp32 linear bytes, int8 weight bytes, scale bytes."""
    fp32 = 0
    int8 = 0
    scales = 0
    for module in model.modules():
        if isinstance(module, nn.Linear):
            n = module.weight.numel()
            fp32 += n * 4
            int8 += n * 1
            scales += module.weight.shape[0] * 4  # per-out channel
    return fp32, int8, scales


@torch.no_grad()
def eval_quant_error(model_fp: TinyLMTorch, model_q: TinyLMTorch, seq: int = 16, n: int = 8) -> QuantStats:
    fp32, i8, sc = measure_int8_footprint(model_fp)
    errs = []
    matches = 0
    total = 0
    for seed in range(n):
        torch.manual_seed(seed)
        x = torch.randint(0, model_fp.config.vocab_size, (1, seq))
        log_fp, _ = model_fp.forward(x)
        log_q, _ = model_q.forward(x)
        errs.append((log_fp - log_q).abs())
        # greedy one-step match rate over positions
        pred_fp = log_fp[0].argmax(dim=-1)
        pred_q = log_q[0].argmax(dim=-1)
        matches += int((pred_fp == pred_q).sum().item())
        total += seq
    stacked = torch.cat([e.reshape(-1) for e in errs])
    return QuantStats(
        fp32_bytes=fp32,
        weight_bytes=i8,
        scale_bytes=sc,
        compression_ratio=fp32 / max(i8 + sc, 1),
        max_abs_logit_err=float(stacked.max()),
        mean_abs_logit_err=float(stacked.mean()),
        greedy_match_rate=matches / max(total, 1),
        bits=8,
        group_size=0,
    )


def quantize_and_eval(cfg: TinyLMConfig | None = None, seed: int = 0) -> QuantStats:
    cfg = cfg or TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64)
    torch.manual_seed(seed)
    fp = TinyLMTorch.from_config(cfg)
    qsd = quantize_state_dict_int8(fp)
    qmodel = TinyLMTorch.from_config(cfg)
    load_int8_into_model(qmodel, qsd)
    return eval_quant_error(fp, qmodel)


# ---------------------------------------------------------------------------
# INT4 group-wise (educational Q4)
# ---------------------------------------------------------------------------

INT4_QMAX = 7  # symmetric range [-7, 7] so 0 is representable


def _pad_in_features(w: torch.Tensor, group_size: int) -> Tuple[torch.Tensor, int]:
    """Pad input dim so it divides group_size. Returns padded (out, in_pad), orig_in."""
    out, inn = w.shape
    if inn % group_size == 0:
        return w, inn
    pad = group_size - (inn % group_size)
    return torch.nn.functional.pad(w, (0, pad)), inn


def _quant_weight_int4_group(
    w: torch.Tensor, group_size: int = 32
) -> Tuple[torch.Tensor, torch.Tensor, int]:
    """w: (out, in) -> packed uint8 (out, in_pad/2), scales (out, n_groups), orig_in.

    Two signed 4-bit codes packed per byte: low nibble = even col, high = odd col.
    Codes live in [0, 14] representing values [-7, 7] (code = q + 7).
    """
    wp, orig_in = _pad_in_features(w.detach(), group_size)
    out, inn = wp.shape
    n_groups = inn // group_size
    g = wp.view(out, n_groups, group_size)
    amax = g.abs().amax(dim=-1).clamp(min=1e-8)  # (out, n_groups)
    scales = amax / float(INT4_QMAX)
    q = torch.round(g / scales.unsqueeze(-1)).clamp(-INT4_QMAX, INT4_QMAX).to(torch.int8)
    q = q.view(out, inn)
    # pack: even + odd columns
    even = (q[:, 0::2] + INT4_QMAX).to(torch.uint8)
    odd = (q[:, 1::2] + INT4_QMAX).to(torch.uint8)
    packed = even | (odd << 4)
    return packed.contiguous(), scales.contiguous(), orig_in


def _dequant_weight_int4_group(
    packed: torch.Tensor, scales: torch.Tensor, orig_in: int, group_size: int
) -> torch.Tensor:
    out, packed_in = packed.shape
    inn = packed_in * 2
    even = (packed & 0x0F).to(torch.int16) - INT4_QMAX
    odd = ((packed >> 4) & 0x0F).to(torch.int16) - INT4_QMAX
    q = torch.empty(out, inn, dtype=torch.float32, device=packed.device)
    q[:, 0::2] = even.float()
    q[:, 1::2] = odd.float()
    n_groups = inn // group_size
    qg = q.view(out, n_groups, group_size)
    w = qg * scales.to(q.device).unsqueeze(-1)
    return w.view(out, inn)[:, :orig_in]


def quantize_state_dict_int4(model: TinyLMTorch, group_size: int = 32) -> Dict[str, torch.Tensor]:
    out: Dict[str, torch.Tensor] = {"_group_size": torch.tensor(group_size)}
    with torch.no_grad():
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                packed, scales, orig_in = _quant_weight_int4_group(module.weight, group_size)
                out[f"{name}.weight_int4"] = packed.cpu()
                out[f"{name}.weight_scale"] = scales.cpu()
                out[f"{name}.orig_in"] = torch.tensor(orig_in)
        out["tok_emb.weight"] = model.tok_emb.weight.detach().cpu().clone()
        if model.pos_emb is not None:
            out["pos_emb.weight"] = model.pos_emb.weight.detach().cpu().clone()
        out["ln_f_w"] = model.ln_f_w.detach().cpu().clone()
        for i, layer in enumerate(model.layers):
            out[f"layers.{i}.ln1_w"] = layer.ln1_w.detach().cpu().clone()
            out[f"layers.{i}.ln2_w"] = layer.ln2_w.detach().cpu().clone()
            out[f"layers.{i}.q_norm"] = layer.q_norm.detach().cpu().clone()
            out[f"layers.{i}.k_norm"] = layer.k_norm.detach().cpu().clone()
    return out


def load_int4_into_model(model: TinyLMTorch, qsd: Dict[str, torch.Tensor]) -> None:
    group_size = int(qsd["_group_size"].item())
    with torch.no_grad():
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                packed = qsd[f"{name}.weight_int4"].to(module.weight.device)
                scales = qsd[f"{name}.weight_scale"].to(module.weight.device)
                orig_in = int(qsd[f"{name}.orig_in"].item())
                w = _dequant_weight_int4_group(packed, scales, orig_in, group_size)
                module.weight.copy_(w.to(module.weight.dtype))
        model.tok_emb.weight.copy_(qsd["tok_emb.weight"].to(model.tok_emb.weight.device))
        if model.pos_emb is not None and "pos_emb.weight" in qsd:
            model.pos_emb.weight.copy_(qsd["pos_emb.weight"].to(model.pos_emb.weight.device))
        model.ln_f_w.copy_(qsd["ln_f_w"].to(model.ln_f_w.device))
        for i, layer in enumerate(model.layers):
            layer.ln1_w.copy_(qsd[f"layers.{i}.ln1_w"].to(layer.ln1_w.device))
            layer.ln2_w.copy_(qsd[f"layers.{i}.ln2_w"].to(layer.ln2_w.device))
            layer.q_norm.copy_(qsd[f"layers.{i}.q_norm"].to(layer.q_norm.device))
            layer.k_norm.copy_(qsd[f"layers.{i}.k_norm"].to(layer.k_norm.device))


def measure_int4_footprint(model: TinyLMTorch, group_size: int = 32) -> Tuple[int, int, int]:
    """fp32 linear bytes, packed int4 bytes, scale bytes."""
    fp32 = 0
    packed = 0
    scales = 0
    for module in model.modules():
        if isinstance(module, nn.Linear):
            out, inn = module.weight.shape
            inn_pad = inn if inn % group_size == 0 else inn + (group_size - inn % group_size)
            n_groups = inn_pad // group_size
            fp32 += out * inn * 4
            packed += out * (inn_pad // 2)  # two 4-bit values per byte
            scales += out * n_groups * 4
    return fp32, packed, scales


@torch.no_grad()
def eval_quant_error_int4(
    model_fp: TinyLMTorch,
    model_q: TinyLMTorch,
    group_size: int = 32,
    seq: int = 16,
    n: int = 8,
) -> QuantStats:
    fp32, wbytes, sc = measure_int4_footprint(model_fp, group_size)
    errs = []
    matches = 0
    total = 0
    for seed in range(n):
        torch.manual_seed(seed)
        x = torch.randint(0, model_fp.config.vocab_size, (1, seq))
        log_fp, _ = model_fp.forward(x)
        log_q, _ = model_q.forward(x)
        errs.append((log_fp - log_q).abs())
        pred_fp = log_fp[0].argmax(dim=-1)
        pred_q = log_q[0].argmax(dim=-1)
        matches += int((pred_fp == pred_q).sum().item())
        total += seq
    stacked = torch.cat([e.reshape(-1) for e in errs])
    return QuantStats(
        fp32_bytes=fp32,
        weight_bytes=wbytes,
        scale_bytes=sc,
        compression_ratio=fp32 / max(wbytes + sc, 1),
        max_abs_logit_err=float(stacked.max()),
        mean_abs_logit_err=float(stacked.mean()),
        greedy_match_rate=matches / max(total, 1),
        bits=4,
        group_size=group_size,
    )


def quantize_and_eval_int4(
    cfg: TinyLMConfig | None = None, seed: int = 0, group_size: int = 32
) -> QuantStats:
    cfg = cfg or TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64)
    torch.manual_seed(seed)
    fp = TinyLMTorch.from_config(cfg)
    qsd = quantize_state_dict_int4(fp, group_size=group_size)
    qmodel = TinyLMTorch.from_config(cfg)
    load_int4_into_model(qmodel, qsd)
    return eval_quant_error_int4(fp, qmodel, group_size=group_size)


def _roundtrip_int4(w: torch.Tensor, group_size: int = 32) -> torch.Tensor:
    packed, scales, orig_in = _quant_weight_int4_group(w, group_size)
    return _dequant_weight_int4_group(packed, scales, orig_in, group_size)


@dataclass
class QuantNLLResult:
    """NLL/PPL of a trained FP32 checkpoint vs INT8 / INT4 dequant inference."""

    fp32_nll: float
    fp32_ppl: float
    int8_nll: float
    int8_ppl: float
    int4_nll: float
    int4_ppl: float
    int8_dnll: float
    int4_dnll: float
    int8_compression: float
    int4_compression: float
    steps: int
    tokens: int


def _clone_cfg_model(src: TinyLMTorch) -> TinyLMTorch:
    dst = TinyLMTorch.from_config(src.config)
    dst.load_state_dict(src.state_dict())
    dst.eval()
    return dst


@torch.no_grad()
def nll_of(model: TinyLMTorch, tokens: torch.Tensor) -> tuple[float, float, int]:
    from .eval_harness import nll_torch

    ev = nll_torch(model, tokens)
    return ev.nll, ev.ppl, ev.tokens


def train_then_quant_nll(
    steps: int = 40,
    lr: float = 2e-2,
    batch: int = 8,
    seq: int = 24,
    seed: int = 0,
    n_layer: int = 2,
    n_embd: int = 32,
    n_head: int = 4,
    vocab: int = 32,
    group_size: int = 32,
) -> QuantNLLResult:
    """Train a tiny LM, then measure teacher-forced NLL after INT8 and INT4 WOQ.

    Cycle 11–12 measured untrained logit error. This probe asks whether
    quantization preserves *learned* next-token likelihood on the same
    synthetic copy+motif task used by the ablation trainer.
    """
    from .eval_harness import synthetic_copy_batch

    torch.manual_seed(seed)
    np.random.seed(seed)
    cfg = TinyLMConfig(
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=seq,
        qk_norm=True,
        residual_init_scale=True,
        use_rope=True,
    )
    model = TinyLMTorch.from_config(cfg)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95), weight_decay=0.01)
    model.train()
    for step in range(steps):
        data = synthetic_copy_batch(vocab, batch, seq, seed=step + seed)
        data[:, 1::2] = (data[:, 0::2] + 1) % vocab
        x = torch.from_numpy(data)
        logits, _ = model.forward(x[:, :-1])
        loss = F.cross_entropy(logits.reshape(-1, vocab), x[:, 1:].reshape(-1))
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
    model.eval()

    eval_tok = torch.from_numpy(synthetic_copy_batch(vocab, 32, seq, seed=9999))
    # same motif as train so NLL is on-distribution
    ev_np = eval_tok.numpy()
    ev_np[:, 1::2] = (ev_np[:, 0::2] + 1) % vocab
    eval_tok = torch.from_numpy(ev_np)

    fp_nll, fp_ppl, ntok = nll_of(model, eval_tok)

    m8 = _clone_cfg_model(model)
    load_int8_into_model(m8, quantize_state_dict_int8(model))
    i8_nll, i8_ppl, _ = nll_of(m8, eval_tok)
    s8 = eval_quant_error(model, m8)

    m4 = _clone_cfg_model(model)
    load_int4_into_model(m4, quantize_state_dict_int4(model, group_size=group_size))
    i4_nll, i4_ppl, _ = nll_of(m4, eval_tok)
    s4 = eval_quant_error_int4(model, m4, group_size=group_size)

    return QuantNLLResult(
        fp32_nll=fp_nll,
        fp32_ppl=fp_ppl,
        int8_nll=i8_nll,
        int8_ppl=i8_ppl,
        int4_nll=i4_nll,
        int4_ppl=i4_ppl,
        int8_dnll=i8_nll - fp_nll,
        int4_dnll=i4_nll - fp_nll,
        int8_compression=s8.compression_ratio,
        int4_compression=s4.compression_ratio,
        steps=steps,
        tokens=ntok,
    )


# ---------------------------------------------------------------------------
# Fused INT4 GEMM (no full FP32 weight materialization)
# ---------------------------------------------------------------------------
#
# Cycle 11–13 dequantize packed weights into nn.Linear then call F.linear.
# That measures *fidelity* but not *compute*: the GEMM is still FP32×FP32.
#
# int4_linear unpacks + scales from packed storage then BLAS-GEMMs.
# Persistent footprint stays packed; scratch W is ephemeral.
# Group-einsum was measured slower than dequant+F.linear on CPU (~0.15x).


def int4_linear(
    x: torch.Tensor,
    packed: torch.Tensor,
    scales: torch.Tensor,
    orig_in: int,
    group_size: int = 32,
) -> torch.Tensor:
    """y = x @ W_int4^T without allocating the full dequantized W.

    x:      (..., in)
    packed: (out, in_pad/2) uint8
    scales: (out, n_groups) float
    """
    *lead, inn = x.shape
    if inn != orig_in:
        raise ValueError(f"x in_features {inn} != orig_in {orig_in}")
    out, packed_in = packed.shape
    inn_pad = packed_in * 2
    n_groups = inn_pad // group_size
    if scales.shape != (out, n_groups):
        raise ValueError(f"scales {tuple(scales.shape)} != {(out, n_groups)}")

    x_flat = x.reshape(-1, inn).to(torch.float32)
    if inn_pad > inn:
        x_flat = F.pad(x_flat, (0, inn_pad - inn))

    even = (packed & 0x0F).to(torch.int16) - INT4_QMAX  # (out, packed_in)
    odd = ((packed >> 4) & 0x0F).to(torch.int16) - INT4_QMAX
    q = torch.empty(out, inn_pad, dtype=torch.float32, device=packed.device)
    q[:, 0::2] = even.float()
    q[:, 1::2] = odd.float()
    q = q.view(out, n_groups, group_size)
    q.mul_(scales.to(dtype=torch.float32, device=q.device).unsqueeze(-1))
    w = q.view(out, inn_pad)[:, :orig_in]
    y = x_flat[:, :orig_in] @ w.T
    return y.view(*lead, out)


def int4_linear_ref(
    x: torch.Tensor,
    packed: torch.Tensor,
    scales: torch.Tensor,
    orig_in: int,
    group_size: int = 32,
) -> torch.Tensor:
    """Reference: dequant full W then F.linear."""
    w = _dequant_weight_int4_group(packed, scales, orig_in, group_size)
    return F.linear(x.to(torch.float32), w)


@dataclass
class FusedInt4Bench:
    dequant_ms: float
    fused_ms: float
    speedup: float
    max_abs_err: float
    mean_abs_err: float
    out_features: int
    in_features: int
    batch: int
    group_size: int


@torch.no_grad()
def bench_fused_int4(
    out_features: int = 256,
    in_features: int = 256,
    batch: int = 64,
    group_size: int = 32,
    seed: int = 0,
    repeats: int = 20,
    warmup: int = 5,
) -> FusedInt4Bench:
    """Compare dequant-then-GEMM vs group-fused INT4 linear."""
    import time

    torch.manual_seed(seed)
    w = torch.randn(out_features, in_features)
    packed, scales, orig_in = _quant_weight_int4_group(w, group_size)
    x = torch.randn(batch, in_features)

    ref = int4_linear_ref(x, packed, scales, orig_in, group_size)
    fused = int4_linear(x, packed, scales, orig_in, group_size)
    err = (ref - fused).abs()

    for _ in range(warmup):
        int4_linear_ref(x, packed, scales, orig_in, group_size)
        int4_linear(x, packed, scales, orig_in, group_size)

    t0 = time.perf_counter()
    acc = 0.0
    for _ in range(repeats):
        y = int4_linear_ref(x, packed, scales, orig_in, group_size)
        acc += float(y[0, 0])
    t_ref = (time.perf_counter() - t0) / repeats

    t0 = time.perf_counter()
    acc2 = 0.0
    for _ in range(repeats):
        y = int4_linear(x, packed, scales, orig_in, group_size)
        acc2 += float(y[0, 0])
    t_fused = (time.perf_counter() - t0) / repeats
    _ = acc + acc2

    return FusedInt4Bench(
        dequant_ms=t_ref * 1e3,
        fused_ms=t_fused * 1e3,
        speedup=(t_ref / t_fused) if t_fused > 0 else float("inf"),
        max_abs_err=float(err.max()),
        mean_abs_err=float(err.mean()),
        out_features=out_features,
        in_features=in_features,
        batch=batch,
        group_size=group_size,
    )


# ---------------------------------------------------------------------------
# Packed INT4 TinyLM (replace nn.Linear at inference)
# ---------------------------------------------------------------------------


class Int4Linear(nn.Module):
    """Bias-free linear whose weight stays packed INT4 group-wise.

    Default forward uses ``int4_linear`` (unpack scratch + BLAS) so the
    persistent parameter set is packed uint8 + per-group scales.

    Cycle 16: ``materialize()`` / ``cache_fp32=True`` unpacks W once into
    an optional buffer and then calls ``F.linear``. Packed storage is
    kept by default so the cache can be released.

    Cycle 17: ``materialize(drop_packed=True)`` / ``drop_packed()`` frees
    the uint8 packed buffer after the FP32 cache exists. Scales stay so
    the module can still describe the quantization grid. Default remains
    keep-packed so ``release()`` can return to per-call unpack.
    """

    def __init__(
        self,
        packed: torch.Tensor,
        scales: torch.Tensor,
        orig_in: int,
        group_size: int = 32,
        cache_fp32: bool = False,
    ):
        super().__init__()
        self.register_buffer("packed", packed.contiguous())
        self.register_buffer("scales", scales.contiguous())
        self.orig_in = int(orig_in)
        self.group_size = int(group_size)
        self.out_features = packed.shape[0]
        self.in_features = int(orig_in)
        self._w_cache: torch.Tensor | None = None
        self._packed_dropped = False
        if cache_fp32:
            self.materialize()

    def has_packed(self) -> bool:
        return (not self._packed_dropped) and hasattr(self, "packed") and self.packed is not None

    def materialize(self, drop_packed: bool = False) -> torch.Tensor:
        """Unpack once; later forwards use F.linear on the cached W.

        If ``drop_packed``, free the uint8 packed buffer after the cache
        exists. ``release()`` then cannot restore the unpack path.
        """
        if self._w_cache is None:
            if not self.has_packed():
                raise RuntimeError("Int4Linear.materialize needs packed weights")
            self._w_cache = _dequant_weight_int4_group(
                self.packed, self.scales, self.orig_in, self.group_size
            )
        if drop_packed:
            self.drop_packed()
        return self._w_cache

    def drop_packed(self) -> None:
        """Free packed uint8 storage. Requires an FP32 cache to remain usable."""
        if self._w_cache is None:
            raise RuntimeError("drop_packed requires materialize() first")
        if hasattr(self, "packed"):
            del self.packed
        self._packed_dropped = True

    def release(self) -> None:
        """Drop the FP32 cache; forward returns to per-call unpack if packed remains."""
        if self._packed_dropped or not self.has_packed():
            raise RuntimeError("release() needs packed weights; they were dropped")
        self._w_cache = None

    def cache_bytes(self) -> int:
        if self._w_cache is None:
            return 0
        return int(self._w_cache.numel() * self._w_cache.element_size())

    def packed_storage_bytes(self) -> int:
        if not self.has_packed():
            return 0
        return int(self.packed.numel() * self.packed.element_size())

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self._w_cache is not None:
            return F.linear(x.to(torch.float32), self._w_cache)
        if not self.has_packed():
            raise RuntimeError("Int4Linear has neither packed weights nor an FP32 cache")
        return int4_linear(x, self.packed, self.scales, self.orig_in, self.group_size)


def _set_module(root: nn.Module, dotted: str, new: nn.Module) -> None:
    parts = dotted.split(".")
    parent = root
    for p in parts[:-1]:
        parent = getattr(parent, p) if not p.isdigit() else parent[int(p)]
    name = parts[-1]
    if name.isdigit():
        parent[int(name)] = new
    else:
        setattr(parent, name, new)


class Int4Embedding(nn.Module):
    """Token/position embedding table stored as group-wise packed INT4.

    Table shape is (num_embeddings, emb_dim) — same layout as a Linear
    weight, so packing reuses ``_quant_weight_int4_group``.

    ``.weight`` is a property that returns the dequantized (or cached)
    table so TinyLM's tied LM head ``F.linear(x, self.tok_emb.weight)``
    keeps working without a torch_model change.
    """

    def __init__(
        self,
        packed: torch.Tensor,
        scales: torch.Tensor,
        orig_in: int,
        group_size: int = 32,
        cache_fp32: bool = False,
    ):
        super().__init__()
        self.register_buffer("packed", packed.contiguous())
        self.register_buffer("scales", scales.contiguous())
        self.orig_in = int(orig_in)
        self.group_size = int(group_size)
        self.num_embeddings = packed.shape[0]
        self.embedding_dim = int(orig_in)
        self._w_cache: torch.Tensor | None = None
        self._packed_dropped = False
        if cache_fp32:
            self.materialize()

    def has_packed(self) -> bool:
        return (not self._packed_dropped) and hasattr(self, "packed") and self.packed is not None

    def materialize(self, drop_packed: bool = False) -> torch.Tensor:
        if self._w_cache is None:
            if not self.has_packed():
                raise RuntimeError("Int4Embedding.materialize needs packed weights")
            self._w_cache = _dequant_weight_int4_group(
                self.packed, self.scales, self.orig_in, self.group_size
            )
        if drop_packed:
            self.drop_packed()
        return self._w_cache

    def drop_packed(self) -> None:
        if self._w_cache is None:
            raise RuntimeError("drop_packed requires materialize() first")
        if hasattr(self, "packed"):
            del self.packed
        self._packed_dropped = True

    def release(self) -> None:
        if self._packed_dropped or not self.has_packed():
            raise RuntimeError("release() needs packed weights; they were dropped")
        self._w_cache = None

    def cache_bytes(self) -> int:
        if self._w_cache is None:
            return 0
        return int(self._w_cache.numel() * self._w_cache.element_size())

    def packed_storage_bytes(self) -> int:
        if not self.has_packed():
            return 0
        return int(self.packed.numel() * self.packed.element_size())

    @property
    def weight(self) -> torch.Tensor:
        """Dequantized table for F.embedding / tied F.linear."""
        if self._w_cache is not None:
            return self._w_cache
        if not self.has_packed():
            raise RuntimeError("Int4Embedding has neither packed weights nor an FP32 cache")
        return _dequant_weight_int4_group(
            self.packed, self.scales, self.orig_in, self.group_size
        )

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        return F.embedding(idx, self.weight)


def pack_embeddings_int4(
    model: TinyLMTorch,
    group_size: int = 32,
    cache_fp32: bool = False,
    drop_packed: bool = False,
) -> TinyLMTorch:
    """Replace tok_emb / pos_emb with Int4Embedding. Opt-in (Cycle 20)."""
    device = next(model.parameters()).device
    with torch.no_grad():
        for attr in ("tok_emb", "pos_emb"):
            emb = getattr(model, attr, None)
            if emb is None or isinstance(emb, Int4Embedding):
                continue
            packed, scales, orig_in = _quant_weight_int4_group(emb.weight, group_size)
            layer = Int4Embedding(
                packed.to(device),
                scales.to(device),
                orig_in,
                group_size,
                cache_fp32=cache_fp32,
            )
            if drop_packed:
                layer.materialize(drop_packed=True)
            setattr(model, attr, layer)
    return model


def pack_model_int4(
    model: TinyLMTorch,
    group_size: int = 32,
    cache_fp32: bool = False,
    drop_packed: bool = False,
    quantize_embeddings: bool = False,
) -> TinyLMTorch:
    """Replace every ``nn.Linear`` with ``Int4Linear`` from the model's weights.

    Embeddings and RMSNorm stay FP32 by default. Pass
    ``quantize_embeddings=True`` to pack tok_emb / pos_emb as INT4
    (Cycle 20). In-place; returns the same module.
    ``cache_fp32`` unpacks each layer once (Cycle 16 decode path).
    ``drop_packed`` (Cycle 17) frees uint8 packed buffers after materialize.
    """
    qsd = quantize_state_dict_int4(model, group_size=group_size)
    load_packed_int4_modules(
        model, qsd, cache_fp32=cache_fp32, drop_packed=drop_packed
    )
    if quantize_embeddings:
        pack_embeddings_int4(
            model,
            group_size=group_size,
            cache_fp32=cache_fp32,
            drop_packed=drop_packed,
        )
    return model


def load_packed_int4_modules(
    model: TinyLMTorch,
    qsd: Dict[str, torch.Tensor],
    cache_fp32: bool = False,
    drop_packed: bool = False,
) -> TinyLMTorch:
    """Swap Linear → Int4Linear using a packed state dict. Drop FP32 W."""
    group_size = int(qsd["_group_size"].item())
    device = next(model.parameters()).device
    with torch.no_grad():
        for name, module in list(model.named_modules()):
            if isinstance(module, nn.Linear):
                packed = qsd[f"{name}.weight_int4"].to(device)
                scales = qsd[f"{name}.weight_scale"].to(device)
                orig_in = int(qsd[f"{name}.orig_in"].item())
                layer = Int4Linear(
                    packed, scales, orig_in, group_size, cache_fp32=cache_fp32
                )
                if drop_packed:
                    layer.materialize(drop_packed=True)
                _set_module(model, name, layer)
        for attr in ("tok_emb", "pos_emb"):
            if f"{attr}.weight_int4" in qsd:
                packed = qsd[f"{attr}.weight_int4"].to(device)
                scales = qsd[f"{attr}.weight_scale"].to(device)
                orig_in = int(qsd[f"{attr}.orig_in"].item())
                layer = Int4Embedding(
                    packed, scales, orig_in, group_size, cache_fp32=cache_fp32
                )
                if drop_packed:
                    layer.materialize(drop_packed=True)
                setattr(model, attr, layer)
            elif f"{attr}.weight" in qsd:
                emb = getattr(model, attr, None)
                if emb is not None:
                    emb.weight.copy_(qsd[f"{attr}.weight"].to(device))
        model.ln_f_w.copy_(qsd["ln_f_w"].to(device))
        for i, layer in enumerate(model.layers):
            layer.ln1_w.copy_(qsd[f"layers.{i}.ln1_w"].to(device))
            layer.ln2_w.copy_(qsd[f"layers.{i}.ln2_w"].to(device))
            layer.q_norm.copy_(qsd[f"layers.{i}.q_norm"].to(device))
            layer.k_norm.copy_(qsd[f"layers.{i}.k_norm"].to(device))
    model.eval()
    return model


def packed_int4_linear_bytes(model: nn.Module) -> Tuple[int, int]:
    """(packed+scale bytes on Int4Linear, leftover nn.Linear fp32 bytes)."""
    packed = 0
    leftover = 0
    for m in model.modules():
        if isinstance(m, Int4Linear):
            packed += m.packed_storage_bytes()
            packed += m.scales.numel() * m.scales.element_size()
        elif isinstance(m, nn.Linear):
            leftover += m.weight.numel() * m.weight.element_size()
    return packed, leftover


def packed_int4_embed_bytes(model: nn.Module) -> Tuple[int, int]:
    """(packed+scale on Int4Embedding, leftover nn.Embedding fp32 bytes)."""
    packed = 0
    leftover = 0
    for m in model.modules():
        if isinstance(m, Int4Embedding):
            packed += m.packed_storage_bytes()
            packed += m.scales.numel() * m.scales.element_size()
        elif isinstance(m, nn.Embedding):
            leftover += m.weight.numel() * m.weight.element_size()
    return packed, leftover


def packed_int4_cache_bytes(model: nn.Module) -> int:
    """Bytes held in optional unpack-once FP32 caches."""
    return sum(
        m.cache_bytes()
        for m in model.modules()
        if isinstance(m, (Int4Linear, Int4Embedding))
    )


def materialize_int4_model(model: nn.Module, drop_packed: bool = False) -> None:
    for m in model.modules():
        if isinstance(m, (Int4Linear, Int4Embedding)):
            m.materialize(drop_packed=drop_packed)


def drop_packed_int4_storage(model: nn.Module) -> None:
    """Free uint8 packed buffers after materialize (Cycle 17)."""
    for m in model.modules():
        if isinstance(m, (Int4Linear, Int4Embedding)):
            m.drop_packed()


def release_int4_model(model: nn.Module) -> None:
    for m in model.modules():
        if isinstance(m, (Int4Linear, Int4Embedding)):
            m.release()


@torch.no_grad()
def eval_packed_vs_dequant(
    cfg: TinyLMConfig | None = None,
    seed: int = 0,
    group_size: int = 32,
    seq: int = 16,
    n: int = 4,
) -> QuantStats:
    """Logit error: packed Int4Linear path vs dequant-into-Linear path (same qsd)."""
    cfg = cfg or TinyLMConfig.preset("rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32)
    torch.manual_seed(seed)
    fp = TinyLMTorch.from_config(cfg)
    qsd = quantize_state_dict_int4(fp, group_size=group_size)

    deq = TinyLMTorch.from_config(cfg)
    load_int4_into_model(deq, qsd)
    deq.eval()

    packed = TinyLMTorch.from_config(cfg)
    load_packed_int4_modules(packed, qsd)
    packed.eval()

    errs = []
    matches = 0
    total = 0
    for s in range(n):
        torch.manual_seed(100 + s)
        x = torch.randint(0, cfg.vocab_size, (1, seq))
        log_d, _ = deq.forward(x)
        log_p, _ = packed.forward(x)
        errs.append((log_d - log_p).abs())
        matches += int((log_d[0].argmax(-1) == log_p[0].argmax(-1)).sum().item())
        total += seq
    stacked = torch.cat([e.reshape(-1) for e in errs])
    fp32, wbytes, sc = measure_int4_footprint(fp, group_size)
    return QuantStats(
        fp32_bytes=fp32,
        weight_bytes=wbytes,
        scale_bytes=sc,
        compression_ratio=fp32 / max(wbytes + sc, 1),
        max_abs_logit_err=float(stacked.max()),
        mean_abs_logit_err=float(stacked.mean()),
        greedy_match_rate=matches / max(total, 1),
        bits=4,
        group_size=group_size,
    )


@dataclass
class PackedDecodeBench:
    dequant_tok_s: float
    packed_tok_s: float
    speedup: float
    greedy_match: float
    leftover_linear_bytes: int
    packed_weight_bytes: int
    cached_tok_s: float = 0.0
    cached_speedup_vs_packed: float = 0.0
    cached_speedup_vs_dequant: float = 0.0
    cached_greedy_match: float = 0.0
    cache_bytes: int = 0
    dropped_packed_bytes: int = 0
    dropped_cache_bytes: int = 0
    dropped_greedy_match: float = 0.0
    dropped_tok_s: float = 0.0


@torch.no_grad()
def bench_packed_int4_decode(
    cfg: TinyLMConfig | None = None,
    seed: int = 0,
    prompt_len: int = 8,
    n_new: int = 24,
    warmup: int = 1,
    group_size: int = 32,
) -> PackedDecodeBench:
    """Cached greedy decode: dequant Linear vs packed Int4Linear."""
    import time

    from .generate import generate_torch
    from .numpy_model import TinyLMNumPy

    cfg = cfg or TinyLMConfig.preset("rope", vocab_size=64, n_layer=4, n_embd=64, n_head=4, block_size=64)
    torch.manual_seed(seed)
    src = TinyLMTorch.from_config(cfg)
    src.load_numpy_state(TinyLMNumPy.from_config(cfg, seed=seed))
    qsd = quantize_state_dict_int4(src, group_size=group_size)

    deq = TinyLMTorch.from_config(cfg)
    load_int4_into_model(deq, qsd)
    deq.eval()

    packed = TinyLMTorch.from_config(cfg)
    load_packed_int4_modules(packed, qsd)

    cached = TinyLMTorch.from_config(cfg)
    load_packed_int4_modules(cached, qsd, cache_fp32=True)

    prompt = torch.arange(prompt_len, dtype=torch.long)[None, :]

    def _run(m, reps: int) -> tuple[float, list]:
        last = None
        t0 = time.perf_counter()
        for _ in range(reps):
            last = generate_torch(m, prompt, n_new=n_new, use_cache=True)
        dt = time.perf_counter() - t0
        if reps <= 0:
            last = generate_torch(m, prompt, n_new=n_new, use_cache=True)
            return 0.0, last
        return reps * n_new / dt, last

    dropped = TinyLMTorch.from_config(cfg)
    load_packed_int4_modules(dropped, qsd, cache_fp32=True, drop_packed=True)

    _run(deq, warmup)
    _run(packed, warmup)
    _run(cached, warmup)
    _run(dropped, warmup)
    tok_d, tokens_d = _run(deq, 3)
    tok_p, tokens_p = _run(packed, 3)
    tok_c, tokens_c = _run(cached, 3)
    tok_x, tokens_x = _run(dropped, 3)
    match = float((tokens_d == tokens_p).float().mean()) if tokens_d is not None else 0.0
    match_c = float((tokens_d == tokens_c).float().mean()) if tokens_d is not None else 0.0
    match_x = float((tokens_d == tokens_x).float().mean()) if tokens_d is not None else 0.0
    pb, leftover = packed_int4_linear_bytes(packed)
    drop_b, _ = packed_int4_linear_bytes(dropped)
    return PackedDecodeBench(
        dequant_tok_s=tok_d,
        packed_tok_s=tok_p,
        speedup=tok_p / tok_d if tok_d > 0 else float("inf"),
        greedy_match=match,
        leftover_linear_bytes=leftover,
        packed_weight_bytes=pb,
        cached_tok_s=tok_c,
        cached_speedup_vs_packed=tok_c / tok_p if tok_p > 0 else float("inf"),
        cached_speedup_vs_dequant=tok_c / tok_d if tok_d > 0 else float("inf"),
        cached_greedy_match=match_c,
        cache_bytes=packed_int4_cache_bytes(cached),
        dropped_packed_bytes=drop_b,
        dropped_cache_bytes=packed_int4_cache_bytes(dropped),
        dropped_greedy_match=match_x,
        dropped_tok_s=tok_x,
    )


# ---------------------------------------------------------------------------
# INT4 checkpoint serialize / reload (no original Linear required)
# ---------------------------------------------------------------------------

INT4_CKPT_VERSION = 1


def export_int4_state(
    model: TinyLMTorch,
    *,
    from_cache: bool = False,
) -> Dict[str, torch.Tensor]:
    """Build a packed INT4 state dict from an already-packed TinyLM.

    Does not need the original ``nn.Linear`` weights. Packed uint8 buffers
    are copied from each ``Int4Linear``. If packed storage was dropped,
    pass ``from_cache=True`` to re-quantize the FP32 cache (lossy second
    quantization — exact bit-identity is not guaranteed).
    """
    int4_mods = [(n, m) for n, m in model.named_modules() if isinstance(m, Int4Linear)]
    if not int4_mods:
        # Fall back to quantizing remaining Linears (first-time pack).
        return quantize_state_dict_int4(model)

    group_sizes = {m.group_size for _, m in int4_mods}
    if len(group_sizes) != 1:
        raise ValueError(f"mixed group_size in Int4Linear modules: {group_sizes}")
    group_size = next(iter(group_sizes))
    out: Dict[str, torch.Tensor] = {"_group_size": torch.tensor(group_size)}
    with torch.no_grad():
        for name, module in int4_mods:
            if module.has_packed():
                packed = module.packed.detach().cpu().clone()
                scales = module.scales.detach().cpu().clone()
                orig_in = module.orig_in
            elif from_cache and module._w_cache is not None:
                packed, scales, orig_in = _quant_weight_int4_group(
                    module._w_cache, group_size
                )
                packed = packed.cpu()
                scales = scales.cpu()
            else:
                raise RuntimeError(
                    f"{name}: packed weights dropped; export with from_cache=True "
                    "to re-quantize the FP32 cache"
                )
            out[f"{name}.weight_int4"] = packed
            out[f"{name}.weight_scale"] = scales
            out[f"{name}.orig_in"] = torch.tensor(int(orig_in))
        for attr in ("tok_emb", "pos_emb"):
            emb = getattr(model, attr, None)
            if emb is None:
                continue
            if isinstance(emb, Int4Embedding):
                if emb.has_packed():
                    packed = emb.packed.detach().cpu().clone()
                    scales = emb.scales.detach().cpu().clone()
                    orig_in = emb.orig_in
                elif from_cache and emb._w_cache is not None:
                    packed, scales, orig_in = _quant_weight_int4_group(
                        emb._w_cache, group_size
                    )
                    packed = packed.cpu()
                    scales = scales.cpu()
                else:
                    raise RuntimeError(
                        f"{attr}: packed embeddings dropped; export with from_cache=True"
                    )
                out[f"{attr}.weight_int4"] = packed
                out[f"{attr}.weight_scale"] = scales
                out[f"{attr}.orig_in"] = torch.tensor(int(orig_in))
            else:
                out[f"{attr}.weight"] = emb.weight.detach().cpu().clone()
        out["ln_f_w"] = model.ln_f_w.detach().cpu().clone()
        for i, layer in enumerate(model.layers):
            out[f"layers.{i}.ln1_w"] = layer.ln1_w.detach().cpu().clone()
            out[f"layers.{i}.ln2_w"] = layer.ln2_w.detach().cpu().clone()
            out[f"layers.{i}.q_norm"] = layer.q_norm.detach().cpu().clone()
            out[f"layers.{i}.k_norm"] = layer.k_norm.detach().cpu().clone()
    return out


def int4_checkpoint_dict(
    model: TinyLMTorch,
    *,
    from_cache: bool = False,
) -> dict:
    """CPU checkpoint: config + packed INT4 tensors. No FP32 Linear W."""
    qsd = export_int4_state(model, from_cache=from_cache)
    return {
        "format": "orbit.int4",
        "version": INT4_CKPT_VERSION,
        "config": model.config.to_dict(),
        "tensors": qsd,
    }


def save_int4_checkpoint(
    model: TinyLMTorch,
    path: str,
    *,
    from_cache: bool = False,
) -> int:
    """Write an INT4 packed checkpoint. Returns file size in bytes."""
    from pathlib import Path

    payload = int4_checkpoint_dict(model, from_cache=from_cache)
    path = str(path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, path)
    return Path(path).stat().st_size


INT4_MMAP_MAGIC = b"ORBITI4\n"
INT4_MMAP_VERSION = 1
INT4_MMAP_ALIGN = 64


def _dtype_to_code(dt: torch.dtype) -> str:
    if dt == torch.uint8:
        return "u8"
    if dt == torch.float32:
        return "f32"
    if dt == torch.int64:
        return "i64"
    if dt == torch.int32:
        return "i32"
    raise TypeError(f"unsupported mmap dtype {dt}")


def _code_to_numpy(code: str):
    return {"u8": np.uint8, "f32": np.float32, "i64": np.int64, "i32": np.int32}[code]


def _align_up(n: int, align: int = INT4_MMAP_ALIGN) -> int:
    return (n + align - 1) // align * align


def save_int4_mmap(
    model: TinyLMTorch,
    path: str,
    *,
    from_cache: bool = False,
) -> int:
    """Write a pickle-free INT4 checkpoint (JSON header + raw blobs).

    Educational analogue of safetensors / GGUF: length-prefixed JSON
    metadata, then 64-byte-aligned little-endian tensors. Returns size.
    """
    import json
    from pathlib import Path

    qsd = export_int4_state(model, from_cache=from_cache)
    header = {
        "format": "orbit.int4m",
        "version": INT4_MMAP_VERSION,
        "config": model.config.to_dict(),
        "tensors": {},
    }
    blobs: list[tuple[str, bytes]] = []
    offset = 0
    for name in sorted(qsd.keys()):
        t = qsd[name].detach().cpu().contiguous()
        code = _dtype_to_code(t.dtype)
        raw = t.numpy().tobytes()
        header["tensors"][name] = {
            "dtype": code,
            "shape": list(t.shape),
            "offset": offset,
            "nbytes": len(raw),
        }
        pad = _align_up(len(raw)) - len(raw)
        blobs.append((name, raw + (b"\x00" * pad)))
        offset += len(raw) + pad

    meta = json.dumps(header, separators=(",", ":")).encode("utf-8")
    path = str(path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        f.write(INT4_MMAP_MAGIC)
        f.write(len(meta).to_bytes(8, "little"))
        f.write(meta)
        # pad header so data starts on ALIGN
        written = len(INT4_MMAP_MAGIC) + 8 + len(meta)
        pad_h = _align_up(written) - written
        f.write(b"\x00" * pad_h)
        for _, raw in blobs:
            f.write(raw)
    return Path(path).stat().st_size


def _mmap_header(path: str) -> tuple[dict, int]:
    import json

    with open(path, "rb") as f:
        magic = f.read(len(INT4_MMAP_MAGIC))
        if magic != INT4_MMAP_MAGIC:
            raise ValueError(f"not an orbit.int4m checkpoint: {path}")
        n = int.from_bytes(f.read(8), "little")
        meta = json.loads(f.read(n).decode("utf-8"))
        written = len(INT4_MMAP_MAGIC) + 8 + n
        data_off = _align_up(written)
    if meta.get("format") != "orbit.int4m":
        raise ValueError(f"bad mmap format field: {meta.get('format')}")
    return meta, data_off


def load_int4_mmap_state(path: str, *, copy: bool = False) -> Dict[str, torch.Tensor]:
    """Map packed tensors from an orbit.int4m file.

    ``copy=False`` wraps ``numpy.memmap`` views (read-only). ``copy=True``
    materializes independent CPU tensors (safe if the file is unlinked).
    """
    meta, data_off = _mmap_header(path)
    mm = np.memmap(path, dtype=np.uint8, mode="r")
    qsd: Dict[str, torch.Tensor] = {}
    for name, spec in meta["tensors"].items():
        start = data_off + int(spec["offset"])
        nbytes = int(spec["nbytes"])
        np_dt = _code_to_numpy(spec["dtype"])
        view = np.ndarray(spec["shape"], dtype=np_dt, buffer=mm, offset=start)
        if copy:
            arr = np.array(view, copy=True)
            qsd[name] = torch.from_numpy(arr)
        else:
            # memmap view → torch; keep a ref so the map stays alive
            t = torch.from_numpy(view)
            t._orbit_mmap = mm  # type: ignore[attr-defined]
            qsd[name] = t
    return qsd


def load_int4_mmap(
    path: str,
    *,
    cache_fp32: bool = False,
    drop_packed: bool = False,
    copy: bool = True,
) -> TinyLMTorch:
    """Rebuild TinyLM from a pickle-free mmap checkpoint.

    Default ``copy=True`` so callers can delete the file after load
    (tests, benches). Pass ``copy=False`` to keep packed uint8 mapped.
    """
    meta, _ = _mmap_header(path)
    qsd = load_int4_mmap_state(path, copy=copy)
    cfg = TinyLMConfig.from_dict(meta["config"])
    model = TinyLMTorch.from_config(cfg)
    return load_packed_int4_modules(
        model, qsd, cache_fp32=cache_fp32, drop_packed=drop_packed
    )


def is_int4_mmap(path: str) -> bool:
    try:
        with open(path, "rb") as f:
            return f.read(len(INT4_MMAP_MAGIC)) == INT4_MMAP_MAGIC
    except OSError:
        return False


def load_int4_checkpoint(
    path: str,
    *,
    cache_fp32: bool = False,
    drop_packed: bool = False,
) -> TinyLMTorch:
    """Rebuild TinyLMTorch + Int4Linear from a packed checkpoint.

    Empty Linear shells from ``from_config`` are immediately replaced;
    their random FP32 weights are discarded. Auto-detects pickle
    ``orbit.int4`` vs mmap ``orbit.int4m``.
    """
    if is_int4_mmap(path):
        return load_int4_mmap(
            path, cache_fp32=cache_fp32, drop_packed=drop_packed, copy=True
        )
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict) or payload.get("format") != "orbit.int4":
        raise ValueError(f"not an orbit.int4 checkpoint: {path}")
    cfg = TinyLMConfig.from_dict(payload["config"])
    qsd = payload["tensors"]
    model = TinyLMTorch.from_config(cfg)
    return load_packed_int4_modules(
        model, qsd, cache_fp32=cache_fp32, drop_packed=drop_packed
    )


@dataclass
class Int4CheckpointBench:
    fp32_bytes: int
    int4_bytes: int
    compression: float
    max_abs_logit_err: float
    greedy_match: float
    leftover_linear_bytes: int


@torch.no_grad()
def bench_int4_checkpoint_roundtrip(
    cfg: TinyLMConfig | None = None,
    seed: int = 0,
    group_size: int = 32,
    seq: int = 8,
    path: str | None = None,
) -> Int4CheckpointBench:
    """Pack → save → load in a fresh model → compare logits and file size."""
    import tempfile
    from pathlib import Path

    cfg = cfg or TinyLMConfig.preset(
        "rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32
    )
    torch.manual_seed(seed)
    src = TinyLMTorch.from_config(cfg)
    pack_model_int4(src, group_size=group_size)
    src.eval()

    # FP32 reference size = original Linear + emb + norms via a sibling
    fp = TinyLMTorch.from_config(cfg)
    fp.load_state_dict(TinyLMTorch.from_config(cfg).state_dict())  # dummy
    # measure the unquantized src-equivalent: rebuild FP32 from same seed
    torch.manual_seed(seed)
    fp = TinyLMTorch.from_config(cfg)
    import io

    buf_fp = io.BytesIO()
    torch.save(fp.state_dict(), buf_fp)
    fp32_bytes = buf_fp.tell()

    if path is None:
        tmp = tempfile.NamedTemporaryFile(suffix=".pt", delete=False)
        path = tmp.name
        tmp.close()
    int4_bytes = save_int4_checkpoint(src, path)
    restored = load_int4_checkpoint(path)
    leftover = packed_int4_linear_bytes(restored)[1]

    x = torch.randint(0, cfg.vocab_size, (1, seq))
    log_s, _ = src.forward(x)
    log_r, _ = restored.forward(x)
    err = (log_s - log_r).abs()
    match = float((log_s[0].argmax(-1) == log_r[0].argmax(-1)).float().mean())
    try:
        Path(path).unlink(missing_ok=True)
    except OSError:
        pass
    return Int4CheckpointBench(
        fp32_bytes=fp32_bytes,
        int4_bytes=int4_bytes,
        compression=fp32_bytes / max(int4_bytes, 1),
        max_abs_logit_err=float(err.max()),
        greedy_match=match,
        leftover_linear_bytes=leftover,
    )


@dataclass
class Int4MmapBench:
    pickle_bytes: int
    mmap_bytes: int
    ratio_vs_pickle: float
    max_abs_logit_err: float
    greedy_match: float
    leftover_linear_bytes: int
    mmap_view_used: bool


@torch.no_grad()
def bench_int4_mmap_roundtrip(
    cfg: TinyLMConfig | None = None,
    seed: int = 0,
    group_size: int = 32,
    seq: int = 8,
) -> Int4MmapBench:
    """Pack → pickle save + mmap save → load both → compare logits."""
    import tempfile
    from pathlib import Path

    cfg = cfg or TinyLMConfig.preset(
        "rope", vocab_size=32, n_layer=2, n_embd=32, n_head=4, block_size=32
    )
    torch.manual_seed(seed)
    src = TinyLMTorch.from_config(cfg)
    pack_model_int4(src, group_size=group_size)
    src.eval()

    tmp = tempfile.NamedTemporaryFile(suffix=".pt", delete=False)
    pkl_path = tmp.name
    tmp.close()
    tmp2 = tempfile.NamedTemporaryFile(suffix=".int4m", delete=False)
    mm_path = tmp2.name
    tmp2.close()

    pickle_bytes = save_int4_checkpoint(src, pkl_path)
    mmap_bytes = save_int4_mmap(src, mm_path)

    restored_pkl = load_int4_checkpoint(pkl_path)
    restored_mm = load_int4_mmap(mm_path, copy=True)
    leftover = packed_int4_linear_bytes(restored_mm)[1]

    # mapped view path (file must stay)
    qsd_view = load_int4_mmap_state(mm_path, copy=False)
    view_ok = any(hasattr(t, "_orbit_mmap") for t in qsd_view.values())

    x = torch.randint(0, cfg.vocab_size, (1, seq))
    log_s, _ = src.forward(x)
    log_m, _ = restored_mm.forward(x)
    log_p, _ = restored_pkl.forward(x)
    err = (log_s - log_m).abs()
    match = float((log_s[0].argmax(-1) == log_m[0].argmax(-1)).float().mean())
    assert torch.allclose(log_m, log_p, atol=1e-6, rtol=1e-6)

    for p in (pkl_path, mm_path):
        try:
            Path(p).unlink(missing_ok=True)
        except OSError:
            pass
    return Int4MmapBench(
        pickle_bytes=pickle_bytes,
        mmap_bytes=mmap_bytes,
        ratio_vs_pickle=pickle_bytes / max(mmap_bytes, 1),
        max_abs_logit_err=float(err.max()),
        greedy_match=match,
        leftover_linear_bytes=leftover,
        mmap_view_used=view_ok,
    )


@dataclass
class Int4EmbedBench:
    fp32_embed_bytes: int
    int4_embed_bytes: int
    compression: float
    max_abs_logit_err_vs_linear_only: float
    greedy_match_vs_src_int4: float
    leftover_embed_bytes: int
    mmap_bytes: int


@torch.no_grad()
def bench_int4_embeddings(
    cfg: TinyLMConfig | None = None,
    seed: int = 0,
    group_size: int = 32,
    seq: int = 8,
) -> Int4EmbedBench:
    """Pack Linear-only vs Linear+embeddings; measure table bytes + logits."""
    import tempfile
    from pathlib import Path

    cfg = cfg or TinyLMConfig.preset(
        "rope", vocab_size=64, n_layer=2, n_embd=32, n_head=4, block_size=32
    )
    torch.manual_seed(seed)
    src = TinyLMTorch.from_config(cfg)
    lin = TinyLMTorch.from_config(cfg)
    lin.load_state_dict(src.state_dict())
    both = TinyLMTorch.from_config(cfg)
    both.load_state_dict(src.state_dict())
    pack_model_int4(lin, group_size=group_size)
    pack_model_int4(both, group_size=group_size, quantize_embeddings=True)
    lin.eval()
    both.eval()

    fp32_e = 0
    for attr in ("tok_emb", "pos_emb"):
        emb = getattr(src, attr, None)
        if emb is None:
            continue
        w = emb.weight
        fp32_e += w.numel() * 4
    int4_e, leftover_e = packed_int4_embed_bytes(both)

    x = torch.randint(0, cfg.vocab_size, (1, seq))
    log_l, _ = lin.forward(x)
    log_b, _ = both.forward(x)
    err = (log_l - log_b).abs()
    match = float((log_l[0].argmax(-1) == log_b[0].argmax(-1)).float().mean())

    tmp = tempfile.NamedTemporaryFile(suffix=".int4m", delete=False)
    path = tmp.name
    tmp.close()
    mmap_bytes = save_int4_mmap(both, path)
    restored = load_int4_mmap(path, copy=True)
    log_r, _ = restored.forward(x)
    assert torch.allclose(log_b, log_r, atol=1e-5, rtol=1e-5)
    try:
        Path(path).unlink(missing_ok=True)
    except OSError:
        pass
    return Int4EmbedBench(
        fp32_embed_bytes=fp32_e,
        int4_embed_bytes=int4_e,
        compression=fp32_e / max(int4_e, 1),
        max_abs_logit_err_vs_linear_only=float(err.max()),
        greedy_match_vs_src_int4=match,
        leftover_embed_bytes=leftover_e,
        mmap_bytes=mmap_bytes,
    )
