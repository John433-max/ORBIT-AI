"""Cycle 43: small YAML-driven bench matrix (stdlib only — no PyYAML required)."""

from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List

from .config import TinyLMConfig
from .generate import bench_numpy, bench_torch
from .numpy_model import TinyLMNumPy
from .torch_model import TinyLMTorch


DEFAULT_MATRIX = [
    {"name": "rope_d64", "preset": "rope", "n_embd": 64, "n_layer": 4, "n_head": 4, "n_new": 40},
    {"name": "gqa_d64", "preset": "gqa", "n_embd": 64, "n_layer": 4, "n_head": 4, "n_new": 40},
    {"name": "modern_d32", "preset": "modern", "n_embd": 32, "n_layer": 2, "n_head": 4, "n_new": 24},
]


def _parse_simple_yaml(text: str) -> List[Dict[str, Any]]:
    """Minimal YAML subset: list of maps with scalar values (no nested structures)."""
    rows: List[Dict[str, Any]] = []
    cur: Dict[str, Any] | None = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if line.lstrip().startswith("- "):
            if cur:
                rows.append(cur)
            cur = {}
            rest = line.lstrip()[2:].strip()
            if rest and ":" in rest:
                k, v = rest.split(":", 1)
                cur[k.strip()] = _scalar(v.strip())
        elif cur is not None and ":" in line:
            k, v = line.split(":", 1)
            cur[k.strip()] = _scalar(v.strip())
    if cur:
        rows.append(cur)
    return rows


def _scalar(s: str):
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    try:
        if "." in s:
            return float(s)
        return int(s)
    except ValueError:
        return s.strip().strip("\"'")


def load_matrix(path: str | None = None) -> List[Dict[str, Any]]:
    if path is None:
        return list(DEFAULT_MATRIX)
    text = Path(path).read_text()
    if path.endswith(".json"):
        return json.loads(text)
    return _parse_simple_yaml(text) or list(DEFAULT_MATRIX)


def run_matrix(path: str | None = None, prompt_len: int = 8) -> List[Dict[str, Any]]:
    results = []
    for row in load_matrix(path):
        preset = row.get("preset", "rope")
        n_embd = int(row.get("n_embd", 64))
        n_layer = int(row.get("n_layer", 4))
        n_head = int(row.get("n_head", 4))
        n_new = int(row.get("n_new", 40))
        cfg = TinyLMConfig.preset(
            preset,
            vocab_size=64,
            n_embd=n_embd,
            n_layer=n_layer,
            n_head=n_head,
            block_size=64,
        )
        np_m = TinyLMNumPy.from_config(cfg, seed=0)
        t_m = TinyLMTorch.from_config(cfg)
        t_m.load_numpy_state(np_m)
        t0 = time.perf_counter()
        np_tps = bench_numpy(np_m, prompt_len=prompt_len, n_new=n_new, use_cache=True)
        torch_tps = bench_torch(t_m, prompt_len=prompt_len, n_new=n_new, use_cache=True)
        results.append(
            {
                "name": row.get("name", preset),
                "preset": preset,
                "params": sum(p.numel() for p in t_m.parameters()),
                "numpy_tok_s": np_tps,
                "torch_tok_s": torch_tps,
                "n_new": n_new,
                "wall_s": time.perf_counter() - t0,
                "config": cfg.to_dict(),
            }
        )
    return results


def write_results(results: List[Dict[str, Any]], out: str) -> None:
    Path(out).write_text(json.dumps(results, indent=2))
