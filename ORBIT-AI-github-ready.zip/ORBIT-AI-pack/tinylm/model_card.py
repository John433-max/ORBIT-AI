"""Cycle 35: lightweight model card JSON for educational TinyLM configs."""

from __future__ import annotations

from datetime import datetime, timezone

from .config import TinyLMConfig


def build_model_card(
    preset: str = "rope",
    vocab: int = 64,
    layers: int = 4,
    embd: int = 64,
    heads: int = 4,
    block: int = 64,
) -> dict:
    cfg = TinyLMConfig.preset(
        preset,
        vocab_size=vocab,
        n_layer=layers,
        n_embd=embd,
        n_head=heads,
        block_size=block,
    )
    return {
        "name": f"orbit-tinylm-{preset}",
        "family": "ORBIT educational TinyLM",
        "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "preset": preset,
        "config": cfg.to_dict(),
        "estimate_parameters": cfg.estimate_parameters(),
        "features": {
            "rope": cfg.use_rope,
            "qk_norm": cfg.qk_norm,
            "swiglu": cfg.use_swiglu,
            "gqa": cfg.n_kv_head < cfg.n_head,
            "n_kv_head": cfg.n_kv_head,
            "tied_embeddings": True,
            "max_seq_len": cfg.max_seq_len(),
            "sliding_window": cfg.sliding_window,
        },
        "license": "educational / project-local",
        "notes": "Untrained toy weights unless a checkpoint is loaded separately.",
    }
