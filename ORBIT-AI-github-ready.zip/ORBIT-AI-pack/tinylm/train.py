"""Minimal TinyLM trainer for ablations (PyTorch)."""

from __future__ import annotations

from pathlib import Path

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F

from .config import TinyLMConfig
from .eval_harness import max_qk_logit_torch, nll_torch, synthetic_copy_batch
from .numpy_model import TinyLMNumPy
from .torch_model import TinyLMTorch


@dataclass
class TrainResult:
    losses: list[float]
    logit_curve: list[float]
    final_nll: float
    final_ppl: float
    max_param_qk: float
    steps: int
    qk_norm: bool



def cosine_lr(step: int, total: int, lr: float, warmup: int = 0, min_ratio: float = 0.1) -> float:
    """Linear warmup then cosine decay to min_ratio * lr (Cycle 24)."""
    if total <= 0:
        return lr
    if warmup > 0 and step < warmup:
        return lr * float(step + 1) / float(warmup)
    t = min(max(step - warmup, 0), max(total - warmup, 1))
    T = max(total - warmup, 1)
    import math
    cos = 0.5 * (1.0 + math.cos(math.pi * t / T))
    return lr * (min_ratio + (1.0 - min_ratio) * cos)


def adamw_param_groups(model, weight_decay: float = 0.01):
    """No decay on 1D params (norms, biases) — Cycle 25."""
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if p.ndim <= 1 or name.endswith('.bias'):
            no_decay.append(p)
        else:
            decay.append(p)
    return [
        {"params": decay, "weight_decay": weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]


def train_ablation(
    qk_norm: bool,
    steps: int = 80,
    lr: float = 3e-2,
    batch: int = 16,
    seq: int = 32,
    seed: int = 0,
    n_layer: int = 2,
    n_embd: int = 32,
    n_head: int = 4,
    vocab: int = 32,
    high_lr_stress: bool = True,
    use_cosine: bool = True,
    warmup: int = 5,
    early_stop_patience: int = 0,
    grad_accum: int = 1,
    use_amp: bool = False,
) -> TrainResult:
    """
    Train on a periodic pattern so loss is meaningful.
    High LR stress is intended to surface QK logit growth without QK-Norm.
    Cosine LR + AdamW param groups (Cycles 24–26). early_stop_patience>0 enables stop.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    cfg = TinyLMConfig(
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=seq,
        qk_norm=qk_norm,
        residual_init_scale=True,
    )
    model = TinyLMTorch.from_config(cfg)
    opt = torch.optim.AdamW(adamw_param_groups(model, 0.01), lr=lr, betas=(0.9, 0.95))

    losses = []
    logit_curve = []
    best = float("inf")
    bad = 0
    model.train()
    opt.zero_grad()
    for step in range(steps):
        if use_cosine:
            lr_t = cosine_lr(step, steps, lr, warmup=warmup)
            for pg in opt.param_groups:
                pg["lr"] = lr_t
        # mix of patterned and random tokens
        data = synthetic_copy_batch(vocab, batch, seq, seed=step + seed)
        # inject a repeating motif so there is learnable structure
        data[:, 1::2] = (data[:, 0::2] + 1) % vocab
        x = torch.from_numpy(data)
        # Cycle 34: optional autocast (CUDA; CPU path stays float32)
        device_type = "cuda" if next(model.parameters()).is_cuda else "cpu"
        with torch.autocast(
            device_type=device_type,
            dtype=torch.float16 if device_type == "cuda" else torch.bfloat16,
            enabled=bool(use_amp and device_type == "cuda"),
        ):
            logits, _ = model.forward(x[:, :-1])
            loss = F.cross_entropy(logits.reshape(-1, vocab), x[:, 1:].reshape(-1))
        loss = loss / max(grad_accum, 1)
        loss.backward()
        if (step + 1) % max(grad_accum, 1) == 0 or step == steps - 1:
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            opt.zero_grad()
        losses.append(float(loss.detach()) * max(grad_accum, 1))
        if early_stop_patience > 0:
            if losses[-1] < best - 1e-4:
                best = losses[-1]
                bad = 0
            else:
                bad += 1
                if bad >= early_stop_patience:
                    break
        if step % max(1, steps // 10) == 0 or step == steps - 1:
            probe = torch.from_numpy(synthetic_copy_batch(vocab, 4, min(seq, 16), seed=1234))
            logit_curve.append(max_qk_logit_torch(model, probe))

    ev = nll_torch(model, torch.from_numpy(synthetic_copy_batch(vocab, 32, seq, seed=9999)))
    # Q/K weight magnitude as a cheap proxy for logit scale pressure
    qk_norm_mag = 0.0
    with torch.no_grad():
        for layer in model.layers:
            qk_norm_mag = max(
                qk_norm_mag,
                float(layer.wq.weight.norm()),
                float(layer.wk.weight.norm()),
            )
    return TrainResult(
        losses=losses,
        logit_curve=logit_curve,
        final_nll=ev.nll,
        final_ppl=ev.ppl,
        max_param_qk=qk_norm_mag,
        steps=steps,
        qk_norm=qk_norm,
    )


def compare_qk_norm(**kwargs) -> dict:
    off = train_ablation(qk_norm=False, **kwargs)
    on = train_ablation(qk_norm=True, **kwargs)
    return {
        "off": off,
        "on": on,
        "loss_delta_last10": float(np.mean(off.losses[-10:]) - np.mean(on.losses[-10:])),
        "nll_delta": off.final_nll - on.final_nll,
        "off_logit_end": off.logit_curve[-1] if off.logit_curve else None,
        "on_logit_end": on.logit_curve[-1] if on.logit_curve else None,
    }


def multi_seed_qk_norm(seeds=(0, 1, 2), **kwargs) -> dict:
    """Run compare_qk_norm across seeds; report mean end-logit and NLL."""
    rows = []
    for s in seeds:
        kw = dict(kwargs)
        kw["seed"] = s
        rows.append(compare_qk_norm(**kw))
    off_end = [r["off_logit_end"] for r in rows]
    on_end = [r["on_logit_end"] for r in rows]
    nll_d = [r["nll_delta"] for r in rows]
    return {
        "seeds": list(seeds),
        "mean_off_logit_end": float(np.mean(off_end)),
        "mean_on_logit_end": float(np.mean(on_end)),
        "mean_nll_delta": float(np.mean(nll_d)),
        "off_curves": [r["off"].logit_curve for r in rows],
        "on_curves": [r["on"].logit_curve for r in rows],
    }


def train_chat_tiny(
    steps: int = 40,
    lr: float = 3e-2,
    batch: int = 16,
    seq: int = 32,
    seed: int = 0,
    preset: str = "rope",
    vocab: int = 128,
    n_layer: int = 2,
    n_embd: int = 32,
    n_head: int = 4,
    ckpt_path: str | None = None,
) -> dict:
    """Cycle 67: short structured-token train → NumPy checkpoint for chat.generate.

    Task is the same even/odd copy motif as train_ablation so NLL is measurable
    without a large corpus. Weights transfer Torch → NumPy via dump_numpy_state.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    cfg = TinyLMConfig.preset(
        preset,
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=max(seq, 16),
    )
    model = TinyLMTorch.from_config(cfg)
    opt = torch.optim.AdamW(adamw_param_groups(model, 0.01), lr=lr, betas=(0.9, 0.95))
    losses = []
    model.train()
    for step in range(steps):
        data = synthetic_copy_batch(vocab, batch, seq, seed=step + seed)
        data[:, 1::2] = (data[:, 0::2] + 1) % vocab
        x = torch.from_numpy(data)
        logits, _ = model.forward(x[:, :-1])
        loss = F.cross_entropy(logits.reshape(-1, vocab), x[:, 1:].reshape(-1))
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(float(loss.detach()))
    probe = torch.from_numpy(synthetic_copy_batch(vocab, 32, seq, seed=9999))
    probe_np = probe.numpy()
    probe_np[:, 1::2] = (probe_np[:, 0::2] + 1) % vocab
    ev = nll_torch(model, torch.from_numpy(probe_np))
    np_m = TinyLMNumPy.from_config(cfg, seed=seed)
    np_m.load_state_dict(model.dump_numpy_state(), strict=True)
    saved = None
    if ckpt_path:
        from .checkpoint import save_numpy_checkpoint

        saved = save_numpy_checkpoint(
            np_m,
            ckpt_path,
            extra={"steps": steps, "final_nll": ev.nll, "final_ppl": ev.ppl, "preset": preset},
        )
    return {
        "model_np": np_m,
        "model_torch": model,
        "cfg": cfg,
        "losses": losses,
        "final_nll": ev.nll,
        "final_ppl": ev.ppl,
        "steps": steps,
        "ckpt": saved,
    }


def train_rope_context_probe(
    steps: int = 60,
    lr: float = 2e-2,
    batch: int = 16,
    train_seq: int = 24,
    block_size: int = 24,
    long_seq: int = 40,
    seed: int = 0,
    n_layer: int = 2,
    n_embd: int = 32,
    n_head: int = 4,
    vocab: int = 32,
) -> dict:
    """
    Train two RoPE models on short sequences:
      - plain RoPE (factor=1, max_seq=block_size)
      - YaRN (factor=2, max_seq=2*block_size)
    Evaluate NLL on long_seq > block_size (only YaRN can run without error).
    Reports short-seq NLL for both and long-seq NLL for YaRN.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)

    def _train(cfg: TinyLMConfig) -> TinyLMTorch:
        model = TinyLMTorch.from_config(cfg)
        opt = torch.optim.AdamW(model.parameters(), lr=lr, betas=(0.9, 0.95), weight_decay=0.01)
        model.train()
        for step in range(steps):
            data = synthetic_copy_batch(vocab, batch, train_seq, seed=step + seed)
            data[:, 1::2] = (data[:, 0::2] + 1) % vocab
            x = torch.from_numpy(data)
            logits, _ = model.forward(x[:, :-1])
            loss = F.cross_entropy(logits.reshape(-1, vocab), x[:, 1:].reshape(-1))
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        return model

    plain_cfg = TinyLMConfig(
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=block_size,
        qk_norm=True,
        residual_init_scale=True,
        use_rope=True,
        rope_scaling="none",
        rope_factor=1.0,
        attn_logit_softcap=0.0,
    )
    yarn_cfg = TinyLMConfig(
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=block_size,
        qk_norm=True,
        residual_init_scale=True,
        use_rope=True,
        rope_scaling="yarn",
        rope_factor=2.0,
        attn_logit_softcap=0.0,
    )
    plain = _train(plain_cfg)
    yarn = _train(yarn_cfg)

    short = torch.from_numpy(synthetic_copy_batch(vocab, 32, train_seq, seed=9999))
    plain_short = nll_torch(plain, short)
    yarn_short = nll_torch(yarn, short)

    long = torch.from_numpy(synthetic_copy_batch(vocab, 16, long_seq, seed=4242))
    yarn_long = nll_torch(yarn, long)
    # Plain RoPE must reject or hard-fail beyond block_size
    plain_long_ok = False
    plain_long_nll = None
    try:
        plain_long = nll_torch(plain, long)
        plain_long_ok = True
        plain_long_nll = plain_long.nll
    except Exception:
        plain_long_ok = False

    return {
        "plain_short_nll": plain_short.nll,
        "yarn_short_nll": yarn_short.nll,
        "yarn_long_nll": yarn_long.nll,
        "plain_long_allowed": plain_long_ok,
        "plain_long_nll": plain_long_nll,
        "train_seq": train_seq,
        "long_seq": long_seq,
        "block_size": block_size,
        "yarn_max_seq": yarn_cfg.max_seq_len(),
    }


def _byte_ids_train(text: str, vocab_size: int) -> list:
    vs = max(8, int(vocab_size or 128))
    lo, hi = 1, vs - 2
    span = hi - lo + 1
    out = []
    for b in (text or "").encode("utf-8", errors="replace"):
        out.append(lo + (int(b) % span))
    return out or [lo]


def _persona_corpus(path: str | None = None) -> list[str]:
    """Load persona rows + a few fixed dialog lines for chat-domain training."""
    lines = []
    candidates = []
    if path:
        candidates.append(Path(path))
    candidates.extend(
        [
            Path("persona_chat.jsonl"),
            Path(__file__).resolve().parent.parent / "persona_chat.jsonl",
        ]
    )
    for p in candidates:
        if p.exists():
            import json
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                q = (row.get("instruction") or "").strip()
                a = (row.get("output") or "").strip()
                if q and a:
                    lines.append(f"user: {q}\nassistant: {a}")
            break
    # Always include short identity dialogs so even empty file has signal
    lines.extend(
        [
            "user: hi\nassistant: Hey. I'm ORBIT.",
            "user: what is your name\nassistant: I'm ORBIT.",
            "user: thanks\nassistant: Sure.",
            "user: who are you\nassistant: I'm ORBIT, a small prototype.",
        ]
    )
    return lines


def _train_persona_bpe(corpus: list[str], vocab_target: int = 320):
    """Cycle 70: small GPT-2-style BPE on the persona corpus.

    Base alphabet is raw bytes (256) so unseen UTF-8 still round-trips.
    Vocab is 256 + merges + BOS/EOS/PAD; floor is 259.
    """
    import sys
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from bpe_tokenizer import BPETokenizer

    text = "\n".join(corpus)
    target = max(259, int(vocab_target or 320))
    tok = BPETokenizer().train(text, vocab_size=target, min_frequency=2)
    return tok


def train_persona_chat(
    steps: int = 60,
    lr: float = 3e-2,
    batch: int = 8,
    seq: int = 48,
    seed: int = 0,
    preset: str = "rope",
    vocab: int = 128,
    n_layer: int = 2,
    n_embd: int = 32,
    n_head: int = 4,
    ckpt_path: str | None = "checkpoints/tinylm_persona.npz",
    persona_path: str | None = None,
    tokenizer: str = "byte",
    vocab_target: int = 320,
    bpe_path: str | None = None,
) -> dict:
    """Cycle 68/70: train TinyLM on persona dialog text, export NumPy ckpt.

    tokenizer='byte' (default): lossy byte-mod into `vocab` (compat with Cycle 68).
    tokenizer='bpe': train a small byte-level BPE; model vocab = tok.VOCAB_SIZE.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    corpus = _persona_corpus(persona_path)
    tok = None
    tok_kind = (tokenizer or "byte").lower()
    if tok_kind == "bpe":
        if bpe_path:
            import sys
            from pathlib import Path as _P

            root = _P(__file__).resolve().parent.parent
            if str(root) not in sys.path:
                sys.path.insert(0, str(root))
            from bpe_tokenizer import BPETokenizer

            tok = BPETokenizer.load(bpe_path)
        else:
            tok = _train_persona_bpe(corpus, vocab_target=vocab_target)
        vocab = int(tok.VOCAB_SIZE)
        encoded = [tok.encode(s, add_bos=False, add_eos=False) for s in corpus]
        eos_fill = int(tok.EOS)
        sep_ids = tok.encode("\n", add_bos=False, add_eos=False) or [eos_fill]
    else:
        encoded = [_byte_ids_train(s, vocab) for s in corpus]
        eos_fill = vocab - 1
        sep_ids = [eos_fill]
    # tile short sequences so batch sampling always has enough tokens
    stream = []
    boundary = 0
    while len(stream) < batch * seq * max(4, steps // 2):
        for ids in encoded:
            stream.extend(ids)
            # Cycle 76: prefer newline separators so EOS is not the modal next-token.
            stream.extend(sep_ids)
            boundary += 1
            if tok_kind == "bpe" and boundary % 8 == 0:
                stream.append(eos_fill)
    stream = np.array(stream, dtype=np.int64)

    cfg = TinyLMConfig.preset(
        preset,
        vocab_size=vocab,
        n_layer=n_layer,
        n_embd=n_embd,
        n_head=n_head,
        block_size=max(seq, 16),
    )
    model = TinyLMTorch.from_config(cfg)
    opt = torch.optim.AdamW(adamw_param_groups(model, 0.01), lr=lr, betas=(0.9, 0.95))
    losses = []
    model.train()
    rng = np.random.default_rng(seed)

    def sample_batch():
        xs = []
        for _ in range(batch):
            start = int(rng.integers(0, max(1, len(stream) - seq - 1)))
            xs.append(stream[start : start + seq])
        return torch.from_numpy(np.stack(xs))

    for step in range(steps):
        x = sample_batch()
        logits, _ = model.forward(x[:, :-1])
        loss = F.cross_entropy(logits.reshape(-1, vocab), x[:, 1:].reshape(-1))
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(float(loss.detach()))

    # hold-out NLL on last 20% of stream
    cut = max(seq + 1, int(len(stream) * 0.8))
    probe_list = []
    for i in range(8):
        start = cut + i * seq
        if start + seq > len(stream):
            break
        probe_list.append(stream[start : start + seq])
    if not probe_list:
        probe_list = [stream[:seq]]
    probe = torch.from_numpy(np.stack(probe_list))
    ev = nll_torch(model, probe)
    np_m = TinyLMNumPy.from_config(cfg, seed=seed)
    np_m.load_state_dict(model.dump_numpy_state(), strict=True)
    saved = None
    if ckpt_path:
        from .checkpoint import save_numpy_checkpoint

        extra = {
            "steps": steps,
            "final_nll": ev.nll,
            "final_ppl": ev.ppl,
            "preset": preset,
            "corpus": "persona_chat",
            "n_dialogs": len(corpus),
            "tokenizer": tok_kind,
            "vocab_size": vocab,
        }
        tok_path = None
        if tok is not None:
            from pathlib import Path

            tok_path = str(Path(ckpt_path).with_suffix(".bpe.json"))
            tok.save(tok_path)
            extra["tokenizer_path"] = tok_path
            extra["bpe_merges"] = len(tok.merge_order)
        saved = save_numpy_checkpoint(np_m, ckpt_path, extra=extra)
        if tok_path:
            saved["tokenizer_path"] = tok_path
    return {
        "model_np": np_m,
        "model_torch": model,
        "cfg": cfg,
        "losses": losses,
        "final_nll": ev.nll,
        "final_ppl": ev.ppl,
        "steps": steps,
        "ckpt": saved,
        "n_dialogs": len(corpus),
        "loss_start": losses[0] if losses else None,
        "loss_end": losses[-1] if losses else None,
        "tokenizer": tok_kind,
        "vocab_size": vocab,
        "bpe_merges": len(tok.merge_order) if tok is not None else 0,
        "tokenizer_obj": tok,
    }


def train_persona_bpe_l4d64(
    steps: int = 80,
    lr: float = 1e-2,
    batch: int = 8,
    seq: int = 64,
    seed: int = 0,
    ckpt_path: str | None = "checkpoints/tinylm_persona_bpe_l4.npz",
    bpe_path: str | None = "checkpoints/tinylm_persona_bpe.bpe.json",
) -> dict:
    """Cycle 76: L=4 d=64 n_head=8 BPE persona train, reuse shipped BPE vocab."""
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    if bpe_path and not Path(bpe_path).exists():
        alt = root / "checkpoints" / "tinylm_persona_bpe.bpe.json"
        bpe_path = str(alt) if alt.exists() else None
    out = train_persona_chat(
        steps=steps,
        lr=lr,
        batch=batch,
        seq=seq,
        seed=seed,
        preset="rope",
        n_layer=4,
        n_embd=64,
        n_head=8,
        ckpt_path=ckpt_path,
        tokenizer="bpe",
        bpe_path=bpe_path,
    )
    out["size"] = "l4d64"
    return out

