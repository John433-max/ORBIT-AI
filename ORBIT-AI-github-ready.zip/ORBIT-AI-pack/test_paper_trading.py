"""Tests for paper_trading.py — Phase 16 additions: spread/slippage, stop
loss/take profit, win rate, profit factor, Sharpe ratio, max drawdown."""
import numpy as np
import pytest

from paper_trading import PaperPortfolio, backtest_sma_crossover


def test_buy_rejects_insufficient_cash():
    p = PaperPortfolio(100.0)
    r = p.buy("X", 50, 10)  # notional 500 > 100 cash
    assert r["ok"] is False


def test_sell_rejects_insufficient_position():
    p = PaperPortfolio(10_000.0)
    r = p.sell("X", 50, 10)  # nothing held
    assert r["ok"] is False


def test_buy_then_sell_realizes_pnl():
    p = PaperPortfolio(10_000.0, transaction_cost_bps=0)
    p.buy("X", 100, 10)
    p.sell("X", 120, 10)
    perf = p.performance({"X": 120})
    assert perf["pnl_pct"] > 0
    assert perf["win_rate"] == 1.0
    assert perf["n_wins"] == 1 and perf["n_losses"] == 0


def test_losing_trade_reflected_in_win_rate():
    p = PaperPortfolio(10_000.0, transaction_cost_bps=0)
    p.buy("X", 100, 10)
    p.sell("X", 80, 10)  # sold at a loss
    perf = p.performance({"X": 80})
    assert perf["win_rate"] == 0.0
    assert perf["n_losses"] == 1


def test_spread_and_slippage_worsen_execution_price():
    baseline = PaperPortfolio(10_000.0, transaction_cost_bps=0)
    baseline.buy("X", 100, 1)
    with_costs = PaperPortfolio(10_000.0, transaction_cost_bps=0, spread_bps=100, slippage_bps=50)
    with_costs.buy("X", 100, 1)
    assert with_costs.trade_log[-1]["price"] > baseline.trade_log[-1]["price"]


def test_transaction_fee_charged():
    p = PaperPortfolio(10_000.0, transaction_cost_bps=100)  # 1%
    p.buy("X", 100, 1)
    assert p.trade_log[-1]["fee"] == pytest.approx(1.0, rel=1e-6)


@pytest.fixture
def synthetic_prices():
    rng = np.random.default_rng(1)
    prices = 100 + np.cumsum(rng.normal(0.05, 1.0, 150))
    return np.clip(prices, 1, None)


def test_backtest_runs_and_returns_expected_fields(synthetic_prices):
    perf = backtest_sma_crossover(synthetic_prices)
    for field in ("pnl_pct", "max_drawdown_pct", "buy_and_hold_pnl_pct",
                  "win_rate", "profit_factor", "sharpe_ratio", "n_trades"):
        assert field in perf


def test_backtest_rejects_too_short_series():
    with pytest.raises(ValueError):
        backtest_sma_crossover(np.array([1.0, 2.0, 3.0]), slow=20)


def test_backtest_with_stop_loss_limits_downside(synthetic_prices):
    perf_no_stop = backtest_sma_crossover(synthetic_prices)
    perf_with_stop = backtest_sma_crossover(synthetic_prices, stop_loss_pct=0.02, take_profit_pct=0.04)
    # both should run to completion and produce a real (finite) drawdown figure
    assert np.isfinite(perf_no_stop["max_drawdown_pct"])
    assert np.isfinite(perf_with_stop["max_drawdown_pct"])


def test_max_drawdown_is_never_positive(synthetic_prices):
    perf = backtest_sma_crossover(synthetic_prices)
    assert perf["max_drawdown_pct"] <= 0


def test_sma_signal_excludes_current_bar_no_lookahead():
    """Direct verification (not assumption) that the moving-average signal
    at bar t is computed from prices[t-window:t], which excludes bar t
    itself -- if this ever regressed to include bar t, the strategy would
    have genuine look-ahead bias (using a bar's own price to help decide
    whether to trade that same bar)."""
    import numpy as np
    prices = np.arange(30, dtype=float)
    t, fast = 10, 5
    window = prices[t - fast:t]
    assert prices[t] not in window


def test_backtest_result_documents_its_fill_assumption(synthetic_prices):
    """The idealized same-bar-execution assumption must be documented in
    the output, not just in a docstring nobody reading the result sees."""
    perf = backtest_sma_crossover(synthetic_prices)
    assert "fill_assumption" in perf
    assert "prior-bar data" in perf["fill_assumption"]
