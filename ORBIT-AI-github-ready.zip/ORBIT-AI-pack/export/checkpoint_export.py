"""
Export ORBIT checkpoints to a portable directory layout.

Honest scope (from llama.cpp / industry practice research):
  - llama.cpp's `convert_hf_to_gguf.py` expects a **Hugging Face-format**
    directory (config.json + safetensors/bin + tokenizer files).
  - ORBIT's native format is NumPy `.npz` + JSON metadata.
  - This module exports weights + config + a README that documents the
    remaining steps. It does **not** claim GGUF compatibility until a real
    HF-format converter is validated end-to-end.

Usage:
  python -m export.checkpoint_export --npz checkpoint_base.npz --out exports/orbit-tiny
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np


def export_numpy_checkpoint_to_dir(
    npz_path: str,
    out_dir: str,
    metadata_path: Optional[str] = None,
) -> Path:
    npz_path = Path(npz_path)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    if not npz_path.exists():
        raise FileNotFoundError(npz_path)

    data = np.load(str(npz_path))
    weights: Dict[str, Any] = {k: data[k] for k in data.files}
    np.savez_compressed(str(out / "weights.npz"), **weights)

    meta: Dict[str, Any] = {"source_npz": str(npz_path), "n_tensors": len(weights)}
    side = Path(metadata_path) if metadata_path else npz_path.with_suffix(".json")
    if side.exists():
        with open(side, "r", encoding="utf-8") as f:
            meta.update(json.load(f))
    with open(out / "orbit_config.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, default=str)

    # Copy tokenizer if present
    for tok in ("bpe_tokenizer.json", "tokenizer/tokenizer.json"):
        p = Path(tok)
        if p.exists():
            shutil.copy2(p, out / p.name)

    export_readme(out, meta)
    return out


def export_readme(out_dir: Path, meta: Dict[str, Any]) -> None:
    text = f"""# ORBIT export package

Source metadata:
```json
{json.dumps(meta, indent=2, default=str)[:2000]}
```

## What's included
- `weights.npz` — NumPy parameter tensors from the ORBIT checkpoint
- `orbit_config.json` — architecture / training metadata when available
- tokenizer JSON if it was found next to the project

## GGUF / llama.cpp (not automatic)
Industry conversion path (llama.cpp):

1. Convert weights into a **Hugging Face-style** directory
   (`config.json` + `.safetensors` + tokenizer files).
2. Run llama.cpp's `convert_hf_to_gguf.py` on that directory.
3. Optionally quantize with llama.cpp's quantize tool.

ORBIT does **not** yet emit HF `config.json` / safetensors. This export is
the portable intermediate for that future converter. Do not claim
Ollama/LM Studio compatibility until those steps are tested.

## Reload in ORBIT
```python
from model import TinyLM
from train import load_into, build_model_from_checkpoint
# or training.checkpoint.load_numpy_checkpoint
```
"""
    (out_dir / "README.md").write_text(text, encoding="utf-8")


def main(argv=None):
    p = argparse.ArgumentParser(description="Export ORBIT checkpoint package")
    p.add_argument("--npz", required=True, help="Path to .npz checkpoint")
    p.add_argument("--meta", default=None, help="Optional .json metadata sidecar")
    p.add_argument("--out", default="exports/orbit-model")
    args = p.parse_args(argv)
    out = export_numpy_checkpoint_to_dir(args.npz, args.out, args.meta)
    print(f"Exported → {out}")


if __name__ == "__main__":
    main()
