"""
PyTorch port of model.py's TinyLM. Same architecture, verified to match the
NumPy/autograd.py version formula-for-formula (RMSNorm, RoPE rotate-half
convention, GQA repeat_interleave expansion, SwiGLU, tied input/output
embeddings, optional recursive x/y/z reasoning block) -- see each class's
docstring below for the specific correspondence to model.py.

WHY THIS EXISTS ALONGSIDE model.py, NOT INSTEAD OF IT: model.py's whole
point is the hand-written autograd engine (autograd.py) -- that's the
actual educational content of this project (see model.py's own docstring
and DESIGN.md). Replacing it with PyTorch would throw away the thing the
NumPy implementation exists to demonstrate. What PyTorch actually buys is
speed: this project's own large-corpus work (train_large.py, dataset.py's
GITenberg corpus) hit a real, measured wall with the pure-Python autograd
engine -- encoding and training on even a few MB of text took minutes, and
a full pass over the ~56MB bundled corpus was estimated at tens of minutes
to hours. This module is the honest fix for that specific problem: a
faster backend for large-scale training, not a replacement for the
reference implementation.

VERIFICATION STATUS -- read this before trusting this file: installing
PyTorch in the sandbox this project was built in was NOT straightforward
(the default PyPI index resolves to a CUDA build with large dependency
packages; the sandbox's disk space was tight enough that the first install
attempt failed outright, and even a --no-deps install without those CUDA
packages crashed with a low-level Bus error on import). Once genuinely
free disk space was available, a real `pip install torch` succeeded and
this file's forward/backward pass, shape checks, config validation, and
tied-weight logic were all actually run against that real install -- see
test_model_torch.py, which was executed, not just written. What was NOT
possible to verify in this environment: numerically comparing this
implementation's output against model.py's NumPy implementation on
identical weights (doing that properly means porting each Tensor's
`.data` into an equivalent torch.Tensor with the exact same values and
checking outputs match to float precision, which needs more time than was
available after the install itself ate a large part of the session's disk
and time budget). The architecture-level correspondence is documented
per-component below and was checked by hand against model.py line by line,
but "checked by hand" is weaker evidence than a passing numerical parity
test -- flagged explicitly rather than glossed over.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def rmsnorm_torch(x: torch.Tensor, weight: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """Matches model.py's rmsnorm(): mean-square over the last dim, no
    mean-subtraction (that's the difference from LayerNorm), scaled by a
    learned per-channel weight with no bias term."""
    ms = x.pow(2).mean(dim=-1, keepdim=True)
    return x * torch.rsqrt(ms + eps) * weight


def rope_cos_sin_torch(seq_len: int, d_head: int, base: float = 10000.0, device=None):
    """Matches model.py's rope_cos_sin() exactly: same inv_freq formula,
    same "duplicate not interleave" layout (cos/sin each have the d_head/2
    frequencies repeated twice across the full d_head width, matching the
    rotate-half convention below, not the alternate interleaved-pairs
    convention some other RoPE implementations use)."""
    inv_freq = 1.0 / (base ** (torch.arange(0, d_head, 2, device=device).float() / d_head))
    t = torch.arange(seq_len, device=device).float()
    freqs = torch.outer(t, inv_freq)  # (T, d_head/2)
    cos = torch.cat([freqs.cos(), freqs.cos()], dim=-1)  # (T, d_head)
    sin = torch.cat([freqs.sin(), freqs.sin()], dim=-1)
    return cos, sin


def _rotate_half(x: torch.Tensor) -> torch.Tensor:
    d = x.shape[-1]
    x1, x2 = x[..., : d // 2], x[..., d // 2:]
    return torch.cat([-x2, x1], dim=-1)


def apply_rope_torch(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """Matches model.py's apply_rope(): y = x*cos + rotate_half(x)*sin.
    Autograd is automatic here (that's the whole point of using torch) --
    model.py has to hand-write this rotation's backward pass since its
    autograd engine is the thing being demonstrated from scratch."""
    return x * cos + _rotate_half(x) * sin


class CausalSelfAttentionGQA(nn.Module):
    """Matches model.py's CausalSelfAttentionGQA. No bias on any
    projection (bias=False), matching init_linear()'s bias-free linear
    layers. KV-head expansion uses repeat_interleave along the head
    dimension -- the torch equivalent of model.py's
    `np.repeat(t.data, group, axis=1)` -- NOT `.repeat(...)` (which would
    tile the whole head dimension rather than expanding each KV head into
    `group` consecutive copies, a different and wrong GQA grouping)."""

    def __init__(self, d_model, n_heads, n_kv_heads, d_head):
        super().__init__()
        self.n_heads, self.n_kv_heads, self.d_head = n_heads, n_kv_heads, d_head
        self.Wq = nn.Linear(d_model, n_heads * d_head, bias=False)
        self.Wk = nn.Linear(d_model, n_kv_heads * d_head, bias=False)
        self.Wv = nn.Linear(d_model, n_kv_heads * d_head, bias=False)
        self.Wo = nn.Linear(n_heads * d_head, d_model, bias=False)

    def forward(self, x, cos, sin, causal_mask):
        B, T, D = x.shape
        H, KVH, dh = self.n_heads, self.n_kv_heads, self.d_head
        group = H // KVH

        q = self.Wq(x).view(B, T, H, dh).transpose(1, 2)     # (B,H,T,dh)
        k = self.Wk(x).view(B, T, KVH, dh).transpose(1, 2)   # (B,KVH,T,dh)
        v = self.Wv(x).view(B, T, KVH, dh).transpose(1, 2)

        q = apply_rope_torch(q, cos, sin)
        k = apply_rope_torch(k, cos, sin)

        k = k.repeat_interleave(group, dim=1)  # (B,H,T,dh) -- matches model.py's _expand_kv
        v = v.repeat_interleave(group, dim=1)

        scores = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(dh))  # (B,H,T,T)
        scores = scores + causal_mask
        attn = F.softmax(scores, dim=-1)
        out = attn @ v                                                # (B,H,T,dh)
        out = out.transpose(1, 2).reshape(B, T, H * dh)
        return self.Wo(out)


class SwiGLUMLP(nn.Module):
    """Matches model.py's SwiGLUMLP: gate = silu(x@W1), up = x@W2,
    out = (gate*up)@W3 -- no bias on any of the three, matching
    init_linear()."""

    def __init__(self, d_model, d_ff):
        super().__init__()
        self.W1 = nn.Linear(d_model, d_ff, bias=False)  # gate
        self.W2 = nn.Linear(d_model, d_ff, bias=False)  # up
        self.W3 = nn.Linear(d_ff, d_model, bias=False)  # down

    def forward(self, x):
        return self.W3(F.silu(self.W1(x)) * self.W2(x))


class Block(nn.Module):
    """Matches model.py's Block: pre-norm residual attention, then
    pre-norm residual MLP -- standard pre-LN decoder layer, RMSNorm
    weights initialized to all-ones (matching Tensor(np.ones(d_model)))."""

    def __init__(self, d_model, n_heads, n_kv_heads, d_head, d_ff):
        super().__init__()
        self.attn = CausalSelfAttentionGQA(d_model, n_heads, n_kv_heads, d_head)
        self.mlp = SwiGLUMLP(d_model, d_ff)
        self.norm1 = nn.Parameter(torch.ones(d_model))
        self.norm2 = nn.Parameter(torch.ones(d_model))

    def forward(self, x, cos, sin, mask):
        x = x + self.attn(rmsnorm_torch(x, self.norm1), cos, sin, mask)
        x = x + self.mlp(rmsnorm_torch(x, self.norm2))
        return x


class ReasoningBlockTorch(nn.Module):
    """Matches model.py's ReasoningBlock: shared weights across every
    recursive step (n_sup steps), z in hidden-state space (never
    projected to token logits, discarded after use), y is the
    post-transformer residual-stream state being refined. See model.py's
    ReasoningBlock docstring for the design rationale (DESIGN.md Part 2) --
    unchanged here, this is a faithful port, not a redesign."""

    def __init__(self, d_model, n_sup=4):
        super().__init__()
        self.n_sup = n_sup
        self.Wz = nn.Linear(3 * d_model, d_model, bias=False)
        self.Wy = nn.Linear(2 * d_model, d_model, bias=False)
        self.norm_z = nn.Parameter(torch.ones(d_model))
        self.norm_y = nn.Parameter(torch.ones(d_model))

    def forward(self, x, y):
        B, T, D = y.shape
        z = torch.zeros(B, T, D, device=y.device, dtype=y.dtype)
        for _ in range(self.n_sup):
            zin = torch.cat([x, y, z], dim=-1)
            z = rmsnorm_torch(F.silu(self.Wz(zin)), self.norm_z)
            yin = torch.cat([y, z], dim=-1)
            y = y + rmsnorm_torch(F.silu(self.Wy(yin)), self.norm_y)
        return y


class TinyLMTorch(nn.Module):
    """PyTorch TinyLM -- same constructor signature and same config
    validation as model.py's TinyLM, so a checkpoint's metadata JSON
    (d_model/n_layers/n_heads/n_kv_heads/vocab_size/seq_len/recursive,
    written by train.py's full_checkpoint_metadata()) can build either
    backend's model class from the identical dict. Checkpoint *weights*
    are NOT interchangeable between the two backends (different parameter
    storage layout -- .npz for the NumPy engine, torch state_dict here);
    only the architecture description is shared.
    """

    def __init__(self, vocab_size, d_model=64, n_layers=2, n_heads=4, n_kv_heads=2,
                 d_ff=None, max_seq_len=128, use_recursive_reasoning=False,
                 n_sup=4, seed=0):
        super().__init__()
        if vocab_size <= 0:
            raise ValueError(f"vocab_size must be positive, got {vocab_size}")
        if d_model % n_heads != 0:
            raise ValueError(f"d_model ({d_model}) must be divisible by n_heads ({n_heads})")
        if n_heads % n_kv_heads != 0:
            raise ValueError(f"n_heads ({n_heads}) must be divisible by n_kv_heads ({n_kv_heads}) for GQA")
        if n_kv_heads > n_heads:
            raise ValueError(f"n_kv_heads ({n_kv_heads}) cannot exceed n_heads ({n_heads})")
        if n_layers <= 0:
            raise ValueError(f"n_layers must be positive, got {n_layers}")
        if max_seq_len <= 0:
            raise ValueError(f"max_seq_len must be positive, got {max_seq_len}")

        torch.manual_seed(seed)
        self.d_head = d_model // n_heads
        d_ff = d_ff or int(d_model * 8 / 3)

        self.tok_emb = nn.Parameter(torch.randn(vocab_size, d_model) * 0.02)  # matches scale=0.02 in model.py
        self.blocks = nn.ModuleList([
            Block(d_model, n_heads, n_kv_heads, self.d_head, d_ff) for _ in range(n_layers)
        ])
        self.norm_f = nn.Parameter(torch.ones(d_model))

        cos, sin = rope_cos_sin_torch(max_seq_len, self.d_head)
        self.register_buffer("cos", cos, persistent=False)
        self.register_buffer("sin", sin, persistent=False)

        self.use_recursive_reasoning = use_recursive_reasoning
        if use_recursive_reasoning:
            self.reasoner = ReasoningBlockTorch(d_model, n_sup=n_sup)

        self.max_seq_len = max_seq_len
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        B, T = input_ids.shape
        if T > self.max_seq_len:
            raise ValueError(f"sequence length {T} exceeds model max_seq_len {self.max_seq_len}")
        if input_ids.numel() and (input_ids.min().item() < 0 or input_ids.max().item() >= self.vocab_size):
            raise ValueError(
                f"token id out of range [0, {self.vocab_size}): "
                f"got min={input_ids.min().item()}, max={input_ids.max().item()}")

        x = F.embedding(input_ids, self.tok_emb)  # (B,T,D)
        mask = torch.triu(torch.full((T, T), -1e9, device=input_ids.device), diagonal=1)[None, None, :, :]
        cos = self.cos[None, None, :T, :]
        sin = self.sin[None, None, :T, :]

        h = x
        for blk in self.blocks:
            h = blk(h, cos, sin, mask)
        if self.use_recursive_reasoning:
            h = self.reasoner(x, h)
        h = rmsnorm_torch(h, self.norm_f)
        logits = h.reshape(B * T, self.d_model) @ self.tok_emb.T  # tied output projection

        if not torch.isfinite(logits).all():
            n_nan = int(torch.isnan(logits).sum())
            n_inf = int(torch.isinf(logits).sum())
            raise FloatingPointError(f"non-finite values in final logits: {n_nan} NaN, {n_inf} Inf")
        return logits

    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())


def save_checkpoint_torch(model: "TinyLMTorch", path: str, metadata: dict = None):
    """Torch-native checkpoint save. Deliberately NOT reusing train.py's
    .npz-based save_checkpoint()/load_into() -- torch's state_dict already
    handles parameter naming/shape bookkeeping correctly and efficiently;
    manually flattening into the same param_0/param_1/... scheme the NumPy
    engine uses would just be reimplementing what state_dict already does,
    with more room for a naming-order bug. Metadata sidecar uses the exact
    same JSON shape as the NumPy side (see train.py's
    full_checkpoint_metadata/build_model_from_checkpoint) so a checkpoint
    from either backend is equally self-describing, even though weights
    themselves aren't cross-loadable between backends (different parameter
    storage format)."""
    import json
    torch.save(model.state_dict(), path)
    if metadata is not None:
        meta_path = path[:-3] + ".json" if path.endswith(".pt") else path + ".json"
        with open(meta_path, "w") as f:
            json.dump(metadata, f, indent=2)


def build_torch_model_from_checkpoint(pt_path: str, json_path: str = None) -> "tuple[TinyLMTorch, dict]":
    """Torch-side counterpart to train.py's build_model_from_checkpoint():
    reads the same metadata JSON shape, constructs a matching TinyLMTorch,
    loads the state_dict, and -- like the NumPy version -- validates rather
    than silently accepting a mismatch (torch's load_state_dict(strict=True),
    the default, already raises a clear error listing exactly which keys
    are missing/unexpected/shape-mismatched if the checkpoint doesn't match
    the constructed model, which is the same failure mode the NumPy side's
    load_into() had to be specifically fixed to catch -- torch gets this
    for free)."""
    import json
    if json_path is None:
        json_path = pt_path[:-3] + ".json" if pt_path.endswith(".pt") else pt_path + ".json"
    with open(json_path) as f:
        meta = json.load(f)
    required = ["d_model", "n_layers", "n_heads", "n_kv_heads", "vocab_size"]
    missing = [k for k in required if k not in meta]
    if missing:
        raise ValueError(
            f"checkpoint metadata '{json_path}' is missing required fields {missing} -- "
            f"cannot safely reconstruct the model architecture from it.")
    model = TinyLMTorch(vocab_size=meta["vocab_size"], d_model=meta["d_model"], n_layers=meta["n_layers"],
                         n_heads=meta["n_heads"], n_kv_heads=meta["n_kv_heads"],
                         max_seq_len=meta.get("seq_len", 64), use_recursive_reasoning=meta.get("recursive", False))
    state_dict = torch.load(pt_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state_dict)  # strict=True by default -- raises clearly on any mismatch
    return model, meta
