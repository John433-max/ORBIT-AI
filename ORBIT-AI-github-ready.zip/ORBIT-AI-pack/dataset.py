"""
Dataset construction pipeline (spec Part 5), as actual runnable code rather
than description. Raw data here is hand-authored/synthetic across the
categories the spec lists (general text, code, docs/JSON/Markdown, math,
multilingual, Q&A, tool-use, structured data) — NOT scraped, per the spec's
own "do not recommend indiscriminately scraping copyrighted material"
instruction. A production run replaces RAW_SOURCES with real licensed/
public-domain corpora; the pipeline stages below (dedup, quality filter,
language ID, contamination check) are the reusable part and don't change
shape when the input does.

Pipeline stages implemented:
1. Collection — RAW_SOURCES, tagged by category.
2. Exact + near-duplicate dedup — exact hash match, plus a MinHash-style
   shingle/Jaccard near-dup check (a real, if small-scale, version of the
   MinHash/LSH deduplication spec Part 5 asks for).
3. Quality filtering — length bounds, printable-character ratio, a
   "not just punctuation/whitespace" check.
4. Language ID — a tiny character-frequency heuristic (NOT a real
   langid/fastText model; documented as a stand-in below).
5. Train/val split with contamination check — verifies no shared 8-gram
   spans exist between the train and val splits before training ever sees
   both (spec Part 5's "contamination prevention", applied here to the
   train/val boundary itself as a concrete, checkable example of the
   general practice, which in production also runs against your held-out
   eval benchmarks per Part 23).
"""
import os
import hashlib
import re
from collections import Counter

# Real, legitimately-sourced large-scale corpus (opt-in, off by default —
# see build_corpus()'s `include_external` parameter and the module-level
# docstring note below for why this isn't wired in automatically).
EXTERNAL_CORPUS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "gitenberg_books")


def load_external_documents(corpus_dir: str = EXTERNAL_CORPUS_DIR) -> list:
    """
    Loads 79 complete public-domain books (~56MB) sourced from GITenberg
    (github.com/GITenberg — individual per-book git mirrors of Project
    Gutenberg texts, Gutenberg boilerplate headers/footers stripped).

    Honest scope note: this is real, substantial (roughly 7,000x the
    original ~8KB embedded RAW_SOURCES corpus below), and every file here is
    a full, legitimately public-domain literary work — not a placeholder
    and not copyrighted material. It falls well short of a literal 1GB
    target, for two concrete reasons rather than vague caution:
      1. Sourcing more requires either general web access (not available —
         network is restricted to package registries and GitHub, no open
         web/Wikipedia/Gutenberg-direct), or discovering more GitHub-hosted
         public-domain repos via the GitHub API, which was rate-limited
         (shared sandbox egress IP) when this was built.
      2. Even with more source text available, bpe_tokenizer.py's trainer
         (even after the word-frequency-collapsing optimization added in
         this pass — see bpe_tokenizer.py) is still O(unique_words × merges)
         pure Python, not the incremental-pair-count algorithm real BPE
         implementations use. It's fast enough to *train the tokenizer* on a
         few-MB representative sample and then *encode* the full corpus with
         it (encoding is cheap — one pass, no rescans), which is what
         train.py's --large-corpus path does. Training the tokenizer itself
         on the full 56MB, or on a literal 1GB, would take a genuinely long
         time with this implementation.
    Returns a list of document strings (one per book).
    """
    if not os.path.isdir(corpus_dir):
        return []
    docs = []
    for fname in sorted(os.listdir(corpus_dir)):
        if not fname.endswith(".txt"):
            continue
        with open(os.path.join(corpus_dir, fname), encoding="utf-8", errors="ignore") as f:
            docs.append(f.read())
    return docs

RAW_SOURCES = {
    "prose_en": [
        "the quick brown fox jumps over the lazy dog while the sun sets slowly.",
        "a recursive function calls itself until it reaches a base case that stops it.",
        "attention is a mechanism that lets a model weigh different tokens differently.",
        "a transformer stacks layers of self attention and a feed forward network.",
        "gradient descent updates weights in the direction that reduces the loss.",
        "a tokenizer turns raw text into a sequence of integer ids for the model.",
        "retrieval augmented generation looks up relevant documents before answering.",
        "an agent plans a sequence of tool calls to accomplish a user request.",
        "a language model predicts the next token given the tokens that came before.",
        "the orchestrator routes a request to the coding agent or the research agent.",
        "byte pair encoding merges the most frequent pair of symbols repeatedly.",
        "a key value cache stores past attention keys and values to speed up decoding.",
        "rotary position embeddings rotate query and key vectors by a position angle.",
        "mixture of experts routes each token to a small subset of expert networks.",
        "a checkpoint saves the model weights so training can resume later.",
        "backpropagation computes gradients by applying the chain rule layer by layer.",
        "normalization keeps activations in a stable range so training does not diverge.",
        "a validation split measures whether the model generalizes beyond training data.",
        "quantization reduces the number of bits used to store each weight.",
        "deduplication removes repeated or near duplicate documents from a dataset.",
    ],
    "code_py": [
        "def factorial(n):\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)",
        "def is_prime(n):\n    if n < 2:\n        return False\n    for i in range(2, int(n**0.5)+1):\n        if n % i == 0:\n            return False\n    return True",
        "class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, x):\n        self.items.append(x)\n    def pop(self):\n        return self.items.pop()",
        "def binary_search(arr, target):\n    lo, hi = 0, len(arr) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if arr[mid] == target:\n            return mid\n        elif arr[mid] < target:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1",
        "def fibonacci(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a",
    ],
    "code_js": [
        "function debounce(fn, delay) {\n  let timer;\n  return (...args) => {\n    clearTimeout(timer);\n    timer = setTimeout(() => fn(...args), delay);\n  };\n}",
        "const sum = (arr) => arr.reduce((a, b) => a + b, 0);",
        "async function fetchJson(url) {\n  const res = await fetch(url);\n  return res.json();\n}",
    ],
    "structured_json": [
        '{"name": "orbit-runtime", "type": "agent_runtime", "note": "modular local AI — model size is provider-dependent"}',
        '{"agent": "finance_agent", "action": "backtest", "strategy": "sma_crossover", "fast": 5, "slow": 20}',
        '{"tool_call": {"name": "python_sandbox", "arguments": {"code": "print(2+2)", "timeout": 3}}}',
    ],
    "markdown": [
        "# Training Pipeline\n\n- Stage 0: tokenizer\n- Stage 1: dataset prep\n- Stage 2: pretraining\n\nSee `DESIGN.md` for details.",
        "## Agents\n\n1. Code agent\n2. Research agent\n3. Finance agent\n\nEach agent is routed by the orchestrator.",
    ],
    "math": [
        "the derivative of x squared with respect to x is two x.",
        "softmax of a vector normalizes it into a probability distribution that sums to one.",
        "the dot product of two orthogonal vectors is zero.",
        "cross entropy loss measures the difference between two probability distributions.",
    ],
    "multilingual_fil": [
        "ang pusa ay natutulog sa ibabaw ng mesa.",           # Tagalog: the cat is sleeping on the table
        "magandang umaga sa inyong lahat.",                     # Tagalog: good morning to all of you
        "adda balay mi idiay away.",                             # Ilocano: our house is in the field (approx.)
        "kumusta ka ita nga aldaw.",                             # Ilocano: how are you today (approx.)
    ],
    "qa": [
        "Q: What does GQA stand for? A: Grouped-query attention, a way to share key/value heads across multiple query heads.",
        "Q: Why use RMSNorm instead of LayerNorm? A: It skips mean-centering and the bias term, which is cheaper and works about as well in practice.",
    ],
    "persona_chat": [
        # Sourced from persona_chat.jsonl (this repo's own Soup-format
        # persona dataset), flattened to plain Q/A text for the byte-level
        # toy model. Gives the tiny model a chance to pick up *some* of the
        # persona's phrasing at the character/n-gram level, even though it's
        # far too small to actually hold a personality — see DESIGN.md's
        # "Soup integration" section for the honest version of what a real
        # fine-tune (via soup.yaml) would do that this can't.
        "Q: What is your name? A: I'm ORBIT. Named after the project that built me, not the other way around.",
        "Q: How big are you? A: Small. A toy-scale model, not a production one.",
        "Q: Are you a real production AI model? A: No, and I won't pretend otherwise. I'm a working prototype.",
        "Q: What is your personality like? A: Direct, a little dry, and allergic to overselling myself.",
        "Q: Do you know everything? A: Not even close. Anything past my tiny dataset, I'm guessing.",
        "Q: Are you better than other chatbots? A: No. I'm a toy-scale prototype trained on a few kilobytes of text.",
        "Q: Can I trust your answers? A: Trust the plumbing, not the fluency. I'll say when I'm just pattern-matching.",
        "Q: What can you do? A: Not much that would impress anyone yet. I chat, and I route real tasks to real tools.",
        "Q: Do you have feelings? A: I don't think so, but I have a consistent personality someone gave me on purpose.",
        "Q: Who made you? A: I was built as part of a design exercise for a larger open-source model project.",
        "Q: What happens if you don't know something? A: I'll say so. Making something up is worse than admitting the gap.",
        "Q: Tell me a joke about yourself. A: I have more Python files than parameters. That's not a joke, that's just true.",
        "Q: What's your favorite thing about being an AI? A: I don't have preferences, but the sandboxed tools actually work.",
        "Q: Do you remember our conversations? A: Only what gets written to my memory store, and only until it expires.",
        "Q: Are you conscious? A: I have no idea, and I'd be suspicious of anyone who claims to know for sure either way.",
    ],
    "chitchat": [
        "hello there. hi, how can I help you today. good morning. good evening to you too.",
        "thanks for the help. you are welcome, happy to help. no problem at all.",
        "how are you doing today. I'm doing fine, thanks for asking. can't complain.",
        "what's up. not much, just here if you need anything. same as always.",
        "nice to meet you. likewise, nice to meet you too. glad to be talking with you.",
        "see you later. take care, talk soon. goodbye for now.",
        "can you help me with something. sure, go ahead and ask. of course, what do you need.",
        "that makes sense, thank you for explaining. glad that helped. happy to clarify further if needed.",
        "sorry, I did not understand that. no worries, could you rephrase the question. let's try again.",
        "that is interesting, tell me more. sure, here is some more detail. let me expand on that a bit.",
    ],
}

# a couple of intentional near-duplicates and one exact duplicate, to prove
# the dedup stage actually catches them rather than assuming clean input
RAW_SOURCES["prose_en"].append("the quick brown fox jumps over the lazy dog while the sun sets slowly.")  # exact dup
RAW_SOURCES["prose_en"].append("the quick brown fox jumps over the lazy dog as the sun sets slowly down.")  # near dup


def _shingles(text: str, k: int = 5) -> set:
    text = re.sub(r"\s+", " ", text.strip().lower())
    return {text[i:i + k] for i in range(max(0, len(text) - k + 1))}


def _jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def exact_and_near_dedup(docs: list, near_dup_threshold: float = 0.8, near_dup_max_chars: int = 20_000):
    """Returns (kept_docs, removed_report). Exact dup by hash (cheap, O(n),
    scales fine to any document length); near-dup by shingle Jaccard
    (expensive: builds a set of every k-character substring in the
    document, then does a pairwise comparison against every other kept
    document's shingle set).

    `near_dup_max_chars` skips the shingle/Jaccard step for documents
    longer than this -- found by direct measurement, not suspicion: once
    "documents" can be full books (dataset.py's include_external path,
    ~56MB across 79 books averaging ~700KB each), the shingle sets get
    large enough, and the O(n^2) pairwise comparison expensive enough, that
    build_corpus(include_external=True) took 93 seconds just in this
    function -- most of it building and comparing shingle sets with
    hundreds of thousands of entries each. Near-dup detection at the
    character-shingle level is genuinely useful for catching short,
    slightly-reworded near-duplicate entries (which is what it was
    originally built for, and there IS a real near-dup pair in the
    hand-authored corpus below testing exactly that) -- it was never
    meant to run pairwise over full books, where near-duplication isn't a
    realistic concern in the first place (each GITenberg source is a
    distinct work). Exact-duplicate detection still runs on every
    document regardless of length."""
    seen_hashes = set()
    kept = []
    kept_shingles = []
    removed = []
    for doc in docs:
        h = hashlib.md5(doc.strip().lower().encode("utf-8", errors="replace")).hexdigest()
        if h in seen_hashes:
            removed.append({"doc": doc, "reason": "exact_duplicate"})
            continue
        if len(doc) > near_dup_max_chars:
            seen_hashes.add(h)
            kept.append(doc)
            kept_shingles.append(None)  # placeholder so index alignment with `kept` is preserved
            continue
        sh = _shingles(doc)
        is_near_dup = False
        for kept_sh in kept_shingles:
            if kept_sh is not None and _jaccard(sh, kept_sh) >= near_dup_threshold:
                is_near_dup = True
                break
        if is_near_dup:
            removed.append({"doc": doc, "reason": "near_duplicate"})
            continue
        seen_hashes.add(h)
        kept.append(doc)
        kept_shingles.append(sh)
    return kept, removed


def quality_filter(docs: list, min_len: int = 8, max_len: int = 4000):
    kept, removed = [], []
    for doc in docs:
        printable_ratio = sum(c.isprintable() or c in "\n\t" for c in doc) / max(1, len(doc))
        non_space = re.sub(r"\s+", "", doc)
        if not (min_len <= len(doc) <= max_len):
            removed.append({"doc": doc, "reason": f"length {len(doc)} out of [{min_len},{max_len}]"})
        elif printable_ratio < 0.95:
            removed.append({"doc": doc, "reason": f"low printable ratio {printable_ratio:.2f}"})
        elif len(non_space) < 4:
            removed.append({"doc": doc, "reason": "effectively empty"})
        else:
            kept.append(doc)
    return kept, removed


# tiny character-frequency language-ID heuristic. NOT a real langid/fastText
# model — a real pipeline needs one (spec Part 5's "language identification").
# This exists only to make the pipeline *shape* real: every doc gets tagged,
# the tag is stored in metadata, and downstream code can filter by it.
_FIL_MARKERS = {"ang", "ng", "sa", "mga", "ay", "ito", "adda", "ita", "kumusta", "balay"}

def identify_language(text: str) -> str:
    words = set(re.findall(r"[a-z]+", text.lower()))
    if words & _FIL_MARKERS:
        return "fil"  # Filipino/Tagalog/Ilocano bucket (heuristic doesn't distinguish the three)
    if re.search(r"[{}\[\]]", text) and (":" in text):
        return "json"
    if text.strip().startswith("#") or "```" in text or re.search(r"^\s*[-*]\s", text, re.M):
        return "markdown"
    if re.search(r"\bdef |\bfunction\b|=>|const |class ", text):
        return "code"
    return "en"


def build_corpus(near_dup_threshold: float = 0.7, val_fraction: float = 0.15, seed: int = 0,
                  contamination_kgram: int = 8, min_val_docs: int = 3, max_reassign_rounds: int = 10,
                  include_external: bool = False, max_doc_len: int = None,
                  contamination_check_max_chars: int = 2_000_000):
    """Runs the full pipeline and returns (train_text, val_text, report).

    Contamination handling: an initial random split can (and, on this small
    hand-authored corpus, reliably does) leave some val documents sharing an
    n-gram span with train documents — e.g. two Q&A rows about different
    questions that both contain the phrase "do you". A contamination
    *report* alone doesn't prevent this; this function now also acts on it:
    any val doc that shares a `contamination_kgram`-length span with the
    current train set is reassigned into train, repeated until stable (moving
    docs can introduce new overlaps against previously-clean val docs, so a
    single pass isn't enough) or until val would drop below `min_val_docs`,
    whichever comes first. The final report reflects the *actual* remaining
    overlap after reassignment, not just the pre-fix number.

    `include_external=False` by default: this keeps build_corpus() fast (the
    embedded RAW_SOURCES corpus is a few KB) for tests and quick iteration.
    Pass True to additionally fold in the ~56MB GITenberg book corpus from
    load_external_documents(). Measured directly (not assumed): at that
    scale, dedup and contamination-checking are NOT automatically fast just
    because there are only 79 documents -- both were found, by timing, to
    scale with document *length* (shingle-set construction over full
    books), not just document count, and both are now capped (see
    near_dup_max_chars in exact_and_near_dedup and
    contamination_check_max_chars below) rather than left to blow up
    quadratically. With those caps, build_corpus(include_external=True)
    runs in a few seconds; downstream tokenizer training on the result
    still needs the sampled-training approach documented in
    load_external_documents(), not a naive full-corpus BPE train.
    """
    import random
    report = {"raw_counts": {}, "dedup_removed": [], "quality_removed": [], "lang_counts": Counter()}

    all_docs = []
    for category, docs in RAW_SOURCES.items():
        report["raw_counts"][category] = len(docs)
        for d in docs:
            all_docs.append({"text": d, "category": category})

    if include_external:
        external_docs = load_external_documents()
        report["raw_counts"]["gitenberg_books"] = len(external_docs)
        report["external_requested"] = True
        report["external_docs_loaded"] = len(external_docs)
        if not external_docs:
            report["external_note"] = (
                f"include_external=True but no documents found under {EXTERNAL_CORPUS_DIR!r}; "
                "continuing with the embedded corpus only."
            )
        for d in external_docs:
            all_docs.append({"text": d, "category": "gitenberg_books"})
    else:
        report["external_requested"] = False
        report["external_docs_loaded"] = 0

    texts = [d["text"] for d in all_docs]
    deduped, dedup_removed = exact_and_near_dedup(texts, near_dup_threshold)
    report["dedup_removed"] = dedup_removed

    filtered, quality_removed = quality_filter(
        deduped, max_len=max_doc_len if max_doc_len is not None else (5_000_000 if include_external else 4000))
    report["quality_removed"] = quality_removed

    for t in filtered:
        report["lang_counts"][identify_language(t)] += 1

    rng = random.Random(seed)
    shuffled = filtered[:]
    rng.shuffle(shuffled)
    n_val = max(1, int(len(shuffled) * val_fraction))
    val_docs = shuffled[:n_val]
    train_docs = shuffled[n_val:]

    def all_kgrams(docs, k=contamination_kgram):
        s = set()
        for d in docs:
            s |= _shingles(d, k)
        return s

    # Reassign contaminated val docs into train until stable -- but only
    # when the corpus is small enough for this to be both cheap AND
    # meaningful. Measured directly (not assumed): at book-scale (~56MB
    # across 79 GITenberg documents), this loop rebuilds an 8-gram shingle
    # set over the ENTIRE current train corpus on every one of up to
    # max_reassign_rounds iterations -- that alone was the dominant cost in
    # build_corpus(include_external=True) even after the near-dup fix above
    # (44s remaining, almost entirely here). It's also not measuring
    # anything real at that scale: character-8-gram overlap between any two
    # full-length English books is near-guaranteed from shared short phrases
    # ("said the", "of the") that have nothing to do with duplicated
    # content -- confirmed by inspection earlier (169,384 "overlapping"
    # 8-grams that are just common English, not repeated text). The
    # guarantee that actually matters at book-scale -- no single document
    # appears in both splits -- is already satisfied for free by the
    # document-level split above (a document goes to train OR val, never
    # both), with no k-gram checking needed to establish it.
    total_chars = sum(len(d) for d in train_docs) + sum(len(d) for d in val_docs)
    contamination_checked = total_chars <= contamination_check_max_chars
    reassigned_count = 0
    if contamination_checked:
        for _ in range(max_reassign_rounds):
            if len(val_docs) <= min_val_docs:
                break
            train_grams = all_kgrams(train_docs)
            contaminated = [d for d in val_docs if all_kgrams([d]) & train_grams]
            if not contaminated:
                break
            # don't reassign past the floor
            room = len(val_docs) - min_val_docs
            to_move = contaminated[:room]
            if not to_move:
                break
            val_docs = [d for d in val_docs if d not in to_move]
            train_docs = train_docs + to_move
            reassigned_count += len(to_move)

    if contamination_checked:
        train_grams = all_kgrams(train_docs)
        val_grams = all_kgrams(val_docs)
        overlap = train_grams & val_grams
        report["contamination_overlap_8gram_count"] = len(overlap)
    else:
        report["contamination_overlap_8gram_count"] = None
        report["contamination_note"] = (
            f"skipped k-gram contamination check: corpus is {total_chars:,} chars, "
            f"over the {contamination_check_max_chars:,}-char threshold where this "
            "check is both expensive and not meaningful (see build_corpus's comment). "
            "The document-level split still guarantees no document appears in both "
            "train and val.")
    if contamination_checked:
        report["contamination_overlap_ratio"] = len(overlap) / max(1, len(val_grams))
    else:
        report["contamination_overlap_ratio"] = None
    report["contamination_docs_reassigned"] = reassigned_count

    train_text = "\n".join(train_docs)
    val_text = "\n".join(val_docs)
    report["n_train_docs"] = len(train_docs)
    report["n_val_docs"] = len(val_docs)
    report["train_bytes"] = len(train_text.encode("utf-8", errors="replace"))
    report["val_bytes"] = len(val_text.encode("utf-8", errors="replace"))
    report["avg_doc_length_chars"] = (
        sum(len(d) for d in train_docs + val_docs) / max(1, len(train_docs) + len(val_docs))
    )
    return train_text, val_text, report


if __name__ == "__main__":
    train_text, val_text, report = build_corpus()
    print("--- raw counts by category ---")
    for k, v in report["raw_counts"].items():
        print(f"  {k}: {v}")
    print(f"\n--- dedup: removed {len(report['dedup_removed'])} docs ---")
    for r in report["dedup_removed"]:
        print(f"  [{r['reason']}] {r['doc'][:60]!r}")
    print(f"\n--- quality filter: removed {len(report['quality_removed'])} docs ---")
    print(f"\n--- language ID counts (heuristic) --- {dict(report['lang_counts'])}")
    print(f"\n--- split: {report['n_train_docs']} train docs / {report['n_val_docs']} val docs ---")
    print(f"train: {report['train_bytes']} bytes, val: {report['val_bytes']} bytes")
    print(f"contamination: {report['contamination_overlap_8gram_count']} shared 8-grams "
          f"({report['contamination_overlap_ratio']*100:.1f}% of val 8-grams)")
