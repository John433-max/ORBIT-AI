"""Tests for context.py — ConversationStore (Phase 31 basics) and
build_context's priority ordering / token budgeting (Phase 8)."""
import os
import json
import pytest

from bpe_tokenizer import BPETokenizer
from context import ConversationStore, build_context


@pytest.fixture(scope="module")
def tokenizer():
    corpus = "the quick brown fox jumps over the lazy dog what is your name nice to meet you"
    return BPETokenizer().train(corpus, vocab_size=300)


@pytest.fixture
def store(tmp_path):
    s = ConversationStore(str(tmp_path / "conv.db"))
    yield s
    s.close()


# --- ConversationStore ---

def test_add_and_get_recent_chronological_order(store):
    store.add_message("c1", "user", "first")
    store.add_message("c1", "assistant", "second")
    store.add_message("c1", "user", "third")
    recent = store.get_recent("c1", limit=10)
    assert [m["content"] for m in recent] == ["first", "second", "third"]


def test_get_recent_respects_limit(store):
    for i in range(5):
        store.add_message("c1", "user", f"msg{i}")
    recent = store.get_recent("c1", limit=2)
    assert [m["content"] for m in recent] == ["msg3", "msg4"]


def test_conversations_are_isolated_by_id(store):
    store.add_message("c1", "user", "hello from c1")
    store.add_message("c2", "user", "hello from c2")
    assert [m["content"] for m in store.get_recent("c1")] == ["hello from c1"]
    assert [m["content"] for m in store.get_recent("c2")] == ["hello from c2"]


def test_list_conversations(store):
    store.add_message("c1", "user", "a")
    store.add_message("c2", "user", "b")
    convs = {c["conversation_id"] for c in store.list_conversations()}
    assert convs == {"c1", "c2"}


def test_search_finds_matching_content(store):
    store.add_message("c1", "user", "my favorite color is blue")
    store.add_message("c1", "user", "totally unrelated message")
    hits = store.search("favorite color")
    assert len(hits) == 1
    assert "blue" in hits[0]["content"]


def test_delete_conversation(store):
    store.add_message("c1", "user", "to be deleted")
    n = store.delete_conversation("c1")
    assert n == 1
    assert store.get_recent("c1") == []


def test_export_json_and_txt_and_md(store):
    store.add_message("c1", "user", "hi")
    store.add_message("c1", "assistant", "hello")
    as_json = json.loads(store.export_conversation("c1", "json"))
    assert len(as_json) == 2
    as_txt = store.export_conversation("c1", "txt")
    assert "user: hi" in as_txt
    as_md = store.export_conversation("c1", "md")
    assert "**user**" in as_md


def test_export_unsupported_format_raises(store):
    store.add_message("c1", "user", "hi")
    with pytest.raises(ValueError):
        store.export_conversation("c1", "pdf")


# --- build_context ---

def test_current_message_always_present(tokenizer):
    result = build_context(tokenizer, "What is my name?", max_tokens=100)
    assert "What is my name?" in result["prompt"]
    assert result["included"]["system"] is True


def test_never_exceeds_budget_when_content_is_trimmable(tokenizer, store):
    store.add_message("c1", "user", "message " * 50)
    result = build_context(tokenizer, "short question", conversation_id="c1",
                            conversation_store=store, system_message="short system",
                            max_tokens=80)
    assert result["token_count"] <= 80
    # the full 50-word message clearly can't fit in 80 tokens total alongside
    # the mandatory blocks, so trimming must have actually happened
    assert "message message message message message message" not in result["prompt"]


def test_current_message_included_even_under_tiny_budget(tokenizer):
    result = build_context(tokenizer, "What is my name?", max_tokens=2)
    assert "What is my name?" in result["prompt"]


def test_memory_appears_before_conversation_in_priority(tokenizer, store):
    store.add_message("c1", "user", "earlier turn")
    result = build_context(tokenizer, "question", conversation_id="c1", conversation_store=store,
                            memory_hits=[{"text": "important fact"}], max_tokens=300)
    assert result["prompt"].index("important fact") < result["prompt"].index("earlier turn")


def test_included_report_matches_actual_prompt_content(tokenizer, store):
    """Regression test for a real bug: `included` used to report a
    conversation turn as included even when budget trimming removed it
    from the final prompt entirely."""
    store.add_message("c1", "user", "message " * 40)
    result = build_context(tokenizer, "q", conversation_id="c1", conversation_store=store, max_tokens=25)
    if result["included"]["conversation_turns"] == 0:
        assert "[recent conversation]" not in result["prompt"]
    else:
        assert "[recent conversation]" in result["prompt"]


def test_document_hits_include_citation(tokenizer):
    result = build_context(tokenizer, "question", document_hits=[
        {"text": "some fact", "filename": "doc.txt", "location": "page 3"}
    ], max_tokens=300)
    assert "doc.txt" in result["prompt"]
    assert "page 3" in result["prompt"]


def test_recent_conversation_keeps_most_recent_when_truncated(tokenizer, store):
    store.add_message("c1", "user", "old message that is fairly long and detailed")
    store.add_message("c1", "assistant", "reply")
    store.add_message("c1", "user", "newest message")
    result = build_context(tokenizer, "q", conversation_id="c1", conversation_store=store, max_tokens=40)
    if "[recent conversation]" in result["prompt"]:
        # if anything survived truncation, it should be the newest turn, not the oldest
        assert "newest message" in result["prompt"] or "reply" in result["prompt"]
