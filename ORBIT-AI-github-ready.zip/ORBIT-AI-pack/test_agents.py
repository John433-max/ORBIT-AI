"""Tests for agents.py — orchestrator routing, verification, and the
execution-logging (elapsed_ms/error) added in this pass."""
import pytest

from agents import Orchestrator, DataAgent, Verifier, AgentResult


@pytest.fixture
def orch():
    return Orchestrator()


def test_routes_code_request_to_code_agent(orch):
    result = orch.handle("```python\nprint(2+2)\n```")
    assert result["agent"] == "coding_agent"
    assert "4" in result["content"]


def test_routes_data_request_to_data_agent(orch):
    result = orch.handle("what is the mean and std of 1 2 3 4 5")
    assert result["agent"] == "data_agent"
    assert result["ok"] is True


def test_routes_finance_request_to_finance_agent(orch):
    result = orch.handle("run a backtest on this trading strategy")
    assert result["agent"] == "finance_agent"


def test_routes_memory_remember_to_memory_agent(orch):
    result = orch.handle("remember: the user's favorite color is teal")
    assert result["agent"] == "memory_agent"
    assert result["ok"] is True


def test_memory_roundtrip_through_orchestrator(orch):
    orch.handle("remember: the sky is blue on a clear day")
    result = orch.handle("what do you remember about the sky")
    assert result["agent"] == "memory_agent"
    assert result["ok"] is True


def test_unmatched_request_falls_back_to_chat(orch):
    result = orch.handle("hello there")
    assert result["agent"] == "main_chat_agent"


def test_persona_knowledge_base_actually_loads():
    """Regression test for a real bug: MainChatAgent's default persona_path
    was 'soup_data/persona_chat.jsonl', but the file actually ships at
    top-level 'persona_chat.jsonl' -- the mismatch was silently swallowed
    (FileNotFoundError -> _loaded=0), meaning the retrieval-first chat path
    was never functional; every chat request fell through to the raw
    generation/hedge fallback regardless of whether a persona entry
    actually matched."""
    from agents import MainChatAgent
    agent = MainChatAgent()
    assert agent._loaded > 0, "persona knowledge base failed to load from its default path"


def test_persona_match_returns_the_real_persona_answer(orch):
    result = orch.handle("what is your name")
    assert result["agent"] == "main_chat_agent"
    assert result["ok"] is True
    assert "ORBIT" in result["content"]
    assert "hedge" not in result["content"].lower()
    assert "no trained answer" not in result["content"].lower()


def test_routes_arithmetic_to_calculator_agent(orch):
    result = orch.handle("what is 12 * 7")
    assert result["agent"] == "calculator_agent"
    assert "84" in result["content"]


def test_routes_traceback_to_debug_agent(orch):
    result = orch.handle("I got a ModuleNotFoundError: No module named 'numpy'")
    assert result["agent"] == "debug_agent"
    assert result["ok"] is True


def test_routes_document_summarize_to_document_agent(orch):
    result = orch.handle("summarize document #1")
    assert result["agent"] == "document_agent"


def test_document_agent_answers_from_uploaded_document(orch):
    orch.documents.add_document(
        "orbit_notes.txt",
        b"ORBIT is a small research prototype built with NumPy. "
        b"It is not a 100 billion parameter model.",
    )
    result = orch.handle("according to the document, is ORBIT a real 100B model")
    assert result["agent"] == "document_agent"
    if result["ok"]:
        assert "orbit_notes.txt" in result["content"]


def test_route_log_records_timing_and_outcome(orch):
    orch.handle("what is the mean of 1 2 3")
    assert len(orch.route_log) == 1
    entry = orch.route_log[0]
    assert "elapsed_ms" in entry and entry["elapsed_ms"] >= 0
    assert "error" in entry
    assert entry["error"] is None


def test_data_agent_reports_no_numbers_found():
    result = DataAgent().run("no numbers here at all", {})
    assert result.ok is False


def test_verifier_rejects_empty_content():
    v = Verifier()
    checked = v.check(AgentResult("some_agent", True, ""))
    assert checked.ok is False


def test_verifier_rejects_leaked_traceback_from_non_code_agent():
    v = Verifier()
    checked = v.check(AgentResult("data_agent", True, "Traceback (most recent call last):\n..."))
    assert checked.ok is False


def test_verifier_allows_traceback_from_code_agent():
    v = Verifier()
    checked = v.check(AgentResult("coding_agent", True, "Traceback (most recent call last):\n..."))
    assert checked.ok is True


def test_stable_seed_reproducible_across_calls():
    """Regression test for a real bug: FinanceAgent and MainChatAgent used
    Python's built-in hash(request) as a seed source. CPython randomizes
    str hashing per-process by default, so the same request text produced
    a different seed -- and therefore different synthetic backtest
    results / different generated text -- every time the process
    restarted. Verified directly: hash() gave 3 different values for the
    same string across 3 separate `python3 -c` invocations; stable_seed
    gives the same value every time."""
    from agents import stable_seed
    assert stable_seed("what is your name") == stable_seed("what is your name")
    assert stable_seed("a") != stable_seed("b")


def test_finance_agent_reproducible_for_same_request(orch):
    result1 = orch.handle("run a backtest on this trading strategy")
    result2 = orch.handle("run a backtest on this trading strategy")
    assert result1["content"] == result2["content"]


def test_finance_agent_result_carries_structured_transparency_fields(orch):
    """Spec requirement: finance responses must clearly mark synthetic data
    with a structured field, not just a prose sentence a caller could miss
    by only reading `content`."""
    result = orch.handle("run a backtest on this trading strategy")
    assert result["raw"]["simulation"] is True
    assert result["raw"]["data_source"] == "synthetic"
    assert "not financial advice" in result["raw"]["warning"].lower()


def test_research_agent_default_is_honest_mock_not_fake_results(orch):
    """ResearchAgent uses MockSearchProvider, which now tries live DuckDuckGo
    and falls back to an honest offline message. Accept either path."""
    result = orch.handle("search for the latest AI news")
    assert result["agent"] in ("research_agent", "research")
    content = result["content"] or ""
    live = (
        "Search results" in content
        or "http" in content.lower()
        or "Here's what I found" in content
    )
    offline = "don't have live web access" in content
    # handle() marks ok=True whenever content is non-empty, so accept either
    # live snippets or the honest offline stub — never invented facts.
    assert live or offline


def test_research_agent_supports_injected_search_provider():
    """Spec-requested dependency injection: ResearchAgent must be testable
    against a fake provider without needing real network access."""
    from agents import ResearchAgent
    from tools import SearchProvider

    class FakeProvider(SearchProvider):
        def search(self, query):
            return {"ok": True, "note": "injected", "results": ["result A", "result B"]}

    agent = ResearchAgent(search_provider=FakeProvider())
    result = agent.run("anything", {})
    assert result.raw["ok"] is True
    assert result.raw["results"] == ["result A", "result B"]


def test_search_provider_base_class_raises_not_implemented():
    from tools import SearchProvider
    with pytest.raises(NotImplementedError):
        SearchProvider().search("query")


def test_ambiguous_request_scores_multiple_agents(orch):
    """The spec's own example of a weak/multi-intent request that a pure
    keyword-first-match router would drop to chat entirely."""
    agent, scores = orch.route_with_scores("My Python code crashes")
    assert scores.get("code", 0) > 0
    assert scores.get("debug", 0) > 0
    assert agent in ("code", "debug")  # picks one, but both were real candidates


def test_run_and_explain_crash_request_scores_both_code_and_debug(orch):
    agent, scores = orch.route_with_scores("Can you run this Python program and explain why it crashes?")
    assert scores.get("code", 0) > 0
    assert scores.get("debug", 0) > 0


def test_clear_single_intent_request_scores_only_that_agent(orch):
    agent, scores = orch.route_with_scores("what is 2 + 2")
    assert agent == "calculator"
    assert scores.get("calculator") == 1.0


def test_unrelated_request_has_no_candidates(orch):
    agent, scores = orch.route_with_scores("hello there, how are you today")
    assert agent == "chat"
    assert scores == {}


def test_research_keyword_itself_now_routes_to_research(orch):
    """Regression test for a real (pre-existing, found while fixing
    routing) gap: the research route pattern never actually included the
    word 'research', so 'research the impact of AI on education' fell
    through to chat despite being an unambiguous research request."""
    result = orch.handle("research the impact of artificial intelligence on education")
    assert result["agent"] in ("research_agent", "research")


def test_route_with_scores_confidence_is_bounded_zero_to_one(orch):
    for request in ["what is 2+2", "my code crashes", "research this topic",
                     "remember my name", "hello", ""]:
        _, scores = orch.route_with_scores(request)
        for agent, score in scores.items():
            assert 0.0 <= score <= 1.0


def test_routing_is_deterministic_across_repeated_calls(orch):
    request = "My Python code crashes"
    results = {orch.route(request) for _ in range(20)}
    assert len(results) == 1  # same request always routes the same way


def test_route_log_is_bounded_not_unbounded(orch):
    """Regression test for a real bug: route_log used to be a plain list
    that grew on every single handle() call for the lifetime of the
    process -- worse than the similar AUDIT_LOG bug (tools.py) since ORCH
    is a long-lived singleton in api.py and route_log gets an entry on
    every request the API serves, not just sandbox executions."""
    for i in range(orch.route_log.maxlen + 200):
        orch.handle(f"what is your name {i}")
    assert len(orch.route_log) == orch.route_log.maxlen


def test_main_chat_agent_includes_history_in_raw_generation_prompt():
    """Regression test for a real, previously-unnoticed bug: the API's
    /v1/chat/completions request already carries full conversation history
    in `messages`, but nothing downstream of extracting the last user
    message ever looked at anything else -- "My name is John." / "Nice to
    meet you." / "What is my name?" had the first two turns silently
    discarded. Verifies the constructed prompt actually contains prior
    turns, not that the (tiny, honestly-limited) model correctly
    'understands' them -- that's a separate, already-documented limitation."""
    from agents import MainChatAgent
    from model import TinyLM
    from bpe_tokenizer import BPETokenizer

    tok = BPETokenizer().train("hello my name is john nice to meet you what", vocab_size=300)
    model = TinyLM(vocab_size=tok.VOCAB_SIZE, d_model=16, n_layers=1, n_heads=2, n_kv_heads=1,
                    max_seq_len=64, seed=0)
    agent = MainChatAgent(model=model, tokenizer=tok)

    captured_prompts = []
    original_encode = tok.encode
    def spy_encode(text, **kwargs):
        captured_prompts.append(text)
        return original_encode(text, **kwargs)
    tok.encode = spy_encode

    agent._generate_raw("what is my name", history=[
        {"role": "user", "content": "my name is john"},
        {"role": "assistant", "content": "nice to meet you"},
    ])
    assert len(captured_prompts) == 1
    assert "my name is john" in captured_prompts[0]
    assert "nice to meet you" in captured_prompts[0]


def test_main_chat_agent_works_with_no_history_backward_compatible():
    """history=None (or omitted) must behave exactly as before this fix."""
    from agents import MainChatAgent
    from model import TinyLM
    from bpe_tokenizer import BPETokenizer

    tok = BPETokenizer().train("hello world test", vocab_size=300)
    model = TinyLM(vocab_size=tok.VOCAB_SIZE, d_model=16, n_layers=1, n_heads=2, n_kv_heads=1,
                    max_seq_len=64, seed=0)
    agent = MainChatAgent(model=model, tokenizer=tok)
    result = agent._generate_raw("hello")  # no history argument at all
    assert isinstance(result, str)


def test_orchestrator_handle_passes_history_through_to_chat_agent(orch):
    """history is threaded through Orchestrator.handle() -> context dict ->
    agent.run(), without affecting routing (which still keys off the
    current request alone)."""
    received = {}

    class SpyAgent:
        name = "chat"
        def run(self, request, context):
            received["history"] = context.get("history")
            from agents import AgentResult
            return AgentResult("main_chat_agent", True, "ok")

    orch.agents["chat"] = SpyAgent()
    orch.handle("hello", history=[{"role": "user", "content": "prior turn"}])
    assert received["history"] == [{"role": "user", "content": "prior turn"}]
