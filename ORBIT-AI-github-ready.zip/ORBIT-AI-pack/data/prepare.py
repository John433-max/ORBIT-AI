"""
Dataset preparation entry (ORBIT v2 Phase 6 scaffold).

Wraps dataset.build_corpus and writes summary stats under data/processed/.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser(description="Prepare ORBIT train/val text")
    p.add_argument("--external", action="store_true", help="Include GITenberg if present")
    p.add_argument("--out-dir", default="data/processed")
    args = p.parse_args(argv)

    from dataset import build_corpus

    train_text, val_text, report = build_corpus(include_external=args.external)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "train.txt").write_text(train_text, encoding="utf-8")
    (out / "val.txt").write_text(val_text, encoding="utf-8")
    with open(out / "report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    print(f"Wrote {out}/train.txt ({len(train_text)} chars)")
    print(f"Wrote {out}/val.txt ({len(val_text)} chars)")
    print(f"Report → {out}/report.json")
    print("docs:", report.get("n_train_docs"), "train /", report.get("n_val_docs"), "val")


if __name__ == "__main__":
    main()
