"""
Tests for model_torch.py. These require a real PyTorch install (see
requirements-torch.txt) -- the whole module is skipped cleanly if torch
isn't available, rather than failing the rest of the suite, since torch is
an optional heavyweight dependency (see model_torch.py's own docstring on
why: installing it in this project's own dev sandbox required freeing
several GB of disk space and was not a given).
"""
import pytest

torch = pytest.importorskip("torch")

from model_torch import TinyLMTorch


def test_forward_shape():
    m = TinyLMTorch(vocab_size=40, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    x = torch.randint(0, 40, (3, 8))
    out = m(x)
    assert out.shape == (3 * 8, 40)


def test_forward_backward_finite():
    m = TinyLMTorch(vocab_size=30, d_model=16, n_layers=1, n_heads=2, n_kv_heads=1, max_seq_len=6, seed=1)
    x = torch.randint(0, 30, (2, 6))
    out = m(x)
    loss = out.sum()
    loss.backward()
    for p in m.parameters():
        assert p.grad is not None
        assert torch.isfinite(p.grad).all()


def test_recursive_reasoning_variant_runs():
    m = TinyLMTorch(vocab_size=20, d_model=8, n_layers=1, n_heads=2, n_kv_heads=1,
                     max_seq_len=4, use_recursive_reasoning=True, n_sup=2, seed=2)
    x = torch.randint(0, 20, (1, 4))
    out = m(x)
    assert out.shape == (4, 20)
    out.sum().backward()


@pytest.mark.parametrize("kwargs", [
    dict(vocab_size=10, d_model=15, n_heads=4, n_kv_heads=2, max_seq_len=4),
    dict(vocab_size=10, d_model=16, n_heads=4, n_kv_heads=3, max_seq_len=4),
    dict(vocab_size=10, d_model=16, n_heads=2, n_kv_heads=4, max_seq_len=4),
    dict(vocab_size=0, d_model=16, n_heads=2, n_kv_heads=2, max_seq_len=4),
    dict(vocab_size=10, d_model=16, n_heads=2, n_kv_heads=2, max_seq_len=0),
])
def test_invalid_configs_rejected(kwargs):
    with pytest.raises(ValueError):
        TinyLMTorch(**kwargs)


def test_sequence_too_long_rejected():
    m = TinyLMTorch(vocab_size=10, d_model=8, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    with pytest.raises(ValueError):
        m(torch.zeros((1, 10), dtype=torch.long))


def test_out_of_range_token_id_rejected():
    m = TinyLMTorch(vocab_size=10, d_model=8, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    with pytest.raises(ValueError):
        m(torch.tensor([[0, 1, 2, 999]]))


def test_param_count_matches_numpy_model_for_identical_config():
    """The strongest correctness check available without a full numerical
    parity test (see model_torch.py's verification-status note): if the
    architectures genuinely correspond, an identical config must produce
    an identical parameter count on both backends, since parameter count
    is a direct function of every weight matrix's shape."""
    from model import TinyLM
    kwargs = dict(vocab_size=50, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    torch_model = TinyLMTorch(**kwargs)
    numpy_model = TinyLM(**kwargs)
    assert torch_model.param_count() == numpy_model.param_count()


def test_param_count_matches_numpy_model_with_recursive_reasoning():
    from model import TinyLM
    kwargs = dict(vocab_size=30, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8,
                  use_recursive_reasoning=True, n_sup=3, seed=0)
    torch_model = TinyLMTorch(**kwargs)
    numpy_model = TinyLM(**kwargs)
    assert torch_model.param_count() == numpy_model.param_count()


def test_training_loop_actually_reduces_loss():
    """Not just "doesn't crash" -- confirms gradients are actually
    informative and the optimizer step genuinely improves the model on a
    trivial task (predict the next token in a short repeating pattern)."""
    import torch.nn.functional as F
    torch.manual_seed(0)
    vocab_size = 10
    m = TinyLMTorch(vocab_size=vocab_size, d_model=32, n_layers=2, n_heads=4, n_kv_heads=2,
                     max_seq_len=8, seed=0)
    opt = torch.optim.Adam(m.parameters(), lr=1e-2)
    pattern = torch.tensor([[1, 2, 3, 4, 1, 2, 3, 4]])
    x, y = pattern[:, :-1], pattern[:, 1:]

    losses = []
    for _ in range(50):
        opt.zero_grad()
        logits = m(x)[: y.numel()]
        loss = F.cross_entropy(logits, y.reshape(-1))
        loss.backward()
        opt.step()
        losses.append(loss.item())

    assert losses[-1] < losses[0] * 0.5  # substantial, not just noise-level, improvement


def test_gradients_flow_to_tied_embedding_from_both_input_and_output_use():
    """tok_emb is used twice -- once as the input embedding lookup, once
    (transposed) as the output projection. Both usages must contribute
    gradient to the same parameter; a bug that only wired up one path
    would still produce a working forward pass but silently undertrain
    the embedding table."""
    m = TinyLMTorch(vocab_size=20, d_model=8, n_layers=1, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    x = torch.randint(0, 20, (1, 4))
    m(x).sum().backward()
    assert m.tok_emb.grad is not None
    assert torch.isfinite(m.tok_emb.grad).all()
    assert m.tok_emb.grad.abs().sum() > 0


def test_checkpoint_save_and_load_roundtrip(tmp_path):
    from model_torch import save_checkpoint_torch, build_torch_model_from_checkpoint
    m = TinyLMTorch(vocab_size=30, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    path = str(tmp_path / "ckpt.pt")
    save_checkpoint_torch(m, path, metadata={
        "d_model": 16, "n_layers": 2, "n_heads": 4, "n_kv_heads": 2, "vocab_size": 30, "seq_len": 8,
    })
    rebuilt, meta = build_torch_model_from_checkpoint(path)
    assert rebuilt.param_count() == m.param_count()
    x = torch.randint(0, 30, (1, 8))
    assert torch.allclose(m(x), rebuilt(x))


def test_checkpoint_load_rejects_architecture_mismatch(tmp_path):
    from model_torch import save_checkpoint_torch, build_torch_model_from_checkpoint
    import json
    m = TinyLMTorch(vocab_size=30, d_model=16, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=8, seed=0)
    path = str(tmp_path / "ckpt.pt")
    save_checkpoint_torch(m, path, metadata={
        "d_model": 16, "n_layers": 2, "n_heads": 4, "n_kv_heads": 2, "vocab_size": 30, "seq_len": 8,
    })
    bad_meta_path = str(tmp_path / "bad.json")
    with open(bad_meta_path, "w") as f:
        json.dump({"d_model": 32, "n_layers": 2, "n_heads": 4, "n_kv_heads": 2,
                   "vocab_size": 30, "seq_len": 8}, f)
    with pytest.raises(RuntimeError):
        build_torch_model_from_checkpoint(path, json_path=bad_meta_path)


def test_checkpoint_missing_metadata_fields_raises(tmp_path):
    from model_torch import save_checkpoint_torch, build_torch_model_from_checkpoint
    m = TinyLMTorch(vocab_size=20, d_model=8, n_layers=1, n_heads=2, n_kv_heads=1, max_seq_len=4, seed=0)
    path = str(tmp_path / "ckpt.pt")
    save_checkpoint_torch(m, path, metadata={"config": "incomplete"})
    with pytest.raises(ValueError, match="missing required fields"):
        build_torch_model_from_checkpoint(path)
