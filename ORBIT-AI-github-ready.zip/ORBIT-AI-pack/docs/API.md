# ORBIT API — OpenAI Compatibility

Base URL (local): `http://127.0.0.1:8000`

## Supported OpenAI-style endpoints

| Method | Path | Status |
|--------|------|--------|
| GET | `/v1/models` | Yes |
| GET | `/v1/models/{model_id}` | Yes |
| POST | `/v1/chat/completions` | Yes (stream + non-stream) |
| POST | `/v1/completions` | Yes (stream + non-stream) |
| POST | `/v1/embeddings` | Yes (hash embeddings) |

Also: `/health`, `/`, Web UI, and `/v2/*` extensions.

## Models

- `orbit-toy` — default chat / completion model  
- `orbit-tiny` — alias for the tiny config  
- `text-embedding-orbit-hash` — feature-hash embeddings (not a trained embedding model)

## Chat completions

```bash
curl -s http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "orbit-toy",
    "messages": [{"role": "user", "content": "what is your name"}],
    "temperature": 0.8,
    "max_tokens": 64,
    "stream": false
  }'
```

Streaming:

```bash
curl -N http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "orbit-toy",
    "messages": [{"role": "user", "content": "hello"}],
    "stream": true
  }'
```

Response includes `choices[].message`, `finish_reason`, and `usage`  
(`prompt_tokens`, `completion_tokens`, `total_tokens`).

Accepted message roles: `system`, `user`, `assistant`, `tool`, `function`.

## Completions (legacy)

```bash
curl -s http://127.0.0.1:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "orbit-toy",
    "prompt": "The history of AI begins",
    "max_tokens": 40,
    "temperature": 0.8
  }'
```

Supports: `prompt` (string or list), `max_tokens`, `temperature`, `top_p`, `top_k`,
`n`, `stop`, `echo`, `stream`.

## Embeddings

```bash
curl -s http://127.0.0.1:8000/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{
    "model": "text-embedding-orbit-hash",
    "input": ["hello world", "ORBIT platform"]
  }'
```

Optional `dimensions` (default 256). Returns OpenAI-style `data[].embedding` lists.

## Python client (openai package)

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8000/v1", api_key="orbit")

# Chat
r = client.chat.completions.create(
    model="orbit-toy",
    messages=[{"role": "user", "content": "what is your name"}],
)
print(r.choices[0].message.content)

# Completions
r = client.completions.create(model="orbit-toy", prompt="Hello", max_tokens=32)
print(r.choices[0].text)

# Embeddings
r = client.embeddings.create(model="text-embedding-orbit-hash", input="hello")
print(len(r.data[0].embedding))
```

## Limitations (honest)

- Token `usage` counts are approximate when not using the BPE tokenizer path.
- Embeddings are **hash-based**, not trained semantic embeddings.
- Tool/function-calling in the OpenAI JSON schema sense is not fully implemented
  on `/v1/chat/completions`; use `/v2/agent/run` for structured tool calls.
- No API key auth (local prototype).
- `logprobs`, `logit_bias`, and some advanced fields are accepted or ignored.
