# ORBIT v2 — Research notes (applied improvements)

Research date: 2026-09-17. Sources: modern small-LLM guides, miniGPT/from-scratch repos, OpenAI tool-calling docs, llama.cpp conversion docs.

## Architecture (confirmed — already in ORBIT)

Industry consensus for small dense models (2025–2026):

| Component | Status in ORBIT |
|-----------|-----------------|
| Decoder-only | Yes |
| Pre-norm RMSNorm | Yes |
| RoPE | Yes |
| SwiGLU | Yes |
| GQA | Yes |
| Tied embeddings (small models) | Yes |
| No bias in linear projections | Yes (NumPy/Torch paths) |
| Config-driven scale ladder | Yes (development → xxlarge) |

Optional future ablations (not claimed implemented):

- **QK-norm** (RMSNorm on Q/K before attention) — used in some Qwen3-style stacks
- **Residual init scale 1/√(2N)** — stabilizes deep stacks
- **YaRN / NTK RoPE scaling** — long-context extension
- **KV cache** — critical for fast generation (scaffold exists; full path TBD)

## Training recipe (aligned)

- AdamW + cosine LR + warmup + global grad clip — present in `training/trainer.py`
- Early stop / best checkpoint — present
- Data quality > architecture novelty for tiny models — matches DESIGN.md honesty

## Tool calling (applied)

OpenAI / Meta pattern:

1. App sends tool **schemas** with the request  
2. Model returns structured tool call(s) (JSON) — does **not** execute tools  
3. App executes tools, appends results  
4. Model produces final answer (or more tool calls)

ORBIT updates:

- `ToolRegistry.openai_tools()` — OpenAI `tools=[{type:function,...}]` format  
- `ToolCallingAgent.run` — plan → execute (possibly multi-step) → observations  
- Heuristic/JSON parsing until instruction-tuned tool calling exists  

## Export / GGUF (honest)

llama.cpp conversion expects **Hugging Face layout** (config + safetensors + tokenizer), then `convert_hf_to_gguf.py`.

ORBIT now:

- `export/checkpoint_export.py` — packs `.npz` + metadata + README  
- Does **not** claim GGUF/Ollama compatibility until HF conversion is tested  

## Packaging

- Prefer packages (`model/`, `tools/`) for imports  
- Top-level `model.py` / `tools.py` remain **compatibility shims** for classic paths  

## References (non-exhaustive)

- Self-training small LLM guides (RoPE/RMSNorm/SwiGLU/GQA template)
- miniGPT / llm-from-scratch open implementations
- OpenAI function calling / Agents SDK tool-use loop
- llama.cpp model conversion documentation

## Follow-up research (2026-09-17 evening)

### KV cache (Raschka / industry)
- Cache keys/values across decode steps; feed only the new token after the prompt.
- Full integration needs `use_cache` on attention + `reset_kv_cache()` — deferred
  so the educational NumPy path stays readable. Generation speed is measured
  honestly via `evaluation/bench_generate.py` + `logs/metrics.jsonl`.

### Agent tool design (Anthropic / Rubric / AgentPatterns)
- Prefer a **small** tool set with clear namespaces (`web.search`, `memory.add`).
- Bound tool output size (ORBIT: `MAX_TOOL_CONTENT_CHARS = 4000`).
- Engineer tool **descriptions** so routing/heuristics (and future LLM callers)
  know when to use each tool.
- Return high-signal text, not raw dumps.

### Streaming
- OpenAI Chat Completions SSE already implemented in `api.py`
  (`text/event-stream`, real token stream when a checkpoint is loaded).

### Metrics (Definition of Done)
- `monitoring.metrics.record_generation` writes real tok/s to `logs/metrics.jsonl`.
- No fabricated benchmark numbers in docs.
