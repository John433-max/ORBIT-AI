# ORBIT Architecture

## Two Model Implementations (Phase 3)

ORBIT deliberately maintains **two** implementations of the same conceptual architecture:

### A. Educational implementation (NumPy + custom autograd)

- **Location:** `model_numpy_legacy.py` (original) + modular re-exports under `model/`
- **Purpose:** Make every mathematical operation transparent. Gradients are hand-derived and numerically checked.
- **Engine:** `autograd.py` — reverse-mode autodiff written from scratch.
- **Use when:** Learning how transformers work, debugging numerics, running in extremely constrained environments (no PyTorch).

### B. Practical implementation (PyTorch)

- **Location:** `model_torch.py`
- **Purpose:** Actual training and scalable experimentation.
- **Engine:** PyTorch (CPU by default; CUDA if available, never assumed).
- **Use when:** Training larger configs, measuring throughput, preparing for cloud GPU runs.

Both share the same conceptual stack:

```
Token Embeddings (tied with LM head)
        │
        ▼
   Transformer Blocks × N
   ┌─────────────────────┐
   │  RMSNorm            │
   │  Causal GQA + RoPE  │
   │  Residual           │
   │  RMSNorm            │
   │  SwiGLU             │
   │  Residual           │
   └─────────────────────┘
        │
        ▼
   Final RMSNorm
        │
        ▼
   LM Head (tied)
```

Optional Architecture B bolt-on: recursive latent reasoning module (`ReasoningBlock`).

## Configuration System (Phase 1)

All important dimensions live in:

- `model/config.py` — dataclasses `ModelConfig`, `TrainingConfig`, `RuntimeConfig`, `OrbitConfig`
- `configs/*.yaml` — named presets

| Preset        | d_model | layers | heads | kv | context | vocab  | ~params   | ~weights fp32 |
|---------------|---------|--------|-------|----|---------|--------|-----------|---------------|
| development   | 64      | 2      | 4     | 2  | 64      | 1000   | 154k      | 0.6 MB        |
| tiny          | 128     | 4      | 8     | 4  | 128     | 1500   | 914k      | 3.5 MB        |
| small         | 256     | 6      | 8     | 4  | 256     | 3000   | 5.1M      | 19 MB         |
| medium        | 384     | 8      | 8     | 4  | 512     | 5000   | 14.9M     | 57 MB         |
| large         | 512     | 12     | 8     | 4  | 1024    | 8000   | 39.5M     | 151 MB        |
| xlarge        | 768     | 16     | 12    | 4  | 2048    | 16000  | 113M      | 431 MB        |
| xxlarge       | 1024    | 24     | 16    | 8  | 2048    | 32000  | 311M      | 1.2 GB        |

Parameter counts are estimates from `ModelConfig.estimate_parameters()`.
Larger configs are for scaling / cloud; do not assume a laptop can train them.

Load example:

```python
from model import TinyLM, get_preset, OrbitConfig

cfg = get_preset("tiny")                 # or OrbitConfig.load("configs/tiny.yaml")
model = TinyLM.from_config(cfg)
print(model.param_count())
```

## Package Layout (emerging)

```
model/
├── __init__.py
├── config.py
├── embeddings.py
├── rope.py
├── rmsnorm.py
├── attention.py
├── swiglu.py
├── transformer_block.py
├── model.py
└── generation.py

configs/
├── tiny.yaml
├── small.yaml
├── medium.yaml
└── development.yaml

tokenizer/   (Phase 5 — in progress)
training/    (Phase 8)
rag/         (Phase 15)
memory/      (Phase 14)
agent/       (Phase 19)
tools/       (Phase 16)
chat/        (Phase 13)
evaluation/  (Phase 10)
monitoring/  (Phase 26)
checkpoints/
docs/
```

The original top-level scripts (`train.py`, `agents.py`, `api.py`, …) remain the working entry points. New packages are added around them without deleting working functionality.

## Design Principles

1. Keep the educational NumPy path forever.
2. Never hard-code model dimensions inside model code.
3. Never assume CUDA.
4. Prefer modular packages but do not break existing imports or tests.
5. Measure before claiming performance numbers.
