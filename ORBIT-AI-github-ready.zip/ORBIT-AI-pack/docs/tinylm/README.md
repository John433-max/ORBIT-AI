# ORBIT TinyLM (educational)

Minimal decoder-only LM in NumPy and PyTorch with:

- GPT-2 residual projection init `1/sqrt(2N)`
- optional **GQA** (`n_kv_head`) and **SwiGLU** (`use_swiglu`); presets `gqa` / `modern`
- temperature / top-k / top-p sampling; cosine LR training helpers
- optional QK-Norm (RMSNorm on Q and K)
- optional attention logit soft-cap
- KV cache decode (preallocated)
- Torch SDPA when soft-cap is off
- `TinyLMConfig.preset("stable"|"rope"|"yarn"|"ntk")`
- optional RoPE on Q/K after QK-Norm (**no learned pos table** when enabled, Cycle 21)
- optional RoPE context scaling: linear / NTK-aware / YaRN (`rope_factor`)
- measured `torch.compile` cached decode (~2.7× CPU, Cycle 10)
- YaRN short→long trained NLL probe
- eval harness (NLL / PPL)
- QK-Norm training ablation
- weight-only INT8 (per-out) and INT4 group-32 quantization (educational WOQ)
- trained-checkpoint NLL probe for INT8/INT4 (Cycle 13)
- on-the-fly INT4 unpack+GEMM (`int4_linear`, Cycle 14)
- packed INT4 TinyLM decode (`Int4Linear` / `pack_model_int4`, Cycle 15)
- unpack-once FP32 cache on `Int4Linear` (`materialize` / `cache_fp32`, Cycle 16)
- drop packed INT4 buffers after materialize (`drop_packed`, Cycle 17)
- INT4 packed checkpoint serialize/reload (`save_int4_checkpoint` / `load_int4_checkpoint`, Cycle 18)
- pickle-free mmap INT4 checkpoint (`save_int4_mmap` / `load_int4_mmap`, Cycle 19)
- opt-in INT4 token/position embeddings (`quantize_embeddings`, Cycle 20)

```
python -m pytest tests -q
python -m orbit.run_cycle
```
