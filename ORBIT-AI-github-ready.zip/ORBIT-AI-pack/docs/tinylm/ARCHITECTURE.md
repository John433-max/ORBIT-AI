# ORBIT TinyLM Architecture (educational package)

**Location:** `artifacts/orbit/`

## Stack (defaults vs modern preset)

| Component | Default | `modern` preset |
|-----------|---------|-----------------|
| Positions | Learned absolute | RoPE (no pos table) |
| Attention | MHA | GQA (`n_kv_head = n_head/2`) |
| MLP | ReLU × 4 | SwiGLU (`ffn_mult ≈ 8/3`) |
| Norm | Pre-RMSNorm | + optional QK-Norm |
| Head | Tied embedding | Tied embedding |
| Softcap | off | off (SDPA-friendly) |
| Window | full causal | opt-in `sliding_window` / preset `swa` |

## Decode path

1. Prefill full prompt → write K/V into preallocated cache  
2. Step: last token only, `cache_pos` write  
3. Sampling: greedy / temperature / top-k / top-p / repetition penalty  
4. Cycle 54: if `sliding_window=W>0`, `alloc_kv_caches` caps length at W and writes a ring (`slot = pos % W`). Gather last `min(used, W)` keys in time order. RoPE is applied before the write, so wrap does not change angles.  

## Footprint tools

- INT8 / INT4 weight-only quant (`orbit.quantize`)  
- mmap INT4 checkpoints  
- `python -m orbit.cli kv-report` — GQA KV cache bytes vs MHA  

## CLI

```bash
python -m orbit.cli bench --preset rope
python -m orbit.cli generate --temperature 0.8 --top-k 20
python -m orbit.cli train --steps 40 --qk-norm --grad-accum 2
python -m orbit.cli card --preset modern
python -m orbit.cli kv-report --preset gqa --seq 256
```

## Tests

```bash
python -m pytest tests -q
```
