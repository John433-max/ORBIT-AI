# ORBIT v2 — Repository Audit (Phase 0)

**Date:** 2026-09-16  
**Scope:** Full inspection of the existing ORBIT prototype before any code changes.  
**Rule followed:** No source code was modified during this audit. Only inspection and documentation.

---

## 1. Executive Summary

ORBIT is a working from-scratch LLM + agent prototype. It already implements:

- Custom NumPy reverse-mode autograd engine
- Decoder-only Transformer (RMSNorm, RoPE, GQA, SwiGLU, tied embeddings) + optional recursive reasoning module
- Parallel PyTorch implementation of the same architecture
- Byte-level BPE tokenizer (trained, round-trip tested)
- Multi-category dataset pipeline with exact + near-duplicate detection
- Training loops (NumPy and optional PyTorch)
- Checkpoint save/load with metadata
- Nucleus + repetition-penalty sampling / generation
- RAG (retrieval + extractive answering, not generative)
- Feature-hashed vector memory (in-memory + SQLite)
- Rule-based multi-agent orchestrator + 10+ specialized agents
- Sandboxed tools (Python, filesystem, calculator, paper trading, web stub)
- FastAPI OpenAI-compatible server with SSE streaming
- Conversation context management
- Extensive pytest suite (200+ tests) + Hypothesis fuzz tests
- Cross-platform CI (Ubuntu / Windows / macOS)

The prototype is intentionally **toy-scale** and **honest** about limitations (small model cannot do coherent free-form chat; routing is keyword-based; web search is a stub; sandbox is not containerized).

**Known experimental model** (matches `checkpoint_large.json`):

| Parameter            | Value      |
|----------------------|------------|
| d_model              | 128        |
| n_layers             | 4          |
| n_heads              | 8          |
| n_kv_heads           | 4          |
| context / max_seq_len| 64         |
| vocab_size           | 1500       |
| parameters           | 913,536    |
| training tokens      | ≈ 1.43 M   |
| validation loss      | ≈ 6.03     |
| validation perplexity| ≈ 415.5    |

These are **existing measurements**, not invented.

---

## 2. Current File Layout (Top Level)

```
orbit/
├── model.py              # NumPy/autograd TinyLM + ReasoningBlock
├── model_torch.py        # PyTorch equivalent
├── autograd.py           # Custom reverse-mode engine
├── bpe_tokenizer.py      # Trained BPE (GPT-2 style byte base)
├── tokenizer.py          # Original simple byte-level fallback
├── sampling.py           # temperature / top-p / top-k / rep-penalty
├── dataset.py            # Multi-cat data + dedup + split
├── train.py              # NumPy training + checkpointing
├── train_torch.py        # PyTorch training path
├── train_large.py        # Larger corpus training helper
├── generate.py           # Simple generation from checkpoint
├── agents.py             # Orchestrator + specialized agents
├── tools.py              # Sandbox, file, web stub, etc.
├── calculator.py         # Expression calculator
├── paper_trading.py      # Simulated portfolio + SMA backtest
├── memory_store.py       # Hash-embed vector store (+ SQLite)
├── documents.py          # RAG / document chat (extractive)
├── context.py            # Conversation history + budgeted context
├── debugging.py          # Traceback diagnosis helper
├── api.py                # FastAPI OpenAI-compatible server
├── requirements.txt
├── requirements-torch.txt
├── README.md
├── SETUP.md
├── DESIGN.md             # Long design document (100B vision + honesty)
├── soup.yaml
├── persona_chat.jsonl
├── bpe_tokenizer.json
├── bpe_tokenizer_large.json
├── checkpoint_large.npz + .json
├── test_*.py             # 17 test modules
└── .github/workflows/tests.yml
```

**No** `configs/`, `model/` package, `tokenizer/` package, `training/` package, `rag/`, `memory/` package, `agent/` package, `docs/` (until this audit), or formal CLI module structure yet. Everything lives at the top level or is a single-file module.

Data directory (present in original ZIP, partially extracted):

- `data/gitenberg_books/` — multiple public-domain books (large)
- Other raw categories referenced in `dataset.py`

---

## 3. Working Components (Verified by Inspection + Existing Tests)

### 3.1 Model — Educational (NumPy + autograd)

**File:** `model.py`  
**Classes:** `TinyLM`, `CausalSelfAttentionGQA`, `SwiGLUMLP`, `Block`, `ReasoningBlock`  
**Features present:**
- Token embeddings (tied with LM head)
- RMSNorm
- RoPE (cos/sin cache)
- Causal GQA attention
- SwiGLU MLP
- Residual connections
- Optional recursive latent reasoning module (`use_recursive_reasoning`)
- Finite-value checks
- Config validation (divisibility of heads, etc.)
- `param_count()` and `params()` helpers

**Hard-coded defaults in constructor:**
```python
d_model=64, n_layers=2, n_heads=4, n_kv_heads=2, max_seq_len=128
```
Training scripts override these. No external config object.

### 3.2 Model — Practical (PyTorch)

**File:** `model_torch.py`  
**Classes:** `TinyLMTorch`, matching attention/MLP/Block + `ReasoningBlockTorch`  
**Features:** Same architecture as NumPy version; automatic differentiation; checkpoint load/save helpers that interoperate conceptually with the NumPy side.  
**Status:** Present and tested (`test_model_torch.py`).

### 3.3 Autograd Engine

**File:** `autograd.py`  
Custom reverse-mode engine supporting the ops needed by the model (matmul, embedding, softmax, SiLU, reduce, etc.). Numerical gradient checks in `test_autograd.py`. Explicitly educational / sandbox-constrained (no PyTorch dependency for core path).

### 3.4 Tokenizer

- `bpe_tokenizer.py` + `bpe_tokenizer.json` — real trained BPE, lossless round-trip, used by training/generation/API.
- `tokenizer.py` — simpler original byte-level fallback (kept for reference).
- Special tokens are limited compared with the v2 requirement list (`<pad>`, `<unk>`, `<bos>`, `<eos>`, and a few others; no full chat template set yet).

### 3.5 Dataset Pipeline

**File:** `dataset.py`  
- Multi-category raw data (prose, code, JSON, Markdown, math, Filipino/Ilocano, Q&A, persona-chat)
- Exact + near-duplicate detection (shingle / Jaccard)
- Quality filters, language-ID heuristic
- Train/val split + contamination check
- Deterministic where intended

### 3.6 Training

- `train.py` — Adam, held-out perplexity, tiny/small configs, base vs recursive, checkpoint metadata
- `train_torch.py` — PyTorch path, larger seq / vocab experiments
- `train_large.py` — helper for bigger Gutenberg subset

Checkpoint format: `.npz` weights + sidecar `.json` metadata (config, step, val loss/ppl, seed, n_params, tokens used).

### 3.7 Generation / Sampling

- `sampling.py` — temperature, top-p, top-k, repetition penalty
- `generate.py` — loads checkpoint + BPE and samples

No full KV-cache implementation visible in the generation path (toy scale makes it less critical).

### 3.8 Memory

**File:** `memory_store.py`  
- Feature-hashed embeddings (hashing trick)
- In-memory + SQLite backends
- add / query / delete / TTL
- Cosine similarity

### 3.9 RAG / Documents

**File:** `documents.py`  
- Document loading (txt/md/csv/json + optional PDF/DOCX)
- Chunking, hash-embed retrieval, lexical rerank
- Extractive answer + extractive summarizer
- Source tracking / support levels
- Explicitly **not** generative (tiny model cannot abstractively answer)

### 3.10 Agents

**File:** `agents.py`  
- `Orchestrator` (rule-based / keyword routing — honestly documented as a stand-in)
- Specialized agents: Code, Research, Data, Calculator, Debug, Document, Finance, Design, File, Memory, MainChat
- Verifier
- Uses tools, memory, documents, calculator, paper trading

### 3.11 Tools & Security

**File:** `tools.py` + `calculator.py` + `paper_trading.py`  
- Python sandbox (subprocess + rlimits + import blocklist + audit log)
- Sandboxed file read
- Web-search stub (honest “no live access”)
- Calculator
- Paper trading (buy/sell, fees, SMA backtest, guardrails)

Permission model is present but not yet formalized into SAFE / LIMITED / FULL levels with full allow/deny lists.

### 3.12 API

**File:** `api.py`  
- FastAPI
- OpenAI-compatible: `/v1/chat/completions` (streaming SSE + non-streaming), `/v1/models`
- Additional: `/v1/memory`, `/healthz` (and health)
- Integrates agents, memory, RAG paths

### 3.13 Context / Conversation

**File:** `context.py`  
- ConversationStore (SQLite)
- Priority-ordered context assembly (system > memory > docs > history > current)
- Token-budgeted against model `max_seq_len`

### 3.14 Tests & CI

- 17 test modules covering almost every component
- Hypothesis property-based tests
- GitHub Actions matrix: Ubuntu / Windows / macOS × Python 3.11 / 3.12

### 3.15 Documentation

- `README.md` — quick start, honesty about what is proved
- `SETUP.md` — cross-platform install
- `DESIGN.md` — extensive design notes, 100B vision, architecture choices, honesty sections (§18 implemented vs proposed)

---

## 4. Incomplete / Missing Relative to ORBIT v2 Spec

| Area                    | Current State                                      | v2 Expectation                                      |
|-------------------------|----------------------------------------------------|-----------------------------------------------------|
| Configuration system    | Hard-coded defaults + dicts in train scripts       | `configs/*.yaml` + `model/config.py`                |
| Model packaging         | Flat `model.py` / `model_torch.py`                 | Modular `model/` package (embeddings, rope, …)      |
| Tokenizer packaging     | Flat files                                         | `tokenizer/` package + richer special tokens        |
| Dataset layout          | Mostly in-memory / script-driven                   | Explicit `data/raw|cleaned|processed|train|…`       |
| Dataset mixture         | Hard-coded categories                              | Configurable weights                                |
| Training packaging      | Flat `train*.py`                                   | `training/` package                                 |
| Checkpoint structure    | Flat `.npz` + `.json`                            | `checkpoints/latest|best|archives/` + richer meta   |
| Evaluation              | Inline val loss/ppl                                | Dedicated `evaluation/` + repeatable prompts        |
| Generation              | Basic script                                       | Full controls + correct KV cache                    |
| Instruction tuning      | Persona JSONL only                                 | Full instruction / chat format support              |
| Chat templates          | Minimal                                            | Configurable system/user/assistant/tool templates   |
| Memory packaging        | Single file                                        | `memory/` package with pluggable backends           |
| RAG packaging           | Single file                                        | `rag/` package (loader/chunker/embed/vector_db/…)   |
| Tool interface          | Ad-hoc functions                                   | Standard `tools/base.py` with schema + execute      |
| Security levels         | Sandbox exists but informal                        | Explicit SAFE / LIMITED / FULL                      |
| LLM tool calling        | Rule-based keyword routing                         | Structured tool-call format from the model          |
| Agent packaging         | Single large `agents.py`                           | `agent/` package (planner, executor, state, …)      |
| Web search              | Stub                                               | Provider abstraction                                |
| API structure           | Single `api.py`                                    | Modular routes                                      |
| Web UI                  | None (API only)                                    | Chat UI with toggles, streaming, sources            |
| Streaming               | SSE in API                                         | Full end-to-end progressive UI                      |
| Monitoring              | Minimal                                            | `monitoring/` + logs                                |
| CLI                     | None                                               | `python -m orbit …`                                 |
| Export (GGUF/etc.)      | None                                               | Conversion tools (later)                            |
| Formal versioning       | DESIGN.md notes                                    | CHANGELOG.md, v1/v2 tags                            |

---

## 5. Duplicated / Parallel Implementations

1. **Two model backends** (intentional and valuable)
   - `model.py` (NumPy + custom autograd) — educational
   - `model_torch.py` (PyTorch) — practical training
   - Must be kept and documented as equivalent architectures.

2. **Two tokenizers**
   - `tokenizer.py` (simple) vs `bpe_tokenizer.py` (production path)
   - Keep both; mark the simple one as reference/fallback.

3. **Training scripts**
   - `train.py`, `train_torch.py`, `train_large.py` share conceptual steps but are separate entry points.

4. **Memory backends**
   - In-memory `VectorStore` + `SQLiteVectorStore` already exist side-by-side (good).

No other major unwanted duplication found.

---

## 6. Hard-Coded Values That Should Become Configurable

- Model dimensions (`d_model`, `n_layers`, `n_heads`, `n_kv_heads`, `max_seq_len`, `vocab_size`, `d_ff`, RoPE base, norm eps, dropout if any)
- Training hyper-parameters (batch, grad accum, lr, weight decay, warmup, max steps, eval/save intervals, seed)
- Runtime (device, dtype, threads)
- Dataset mixture weights
- Special tokens / chat template
- Agent max iterations, timeouts, allowed tools, permission level
- RAG chunk size / overlap / top-k
- Memory TTL / embedding dimension / backend choice

---

## 7. Bugs / Fragile Points Observed

- Generation path does not appear to implement a proper incremental KV cache (acceptable at toy scale, needed for v2).
- Web search is explicitly a stub; any live search will require a real provider abstraction.
- Rule-based agent routing will not scale; documented honestly but must migrate to structured LLM tool calls.
- Sandbox is process-based + rlimits + import blocklist — not a full container; FULL mode must stay opt-in and well-guarded.
- Some platform-specific resource handling (already mitigated by CI matrix).
- Large Gutenberg data is present but not part of the default tiny training path (intentional).
- No formal `configs/` or package layout yet — refactoring must preserve existing entry points and tests.

No catastrophic broken core functionality was found; the existing test suite is the primary correctness oracle.

---

## 8. Recommended Change Strategy (High Level)

Follow the exact implementation order in the ORBIT v2 TODO:

0. **This audit** (done)
1. Introduce configuration system (`configs/*.yaml` + `model/config.py`) without breaking existing scripts
2. Refactor model into modular package while keeping both NumPy and PyTorch backends
3. Align architectures and document in `docs/ARCHITECTURE.md`
4. Define and document TINY / SMALL / MEDIUM configs + parameter/memory estimates
5. Tokenizer V2 (richer special tokens, package, tests)
6–7. Dataset V2 + mixture system
8–11. Training / checkpoint / evaluation / generation improvements
12–13. Instruction tuning + chat templates
14–15. Memory V2 + RAG V2 packaging
16–21. Tools, security, structured tool calling, agent refactor, web abstraction
22–25. API modularization, OpenAI compatibility polish, Web UI, streaming
26–29. Monitoring, expanded tests, documentation, hardware measurements
30+ Scaling, cloud, export, CLI, launcher, versioning

**Principles to obey throughout:**
- Preserve every working component unless a change is required for correctness, scalability, or compatibility.
- Never invent benchmark numbers.
- Never assume CUDA.
- Keep the educational NumPy path alive.
- Test after every major phase.
- Document migrations for any checkpoint format changes.

---

## 9. Current Architecture Diagram (As Implemented)

```
USER / curl / client
        │
        ▼
   FastAPI (api.py)
        │
        ▼
 Orchestrator (agents.py)  ←── keyword / rule routing
        │
   ┌────┼──────────────────────────────┐
   │    │                              │
   ▼    ▼                              ▼
Agents  Memory (memory_store.py)   Documents / RAG (documents.py)
   │         │                              │
   │         ▼                              ▼
   │    VectorStore / SQLite          Chunk + hash-embed + extract
   │
   ▼
 Tools (tools.py, calculator, paper_trading)
   │
   ▼
 Context assembly (context.py)
   │
   ▼
 TinyLM (model.py or model_torch.py)
   + BPETokenizer
   + sampling.py
   │
   ▼
 Checkpoint (.npz + .json)
```

---

## 10. Next Immediate Action

Proceed to **Phase 1 — Configuration System** only after this audit is accepted.  
Do not modify model, training, or agent code until configuration is in place and existing entry points continue to work.

---

*End of Phase 0 audit. No code was changed.*
