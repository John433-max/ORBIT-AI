# Model providers

Agents and chat miss-path can use `orbit.models.ModelProvider` instead of hard-wiring TinyLM.

## Providers

| Provider | Env | Notes |
|----------|-----|--------|
| `echo` | `ORBIT_MODEL_PROVIDER=echo` | Tests / offline |
| `tinylm` | `ORBIT_MODEL_PROVIDER=tinylm` | Educational weights |
| `ollama` | `ORBIT_MODEL_PROVIDER=ollama` + `ORBIT_MODEL_NAME=…` | Local Ollama HTTP |
| `openai` | `ORBIT_MODEL_PROVIDER=openai` + `ORBIT_OPENAI_BASE_URL` | OpenAI-compatible |
| `gguf` | `ORBIT_MODEL_PROVIDER=gguf` + `ORBIT_MODEL_NAME=/path/model.gguf` | llama-cpp-python |
| `auto` | default | Ollama if up → TinyLM → echo |

### GGUF

```bash
pip install llama-cpp-python
ORBIT_MODEL_PROVIDER=gguf \
ORBIT_MODEL_NAME=/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf \
ORBIT_GGUF_N_CTX=2048 \
ORBIT_GGUF_N_GPU_LAYERS=0 \
python run_orbit.py chat "hello"
```

CPU-first: `ORBIT_GGUF_N_GPU_LAYERS=0`.

### Force chat miss-path through ModelRouter

```bash
ORBIT_CHAT_PROVIDER=1 ORBIT_MODEL_PROVIDER=echo python run_orbit.py chat "hi"
```

Without `ORBIT_CHAT_PROVIDER=1`, default remains TinyLM for auto/tinylm (backward compatible).

## MCP tools

```python
from orbit.mcp import mcp_tools_to_registry

reg = mcp_tools_to_registry([
    {"name": "mcp.echo", "description": "echo", "handler": lambda text="": {"ok": True, "content": text}},
])
```

External MCP clients bind handlers; ORBIT still enforces permission levels.
