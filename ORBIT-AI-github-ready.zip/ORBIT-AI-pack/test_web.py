"""Tests for live web search (DuckDuckGo) with offline-safe assertions."""

from tools.web import (
    StubSearchProvider,
    DuckDuckGoSearchProvider,
    AutoSearchProvider,
    WebSearchTool,
)
from tools import default_registry, ToolCall


def test_stub_provider_is_honest():
    hits = StubSearchProvider().search("anything")
    assert len(hits) == 1
    assert "unavailable" in hits[0].title.lower() or "unavailable" in hits[0].snippet.lower()


def test_web_search_tool_returns_content():
    tool = WebSearchTool(provider=StubSearchProvider())
    r = tool.execute(query="orbit")
    assert r.ok
    assert "orbit" in r.content.lower() or "unavailable" in r.content.lower()


def test_openai_schema_includes_web_search():
    reg = default_registry("SAFE")
    names = [t["function"]["name"] for t in reg.openai_tools()]
    assert "web.search" in names
    assert "calculator" in names


def test_auto_or_live_search_shape():
    """Live search when network works; stub shape when it does not."""
    hits = AutoSearchProvider().search("Python programming language", max_results=3)
    assert isinstance(hits, list) and len(hits) >= 1
    h = hits[0]
    assert hasattr(h, "title") and hasattr(h, "snippet")
    # Either real URL results or explicit failure/stub
    if h.source.startswith("stub"):
        assert "query" in h.snippet.lower() or "fail" in h.snippet.lower() or "unavailable" in h.snippet.lower()
    else:
        assert h.title
        # Prefer URLs on live hits, but Instant Answer may omit
        assert h.snippet or h.url


def test_registry_web_search_execute():
    reg = default_registry("SAFE")
    r = reg.execute(ToolCall(tool="web.search", arguments={"query": "RMSNorm", "max_results": 2}))
    assert r.ok
    assert r.content
