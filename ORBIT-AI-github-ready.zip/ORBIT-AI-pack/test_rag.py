"""Tests for documents.py — document chat / RAG (Phases 3-5, 19)."""
import json
import pytest

from documents import (
    DocumentStore, load_document, chunk_text, split_sentences,
    extractive_summarize, query_aware_extract, answer_from_documents,
    summarize_document, Support, SUPPORTED_FORMATS,
)


@pytest.fixture
def store(tmp_path):
    s = DocumentStore(str(tmp_path / "docs.db"))
    yield s
    s.close()


SAMPLE_TXT = (
    b"Attention is a mechanism that lets a model weigh different tokens differently. "
    b"Transformers stack layers of self attention and a feed forward network. "
    b"RMSNorm is a normalization technique that skips mean centering. "
    b"RoPE encodes position by rotating query and key vectors. "
    b"Grouped query attention shares key and value heads to reduce memory cost."
)


def test_load_txt():
    text, pages = load_document("notes.txt", b"hello world")
    assert text == "hello world"
    assert pages == [(None, "hello world")]


def test_load_csv_renders_rows():
    csv_bytes = b"name,score\nAna,90\nBen,85\n"
    text, pages = load_document("scores.csv", csv_bytes)
    assert "name, score" in text
    assert "Ana, 90" in text


def test_load_json_pretty_prints():
    payload = json.dumps({"a": 1, "b": [1, 2, 3]}).encode()
    text, pages = load_document("data.json", payload)
    assert '"a": 1' in text


def test_load_json_malformed_falls_back_to_raw_text():
    text, pages = load_document("bad.json", b"{not valid json")
    assert "{not valid json" in text  # doesn't crash the upload


def test_unsupported_format_rejected():
    with pytest.raises(ValueError):
        load_document("archive.zip", b"whatever")


def test_split_sentences_basic():
    sents = split_sentences("First sentence. Second sentence! Third one?")
    assert sents == ["First sentence.", "Second sentence!", "Third one?"]


def test_split_sentences_empty():
    assert split_sentences("") == []
    assert split_sentences("   ") == []


def test_chunk_text_respects_size_roughly():
    long_text = " ".join(f"Sentence number {i} is here." for i in range(50))
    chunks = chunk_text(long_text, chunk_size=200, overlap=30)
    assert len(chunks) > 1
    assert all(len(c) < 400 for c in chunks)  # some slack for the last sentence in a chunk


def test_extractive_summarize_returns_original_sentences():
    text = SAMPLE_TXT.decode()
    summary = extractive_summarize(text, n_sentences=2)
    assert len(summary) == 2
    for s in summary:
        assert s in text  # nothing generated — every sentence must be verbatim


def test_extractive_summarize_short_text_returns_all():
    text = "Only one sentence here."
    assert extractive_summarize(text, n_sentences=5) == ["Only one sentence here."]


def test_query_aware_extract_prefers_relevant_sentence():
    text = SAMPLE_TXT.decode()
    result = query_aware_extract(text, "what does RoPE do", n_sentences=1)
    assert any("RoPE" in s for s in result)


def test_query_aware_extract_falls_back_when_no_overlap():
    text = SAMPLE_TXT.decode()
    result = query_aware_extract(text, "zzz nonexistent qqq", n_sentences=2)
    assert len(result) == 2  # falls back to frequency-based, doesn't return empty


# --- DocumentStore / RAG ---

def test_add_list_delete_document(store):
    info = store.add_document("test.txt", SAMPLE_TXT)
    assert info["num_chunks"] >= 1
    docs = store.list_documents()
    assert len(docs) == 1
    assert docs[0]["filename"] == "test.txt"
    assert store.delete_document(info["document_id"]) is True
    assert store.list_documents() == []


def test_delete_nonexistent_document_returns_false(store):
    assert store.delete_document(99999) is False


def test_search_returns_relevant_chunks(store):
    store.add_document("test.txt", SAMPLE_TXT)
    hits = store.search("grouped query attention", k=3)
    assert len(hits) >= 1
    assert hits[0]["filename"] == "test.txt"
    assert "score" in hits[0]


def test_search_empty_store_returns_empty(store):
    assert store.search("anything") == []


def test_chunks_carry_document_metadata(store):
    store.add_document("meta_test.txt", SAMPLE_TXT)
    hits = store.search("attention", k=5)
    for h in hits:
        assert "document_id" in h and "filename" in h and "chunk_index" in h


# --- Answer / hallucination control ---

def test_answer_supported_when_relevant(store):
    store.add_document("test.txt", SAMPLE_TXT)
    result = answer_from_documents(store, "how does RoPE encode position")
    assert result["support"] in (Support.SUPPORTED, Support.PARTIALLY_SUPPORTED)
    assert result["sources"]
    assert result["sources"][0]["filename"] == "test.txt"


def test_answer_unsupported_for_unrelated_question(store):
    store.add_document("test.txt", SAMPLE_TXT)
    result = answer_from_documents(store, "what is the best recipe for chocolate cake")
    assert result["support"] in (Support.UNSUPPORTED, Support.PARTIALLY_SUPPORTED)
    if result["support"] == Support.UNSUPPORTED:
        assert result["sources"] == []


def test_answer_unknown_with_no_documents(store):
    result = answer_from_documents(store, "anything at all")
    assert result["support"] == Support.UNKNOWN
    assert result["sources"] == []


def test_answer_never_fabricates_a_source_not_in_store(store):
    store.add_document("real.txt", SAMPLE_TXT)
    result = answer_from_documents(store, "attention mechanism")
    for src in result["sources"]:
        assert src["filename"] == "real.txt"  # only the real, uploaded file is ever cited


def test_summarize_document_uses_only_that_documents_text(store):
    info1 = store.add_document("doc1.txt", SAMPLE_TXT)
    other_text = b"This document is entirely about baking sourdough bread at home."
    store.add_document("doc2.txt", other_text)
    summary = summarize_document(store, info1["document_id"])
    assert summary["filename"] == "doc1.txt"
    assert "bread" not in summary["summary"].lower()


def test_supported_formats_always_includes_stdlib_types():
    assert {"txt", "md", "csv", "json"} <= SUPPORTED_FORMATS


def test_embedding_cache_avoids_recompute_on_repeated_search(store):
    """Regression test for a real performance bug: search() used to
    recompute hash_embed() for every chunk on every single query, with no
    caching at all. Verifies the cache actually populates and stays flat
    across repeated queries instead of growing per-search."""
    store.add_document("test.txt", SAMPLE_TXT)
    assert len(store._embed_cache) == 0
    store.search("attention mechanism")
    size_after_first = len(store._embed_cache)
    assert size_after_first > 0
    store.search("grouped query attention")
    store.search("RMSNorm normalization")
    assert len(store._embed_cache) == size_after_first  # no growth from repeat queries


def test_embedding_cache_invalidated_on_delete(store):
    info = store.add_document("test.txt", SAMPLE_TXT)
    store.search("attention")
    assert len(store._embed_cache) > 0
    store.delete_document(info["document_id"])
    assert len(store._embed_cache) == 0
