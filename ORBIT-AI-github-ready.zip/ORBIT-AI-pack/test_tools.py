"""
Security-focused tests for tools.py. These specifically target the two bugs
fixed in this pass (path-traversal via string-prefix check, bare eval/exec
bypassing the Attribute-only blocklist), plus baseline sandbox behavior.
Per the module's own docstring, this sandbox is NOT a production security
boundary — these tests check the documented best-effort protections work as
documented, not that the sandbox is unbreakable.
"""
import os
import pytest

from tools import python_sandbox, read_sandboxed_file, _static_check


@pytest.fixture
def sandbox_dirs(tmp_path):
    root = tmp_path / "root"
    root.mkdir()
    (root / "inner").mkdir()
    (root / "inner" / "ok.txt").write_text("fine")
    evil = tmp_path / "root_evil"  # shares a string prefix with `root`
    evil.mkdir()
    (evil / "secret.txt").write_text("TOP SECRET")
    return str(root), str(evil)


def test_legit_file_read_succeeds(sandbox_dirs):
    root, _ = sandbox_dirs
    result = read_sandboxed_file("inner/ok.txt", root=root)
    assert result["ok"] is True
    assert result["content"] == "fine"


def test_dotdot_traversal_blocked(sandbox_dirs):
    root, _ = sandbox_dirs
    result = read_sandboxed_file("../../etc/passwd", root=root)
    assert result["ok"] is False


def test_prefix_confusion_sibling_dir_blocked(sandbox_dirs):
    """root='.../root' and '.../root_evil' share a string prefix; the old
    `.startswith()` check let this through. Must be blocked."""
    root, evil = sandbox_dirs
    rel = os.path.relpath(os.path.join(evil, "secret.txt"), root)
    result = read_sandboxed_file(rel, root=root)
    assert result["ok"] is False


def test_symlink_escape_blocked(sandbox_dirs):
    root, evil = sandbox_dirs
    link_path = os.path.join(root, "link_to_secret")
    os.symlink(os.path.join(evil, "secret.txt"), link_path)
    result = read_sandboxed_file("link_to_secret", root=root)
    assert result["ok"] is False


def test_bare_eval_call_blocked():
    result = _static_check('eval("1+1")')
    assert result is not None
    error_type, reason = result
    assert error_type == "blocked_operation" and "eval" in reason


def test_bare_exec_call_blocked():
    result = _static_check('exec("print(1)")')
    assert result is not None
    error_type, reason = result
    assert error_type == "blocked_operation" and "exec" in reason


def test_dunder_import_blocked():
    result = _static_check('__import__("os")')
    assert result is not None


def test_attribute_style_os_system_still_blocked():
    result = _static_check('import os\nos.system("ls")')
    assert result is not None


def test_registry_metrics_ok_and_unknown():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    ok = reg.execute(ToolCall(tool="calculator", arguments={"expression": "2+2"}))
    assert ok.ok is True
    bad = reg.execute(ToolCall(tool="no_such_tool", arguments={}))
    assert bad.ok is False
    m = reg.metrics()
    assert m["total_calls"] == 2
    assert m["by_tool"]["calculator"]["ok"] == 1
    assert m["by_tool"]["calculator"]["ok_rate"] == 1.0
    assert m["by_tool"]["no_such_tool"]["unknown"] == 1
    assert m["by_tool"]["no_such_tool"]["ok"] == 0
    assert len(m["recent"]) == 2


def test_registry_metrics_permission_denied():
    from tools import default_registry, ToolCall

    # Filesystem is LIMITED; SAFE registry should deny.
    reg = default_registry("SAFE")
    fs = reg.get("filesystem.read")
    assert fs is not None
    denied = reg.execute(ToolCall(tool="filesystem.read", arguments={"path": "."}))
    assert denied.ok is False
    m = reg.metrics()
    assert m["by_tool"]["filesystem.read"]["denied"] == 1


def test_orchestrator_metrics_include_tools():
    from agents import Orchestrator
    from tools import ToolCall

    orch = Orchestrator()
    orch.tools.execute(ToolCall(tool="calculator", arguments={"expression": "1+1"}))
    m = orch.metrics()
    assert "tools" in m
    assert m["tools"]["total_calls"] == 1
    assert m["tools"]["by_tool"]["calculator"]["ok"] == 1


def test_tinylm_lab_tool_bench_ok():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    r = reg.execute(ToolCall(tool="tinylm.lab", arguments={"action": "bench", "preset": "rope"}))
    assert r.ok is True
    assert "tok/s" in r.content
    assert r.data and "tok_s" in r.data
    m = reg.metrics()
    assert m["by_tool"]["tinylm.lab"]["ok"] == 1
    assert m["by_tool"]["tinylm.lab"]["ok_rate"] == 1.0


def test_calculator_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, CalculatorAgent

    orch = Orchestrator()
    res = CalculatorAgent().run("what is 12 * 7", {"tools": orch.tools})
    assert res.ok is True
    assert "84" in res.content
    assert res.raw.get("tool") == "calculator"
    assert res.raw.get("tool_ok") is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["calculator"]["ok"] >= 1


def test_code_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, CodeAgent

    orch = Orchestrator()
    res = CodeAgent().run("```python\nprint(2+2)\n```", {"tools": orch.tools})
    assert res.ok is True
    assert "4" in res.content
    assert res.raw.get("tool") == "python.execute"
    assert res.raw.get("tool_ok") is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["python.execute"]["ok"] >= 1


def test_handle_calc_and_code_feed_shared_registry():
    from agents import Orchestrator

    orch = Orchestrator()
    c = orch.handle("what is 12 * 7")
    assert c["agent"] == "calculator_agent"
    assert "84" in c["content"]
    p = orch.handle("```python\nprint(3*3)\n```")
    assert p["agent"] == "coding_agent"
    assert "9" in p["content"]
    m = orch.metrics()
    assert m["tools"]["by_tool"]["calculator"]["ok"] >= 1
    assert m["tools"]["by_tool"]["python.execute"]["ok"] >= 1


def test_research_agent_records_web_search_on_orchestrator():
    from agents import Orchestrator, ResearchAgent
    from tools import WebSearchTool
    from tools.web import SearchResult, SearchProvider

    class LiveFake(SearchProvider):
        def search(self, query, max_results=5):
            return [
                SearchResult(
                    title="RMSNorm paper",
                    url="https://example.com/rmsnorm",
                    snippet="Root Mean Square Layer Normalization.",
                    source="fake-live",
                )
            ]

    orch = Orchestrator()
    orch.tools.register(WebSearchTool(provider=LiveFake()))
    res = ResearchAgent().run("what is RMSNorm", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "web.search"
    assert res.raw.get("tool_ok") is True
    assert "RMSNorm" in res.content or "Root Mean Square" in res.content
    m = orch.metrics()
    assert m["tools"]["by_tool"]["web.search"]["ok"] >= 1
    assert m["tools"]["by_tool"]["web.search"]["ok_rate"] == 1.0


def test_handle_research_feeds_shared_registry():
    from agents import Orchestrator
    from tools import WebSearchTool
    from tools.web import SearchResult, SearchProvider

    class LiveFake(SearchProvider):
        def search(self, query, max_results=5):
            return [
                SearchResult(
                    title="AI news",
                    url="https://example.com/ai",
                    snippet="Latest AI news headline.",
                    source="fake-live",
                )
            ]

    orch = Orchestrator()
    orch.tools.register(WebSearchTool(provider=LiveFake()))
    r = orch.handle("search for the latest AI news")
    assert r["agent"] in ("research_agent", "research")
    assert r["ok"] is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["web.search"]["ok"] >= 1


def test_memory_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, MemoryAgent

    orch = Orchestrator()
    res = MemoryAgent(orch.store).run("remember: tea at 4pm", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "memory.add"
    assert res.raw.get("tool_ok") is True
    q = MemoryAgent(orch.store).run("what do you remember about tea", {"tools": orch.tools})
    assert q.ok is True
    assert q.raw.get("tool") == "memory.search"
    m = orch.metrics()
    assert m["tools"]["by_tool"]["memory.add"]["ok"] >= 1
    assert m["tools"]["by_tool"]["memory.search"]["ok"] >= 1
    assert m["tools"]["by_tool"]["memory.add"]["ok_rate"] == 1.0


def test_handle_memory_feeds_shared_registry():
    from agents import Orchestrator

    orch = Orchestrator()
    r = orch.handle("remember: the sky is teal tonight")
    assert r["agent"] == "memory_agent"
    assert r["ok"] is True
    q = orch.handle("what do you remember about the sky")
    assert q["agent"] == "memory_agent"
    assert q["ok"] is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["memory.add"]["ok"] >= 1
    assert m["tools"]["by_tool"]["memory.search"]["ok"] >= 1


def test_document_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, DocumentAgent

    orch = Orchestrator()
    orch.documents.add_document(
        "notes.txt",
        b"ORBIT is a small research prototype. It is not a 100B model.",
    )
    res = DocumentAgent(orch.documents).run(
        "according to the document, is ORBIT a 100B model",
        {"tools": orch.tools},
    )
    assert res.raw.get("tool") == "document.answer"
    m = orch.metrics()
    assert m["tools"]["by_tool"]["document.list"]["ok"] >= 1
    assert m["tools"]["by_tool"]["document.answer"]["calls"] >= 1


def test_handle_document_feeds_shared_registry():
    from agents import Orchestrator

    orch = Orchestrator()
    orch.documents.add_document(
        "orbit_notes.txt",
        b"ORBIT is a small research prototype built with NumPy.",
    )
    r = orch.handle("according to the document, what is ORBIT")
    assert r["agent"] == "document_agent"
    m = orch.metrics()
    assert m["tools"]["by_tool"]["document.list"]["ok"] >= 1
    assert "document.answer" in m["tools"]["by_tool"]


def test_lab_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, LabAgent

    orch = Orchestrator()
    res = LabAgent().run("bench the model tok/s with rope", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "tinylm.lab"
    assert res.raw.get("tool_ok") is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["tinylm.lab"]["ok"] >= 1


def test_finance_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, FinanceAgent

    orch = Orchestrator()
    res = FinanceAgent().run("run a backtest on this trading strategy", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "finance.backtest"
    assert res.raw.get("tool_ok") is True
    assert res.raw.get("simulation") is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["finance.backtest"]["ok"] >= 1
    assert m["tools"]["by_tool"]["finance.backtest"]["ok_rate"] == 1.0


def test_debug_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, DebugAgent

    orch = Orchestrator()
    res = DebugAgent().run(
        "I got a ModuleNotFoundError: No module named 'numpy'",
        {"tools": orch.tools},
    )
    assert res.ok is True
    assert res.raw.get("tool") == "debug.diagnose"
    assert res.raw.get("tool_ok") is True
    assert res.raw.get("error_type") == "ModuleNotFoundError"
    m = orch.metrics()
    assert m["tools"]["by_tool"]["debug.diagnose"]["ok"] >= 1
    assert m["tools"]["by_tool"]["debug.diagnose"]["ok_rate"] == 1.0


def test_file_agent_records_tool_success_on_orchestrator(tmp_path):
    from agents import Orchestrator, FileAgent

    root = tmp_path / "sbx"
    root.mkdir()
    (root / "notes.txt").write_text("hello orbit")
    orch = Orchestrator(sandbox_root=str(root))
    res = FileAgent().run(
        "read notes.txt",
        {"tools": orch.tools, "sandbox_root": str(root)},
    )
    assert res.ok is True
    assert res.raw.get("tool") == "file.read"
    assert res.raw.get("tool_ok") is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["file.read"]["ok"] >= 1
    assert m["tools"]["by_tool"]["file.read"]["ok_rate"] == 1.0


def test_data_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, DataAgent

    orch = Orchestrator()
    res = DataAgent().run("mean of 1 2 3 4 5", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "data.stats"
    assert res.raw.get("tool_ok") is True
    assert res.raw.get("n") == 5
    assert "mean=" in res.content
    m = orch.metrics()
    assert m["tools"]["by_tool"]["data.stats"]["ok"] >= 1
    assert m["tools"]["by_tool"]["data.stats"]["ok_rate"] == 1.0


def test_design_agent_records_tool_success_on_orchestrator():
    from agents import Orchestrator, DesignAgent

    orch = Orchestrator()
    res = DesignAgent().run("design a landing page for orbit", {"tools": orch.tools})
    assert res.ok is True
    assert "<div" in (res.raw if isinstance(res.raw, str) else "")
    m = orch.metrics()
    assert m["tools"]["by_tool"]["design.layout"]["ok"] >= 1
    assert m["tools"]["by_tool"]["design.layout"]["ok_rate"] == 1.0


def test_handle_data_design_feed_shared_registry():
    from agents import Orchestrator

    orch = Orchestrator()
    d = orch.handle("what is the mean and std of 1 2 3 4 5")
    assert d["agent"] == "data_agent"
    assert d["ok"] is True
    g = orch.handle("design a landing page mockup")
    assert g["agent"] == "design_agent"
    assert g["ok"] is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["data.stats"]["ok"] >= 1
    assert m["tools"]["by_tool"]["design.layout"]["ok"] >= 1


def test_chat_generate_tool_unbound_is_safe():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    res = reg.execute(
        ToolCall(
            tool="chat.generate",
            arguments={"request": "hello orbit", "backend": "legacy"},
        )
    )
    assert res.ok is True
    assert res.content == "(no model loaded)"
    assert res.data.get("loaded") is False
    assert res.data.get("backend") == "legacy"


def test_chat_generate_auto_uses_tinylm_when_orbit_missing():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    res = reg.execute(
        ToolCall(
            tool="chat.generate",
            arguments={"request": "hello orbit", "max_tokens": 12, "temperature": 0.0},
        )
    )
    assert res.ok is True
    assert res.data.get("loaded") is True
    assert res.data.get("backend") == "tinylm"
    assert int(res.data.get("n_new") or 0) >= 1
    assert float(res.data.get("tok_s") or 0.0) > 0.0
    assert res.content


def test_chat_generate_tinylm_backend_cached():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    res = reg.execute(
        ToolCall(
            tool="chat.generate",
            arguments={
                "request": "hello orbit",
                "backend": "tinylm",
                "max_tokens": 16,
                "temperature": 0.0,
            },
        )
    )
    assert res.ok is True
    assert res.data.get("loaded") is True
    assert res.data.get("backend") == "tinylm"
    assert res.data.get("use_cache") is True
    assert int(res.data.get("n_new") or 0) >= 1
    assert float(res.data.get("tok_s") or 0.0) > 0.0
    assert res.content


def test_chat_generate_trained_ckpt_weights_flag(tmp_path):
    from tinylm.train import train_chat_tiny
    from tools.chat_tool import ChatGenerateTool

    ckpt = tmp_path / "chat67.npz"
    train_chat_tiny(
        steps=8,
        vocab=32,
        n_layer=2,
        n_embd=32,
        n_head=4,
        seq=16,
        ckpt_path=str(ckpt),
        seed=1,
    )
    tool = ChatGenerateTool(backend="tinylm", ckpt_path=str(ckpt), max_tokens=8)
    res = tool.execute(request="hello", max_tokens=8, temperature=0.0)
    assert res.ok is True
    assert res.data.get("backend") == "tinylm"
    assert res.data.get("weights") == "checkpoint"
    assert res.data.get("ckpt")
    assert int(res.data.get("n_new") or 0) >= 1


def test_orchestrator_lazy_tinylm_bind_reuses_model():
    from agents import Orchestrator
    from tools import ToolCall

    orch = Orchestrator()
    assert orch._tinylm_model is None
    first = orch.ensure_tinylm()
    assert first is not None
    assert orch.ensure_tinylm() is first
    tool = orch.tools.get("chat.generate")
    assert tool.tinylm_model is first
    a = orch.tools.execute(
        ToolCall(
            tool="chat.generate",
            arguments={"request": "alpha", "backend": "tinylm", "max_tokens": 12, "temperature": 0.0},
        )
    )
    b = orch.tools.execute(
        ToolCall(
            tool="chat.generate",
            arguments={"request": "beta", "backend": "tinylm", "max_tokens": 12, "temperature": 0.0},
        )
    )
    assert a.ok and b.ok
    assert a.data.get("reused") is True
    assert b.data.get("reused") is True
    assert a.data.get("backend") == "tinylm"
    assert tool.tinylm_model is first
    assert orch._tinylm_model is first
    m = orch.metrics()
    assert m["tools"]["by_tool"]["chat.generate"]["ok"] >= 2
    assert m["tools"]["by_tool"]["chat.generate"]["ok_rate"] == 1.0


def test_main_chat_records_generate_on_orchestrator():
    from agents import Orchestrator

    orch = Orchestrator()
    chat = orch.agents["chat"]
    # Miss the persona KB so the generation tool runs (then quality-gate hedges).
    res = chat.run("zzzz-unmatched-persona-query-63", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("generate_tool") == "chat.generate"
    assert res.raw.get("generate_ok") is True
    assert res.raw.get("source") in ("generation", "generation_fallback")
    # Cycle 66: unbound Orbit LM → auto TinyLM on the miss path.
    assert res.raw.get("generate_backend") == "tinylm"
    assert int(res.raw.get("n_new") or 0) >= 1
    m = orch.metrics()
    assert m["tools"]["by_tool"]["chat.generate"]["ok"] >= 1
    assert m["tools"]["by_tool"]["chat.generate"]["ok_rate"] == 1.0


def test_chat_retrieve_tool_unbound_is_safe():
    from tools import default_registry, ToolCall

    reg = default_registry("SAFE")
    res = reg.execute(ToolCall(tool="chat.retrieve", arguments={"query": "who are you"}))
    assert res.ok is True
    assert res.data.get("matched") is False


def test_main_chat_records_retrieve_on_orchestrator():
    from agents import Orchestrator, MainChatAgent

    orch = Orchestrator()
    chat = orch.agents["chat"]
    assert chat._loaded >= 1
    # Seed a guaranteed hit so routing noise doesn't matter.
    chat.knowledge.add("what is orbit", metadata={"answer": "I am ORBIT, a small research agent."})
    res = MainChatAgent(persona_path="__missing__.jsonl")
    # Use orch's bound tool + the same knowledge via orch.agents["chat"]
    res = chat.run("what is orbit", {"tools": orch.tools})
    assert res.ok is True
    assert res.raw.get("tool") == "chat.retrieve"
    assert res.raw.get("tool_ok") is True
    assert res.raw.get("source") == "persona_retrieval"
    assert "ORBIT" in res.content
    m = orch.metrics()
    assert m["tools"]["by_tool"]["chat.retrieve"]["ok"] >= 1
    assert m["tools"]["by_tool"]["chat.retrieve"]["ok_rate"] == 1.0


def test_handle_chat_feeds_shared_registry():
    from agents import Orchestrator

    orch = Orchestrator()
    chat = orch.agents["chat"]
    chat.knowledge.add(
        "hey orbit greet me",
        metadata={"answer": "I am ORBIT. I retrieve first, generate second."},
    )
    d = orch.handle("hey orbit greet me")
    assert d["agent"] == "main_chat_agent"
    assert d["ok"] is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["chat.retrieve"]["ok"] >= 1


def test_handle_finance_debug_file_feed_shared_registry(tmp_path):
    from agents import Orchestrator

    root = tmp_path / "sbx"
    root.mkdir()
    (root / "notes.txt").write_text("hello orbit")
    orch = Orchestrator(sandbox_root=str(root))
    f = orch.handle("run a backtest on this trading strategy")
    assert f["agent"] == "finance_agent"
    d = orch.handle("I got a ModuleNotFoundError: No module named 'numpy'")
    assert d["agent"] == "debug_agent"
    r = orch.handle("read notes.txt")
    assert r["agent"] == "file_agent"
    assert r["ok"] is True
    m = orch.metrics()
    assert m["tools"]["by_tool"]["finance.backtest"]["ok"] >= 1
    assert m["tools"]["by_tool"]["debug.diagnose"]["ok"] >= 1
    assert m["tools"]["by_tool"]["file.read"]["ok"] >= 1


def test_import_not_in_allowlist_blocked():
    result = _static_check('import os')
    assert result is not None
    error_type, reason = result
    assert error_type == "blocked_operation" and "os" in reason


def test_import_in_allowlist_not_blocked():
    assert _static_check("import math\nprint(math.sqrt(4))") is None
    assert _static_check("import json\nprint(json.dumps({}))") is None


def test_legit_code_not_blocked():
    assert _static_check("print(2 + 2)") is None


def test_python_sandbox_runs_legit_code():
    result = python_sandbox("print(2 + 2)")
    assert result["ok"] is True
    assert result["stdout"].strip() == "4"


def test_python_sandbox_blocks_blocked_import():
    result = python_sandbox("import os\nprint(os.getcwd())")
    assert result["ok"] is False
    assert result["error_type"] == "blocked_operation"


def test_python_sandbox_times_out_on_infinite_loop():
    result = python_sandbox("while True: pass", timeout=0.5)
    assert result["ok"] is False
    assert result["error_type"] == "timeout"


def test_python_sandbox_surfaces_syntax_errors():
    result = python_sandbox("def broken(:", timeout=1.0)
    assert result["ok"] is False
    assert result["error_type"] == "syntax_error"


def test_python_sandbox_runtime_exception_classified_correctly():
    result = python_sandbox("1 / 0", timeout=2.0)
    assert result["ok"] is False
    assert result["error_type"] == "runtime_error"
    assert "ZeroDivisionError" in result["stderr"]


def test_python_sandbox_allows_math_and_json():
    result = python_sandbox("import math, json\nprint(json.dumps({'x': math.sqrt(16)}))", timeout=2.0)
    assert result["ok"] is True
    assert "4.0" in result["stdout"]


def test_python_sandbox_output_limit_enforced_on_stdout():
    # a genuinely unbounded stdout producer -- must be stopped by the
    # output cap well before it could exhaust memory, not merely truncated
    # after the fact
    result = python_sandbox(
        "while True:\n    print('A' * 1000)",
        timeout=5.0, max_stdout_bytes=50_000,
    )
    assert result["ok"] is False
    assert result["error_type"] == "output_limit"
    assert len(result["stdout"]) < 200_000  # bounded, not unbounded


def test_python_sandbox_normal_output_not_treated_as_limit_hit():
    result = python_sandbox("print('hello world')", timeout=2.0, max_stdout_bytes=1000)
    assert result["ok"] is True
    assert result.get("error_type") is None


def test_python_sandbox_resource_limit_distinguished_from_runtime_error():
    # allocate well past the configured memory limit. Verified empirically
    # (not assumed) that this specific case is caught by Python as an
    # in-process MemoryError with a clean exit, not an OS signal -- so the
    # classifier has to check stderr content, not just the exit signal.
    import sys as _sys
    if _sys.platform == "win32":
        import pytest as _pytest
        _pytest.skip("RLIMIT_AS-based memory limiting is POSIX-only")
    result = python_sandbox(
        "x = bytearray(400 * 1024 * 1024)",  # 400MB, well past the 64MB limit below
        timeout=3.0, mem_limit_mb=64,
    )
    assert result["ok"] is False
    assert result["error_type"] == "resource_limit"
    assert "MemoryError" in result["stderr"]


def test_windows_resource_module_import_is_conditional():
    """Regression test for a real bug: tools.py used to unconditionally
    `import resource`, a POSIX-only stdlib module. On native Windows this
    would crash `import tools` -- and therefore `import agents` and
    `import api` -- before any code in this module could even run. The fix
    detects the platform and only imports/uses `resource` on POSIX."""
    import tools
    if tools.IS_WINDOWS:
        assert not hasattr(tools, "resource") or "resource" not in dir(tools)
    else:
        assert hasattr(tools, "resource")


def test_audit_log_is_bounded_not_unbounded():
    """Regression test for a real bug: AUDIT_LOG used to be a plain list
    that every sandbox call appended to, forever, with nothing anywhere in
    the project ever reading or trimming it -- pure unbounded memory growth
    over a long-running process's lifetime. Now a bounded deque."""
    from tools import AUDIT_LOG, _audit
    for i in range(AUDIT_LOG.maxlen + 500):
        _audit("test_event", i=i)
    assert len(AUDIT_LOG) == AUDIT_LOG.maxlen
