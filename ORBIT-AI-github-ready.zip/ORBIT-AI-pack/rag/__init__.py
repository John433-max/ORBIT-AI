"""
ORBIT RAG package (v2).

Pipeline: load → clean → chunk → embed → index → retrieve → (rerank) → context → answer.
Wraps the existing documents.py implementation.
"""

from rag.pipeline import RAGPipeline

__all__ = ["RAGPipeline"]
