"""
RAG pipeline with source tracking.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from documents import DocumentStore, answer_from_documents, summarize_document


@dataclass
class RetrievedChunk:
    text: str
    source: str
    score: float = 0.0
    chunk_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RAGAnswer:
    answer: str
    sources: List[RetrievedChunk]
    support: str = "unknown"          # e.g. high / medium / low / none

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "sources": [s.to_dict() for s in self.sources],
            "support": self.support,
        }


class RAGPipeline:
    """
    High-level RAG interface.

    Uses the existing DocumentStore under the hood so behaviour stays
    consistent with the current extractive system.
    """

    def __init__(self, store: Optional[DocumentStore] = None):
        self.store = store or DocumentStore()

    def load(self, path: Union[str, Path], **kwargs) -> int:
        """Load a document from path. Returns number of chunks added."""
        path = Path(path)
        if hasattr(self.store, "add_file"):
            return int(self.store.add_file(str(path), **kwargs) or 0)
        if hasattr(self.store, "ingest"):
            return int(self.store.ingest(str(path), **kwargs) or 0)
        # Fallback: read text and add
        text = path.read_text(encoding="utf-8", errors="replace")
        return self.add_text(text, source=str(path))

    def add_text(self, text: str, source: str = "inline") -> int:
        if hasattr(self.store, "add_document"):
            return int(self.store.add_document(text, source=source) or 0)
        if hasattr(self.store, "add"):
            self.store.add(text, {"source": source})
            return 1
        return 0

    def retrieve(self, query: str, top_k: int = 5) -> List[RetrievedChunk]:
        if hasattr(self.store, "search"):
            hits = self.store.search(query, k=top_k)
        elif hasattr(self.store, "query"):
            hits = self.store.query(query, k=top_k)
        else:
            hits = []
        chunks: List[RetrievedChunk] = []
        for h in hits or []:
            if isinstance(h, dict):
                chunks.append(RetrievedChunk(
                    text=h.get("text") or h.get("content") or str(h),
                    source=h.get("source") or h.get("path") or "unknown",
                    score=float(h.get("score") or h.get("similarity") or 0.0),
                    chunk_id=str(h.get("id") or h.get("chunk_id") or ""),
                    metadata={k: v for k, v in h.items() if k not in ("text", "content", "score", "similarity")},
                ))
            else:
                chunks.append(RetrievedChunk(text=str(h), source="unknown"))
        return chunks

    def query(self, question: str, top_k: int = 5) -> RAGAnswer:
        """Full retrieve → answer with source tracking."""
        try:
            # documents.answer_from_documents(store, question, k=...)
            result = answer_from_documents(self.store, question, k=top_k)
        except TypeError:
            try:
                result = answer_from_documents(self.store, question)
            except Exception as e:
                return RAGAnswer(answer=f"RAG error: {e}", sources=[], support="none")
        except Exception as e:
            return RAGAnswer(answer=f"RAG error: {e}", sources=[], support="none")

        if isinstance(result, dict):
            answer = result.get("answer") or result.get("content") or str(result)
            support = str(result.get("support") or result.get("level") or "unknown")
            raw_sources = result.get("sources") or result.get("chunks") or []
        else:
            answer = str(result)
            support = "unknown"
            raw_sources = []

        sources = []
        for s in raw_sources:
            if isinstance(s, dict):
                sources.append(RetrievedChunk(
                    text=s.get("text") or s.get("content") or "",
                    source=s.get("source") or s.get("path") or "unknown",
                    score=float(s.get("score") or 0.0),
                    chunk_id=str(s.get("id") or ""),
                ))
            else:
                sources.append(RetrievedChunk(text=str(s), source="unknown"))

        # Fallback: attach retrieved chunks if no sources returned
        if not sources:
            sources = self.retrieve(question, top_k=top_k)

        return RAGAnswer(answer=answer, sources=sources, support=support)

    def summarize(self, source: Optional[str] = None, max_sentences: int = 5) -> str:
        try:
            if source:
                return str(summarize_document(source, max_sentences=max_sentences))
            return str(summarize_document(self.store, max_sentences=max_sentences))
        except Exception as e:
            return f"Summarize error: {e}"
