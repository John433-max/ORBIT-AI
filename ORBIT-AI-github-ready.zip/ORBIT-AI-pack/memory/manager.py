"""
Memory manager — short-term + long-term with semantic retrieval.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from memory_store import VectorStore, SQLiteVectorStore


class MemoryManager:
    """
    Unified memory API.

    Functions:
      add_memory(), search_memory(), update_memory(),
      delete_memory(), summarize_memory()
    """

    def __init__(
        self,
        backend: str = "memory",          # "memory" | "sqlite"
        sqlite_path: str = "orbit_memory.db",
        dim: int = 256,
    ):
        if backend == "sqlite":
            self.store = SQLiteVectorStore(db_path=sqlite_path, dim=dim)
        else:
            self.store = VectorStore(dim=dim)
        self.backend = backend
        self._short_term: List[Dict[str, Any]] = []
        self._max_short = 50

    # ---- long-term ----
    def add_memory(self, text: str, metadata: Optional[Dict] = None) -> str:
        meta = metadata or {}
        mid = self.store.add(text, meta)
        return str(mid)

    def search_memory(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        hits = self.store.query(query, k=top_k)
        # Normalize to list of dicts
        out = []
        for h in hits:
            if isinstance(h, dict):
                out.append(h)
            else:
                out.append({"text": str(h), "score": None})
        return out

    def update_memory(self, memory_id: str, text: str, metadata: Optional[Dict] = None) -> bool:
        if hasattr(self.store, "update"):
            return bool(self.store.update(memory_id, text, metadata or {}))
        # Fallback: delete + add
        self.delete_memory(memory_id)
        self.add_memory(text, metadata)
        return True

    def delete_memory(self, memory_id: str) -> bool:
        if hasattr(self.store, "delete"):
            return bool(self.store.delete(memory_id))
        return False

    def summarize_memory(self, max_items: int = 20) -> str:
        """Simple extractive summary of recent / top memories."""
        # Prefer query with empty or generic prompt
        try:
            hits = self.search_memory("summary of important facts", top_k=max_items)
        except Exception:
            hits = []
        if not hits and hasattr(self.store, "all"):
            hits = list(self.store.all())[:max_items]
        lines = []
        for h in hits:
            t = h.get("text") if isinstance(h, dict) else str(h)
            if t:
                lines.append(f"- {t[:200]}")
        return "Memory summary:\n" + ("\n".join(lines) if lines else "(empty)")

    # ---- short-term (conversation buffer) ----
    def add_short_term(self, role: str, content: str) -> None:
        self._short_term.append({"role": role, "content": content})
        if len(self._short_term) > self._max_short:
            self._short_term = self._short_term[-self._max_short :]

    def get_short_term(self) -> List[Dict[str, str]]:
        return list(self._short_term)

    def clear_short_term(self) -> None:
        self._short_term.clear()
