"""
ORBIT memory package (v2).

Wraps the existing memory_store.py with a cleaner API and pluggable backends.
"""

from memory.manager import MemoryManager

__all__ = ["MemoryManager"]
