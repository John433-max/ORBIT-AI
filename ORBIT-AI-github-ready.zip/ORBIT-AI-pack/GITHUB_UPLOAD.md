# Upload to GitHub

```bash
git clone https://github.com/John433-max/ORBIT-AI.git
cd ORBIT-AI
unzip -o ORBIT-AI-github-ready.zip
mv ORBIT-AI-pack/* . 2>/dev/null; rmdir ORBIT-AI-pack 2>/dev/null
git add -A && git commit -m "Sync full ORBIT source" && git push
```

Checkpoints (*.npz) excluded — train or copy separately.
