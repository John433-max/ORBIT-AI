"""OpenAI-compatible helper tests (no FastAPI required)."""

from api_routes.openai_helpers import model_catalog, usage, estimate_tokens


def test_model_catalog_has_orbit_toy():
    ids = {m["id"] for m in model_catalog()}
    assert "orbit-toy" in ids
    assert "text-embedding-orbit-hash" in ids
    for m in model_catalog():
        assert m["object"] == "model"
        assert "owned_by" in m


def test_usage_shape():
    u = usage(10, 5)
    assert u == {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}


def test_estimate_tokens_positive():
    assert estimate_tokens("hello world") >= 1
    assert estimate_tokens("") == 0
