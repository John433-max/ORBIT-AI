# Phase 0 — Repository Audit (2026-09-20)

## Source of truth
- **Local full tree:** `/home/workdir/artifacts/orbit` (complete implementation)
- **GitHub:** `John433-max/ORBIT-AI` (partial publish; growing toward parity)
- README is **not** assumed correct until verified against code

## Architecture (actual)

| Layer | Location | Status |
|-------|----------|--------|
| CLI / launcher | `run_orbit.py` | WORKING — doctor, serve, chat, status |
| Facade | `orbit_ai.py` | WORKING |
| Orchestrator | `agents.py` | WORKING — rule-based routing + agents |
| Model providers | `orbit/models/*` | WORKING — base, echo, ollama, openai, tinylm, gguf, resilient, router |
| Config | `orbit/core/config.py` | WORKING — env-driven |
| State machine | `orbit/core/state.py` | WORKING — RunState enum + AgentRun |
| Tools | `tools/*` + `tools/base.py` | WORKING — ToolRegistry + permissions |
| API | `api.py` + `api_routes/*` | WORKING — FastAPI, SSE, OpenAI-compat |
| Web UI | `webui/index.html` | WORKING |
| Memory | `memory_store.py` | WORKING — hash-embed + SQLite |
| RAG/docs | `documents.py` | WORKING — extractive, not generative |
| TinyLM lab | `tinylm/*`, `model.py` | WORKING — educational toy-scale |
| MCP adapter | `orbit/mcp/adapter.py` | PARTIAL — present |
| Evaluation | `evaluation/`, `evals/` | PARTIAL |
| Monitoring | `monitoring/` | PARTIAL stubs |

## Classification

| Component | Class |
|-----------|--------|
| ModelProvider abstraction | WORKING |
| Orchestrator + agents | WORKING |
| ToolRegistry + SAFE/EXECUTION levels | WORKING |
| Doctor CLI | WORKING (deps may warn if not installed) |
| Web UI + SSE | WORKING |
| TinyLM as product LM | EDUCATIONAL ONLY — not frontier |
| DESIGN.md 100B vision | HISTORICAL — labeled |
| GitHub tree completeness | PARTIAL vs local |
| Full sandbox isolation | PARTIAL — timeout + blocklist, not OS isolation |
| MCP integration | PARTIAL |

## 100B terminology (Phase 1)
Fixed product-facing strings in: `api.py`, `agents.py`, `requirements.txt`, `DESIGN.md` header, `dataset.py`, `README.md`, `model_numpy_legacy.py`.
Tests that assert “ORBIT is not a 100B model” **kept** (honesty checks).

## Tests run
- `tests/unit`: **37 passed**
- OrbitAI smoke: `12*7` → calculator answer; status keys present

## Entry points (single coherent path)
```bash
pip install -r requirements.txt
python run_orbit.py doctor
python run_orbit.py serve   # http://127.0.0.1:8000/
```

## Next phase
Phase 1 residual: ensure GitHub README matches; optional doctor dep install in CI; continue publishing missing files if needed.
