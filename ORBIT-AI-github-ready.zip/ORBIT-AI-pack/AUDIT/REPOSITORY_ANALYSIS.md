# ORBIT-AI Repository Analysis (Evidence-Based Audit)

**Date:** 2026-09-19  
**Scope:** Local tree `artifacts/orbit/` (full working tree). GitHub remote is a **partial** mirror.  
**Method:** Source inspection, `pytest`, targeted probes. No invented benchmarks.

---

## 1. Architecture overview

```
User → Web UI / CLI / OrbitAI
         → Orchestrator (agents.py) + Thinker (thinking.py)
              → ToolRegistry (tools/base.py) + Agents
              → documents.py (RAG) · memory_store.py · science_math/calculator
              → chat.generate / TinyLM / ModelProvider (orbit/models/)
         → api.py (FastAPI OpenAI-compatible)
```

**Request path (chat):**  
`POST /v1/chat/completions` → last user message → `Orchestrator.handle` / thinker  
→ score agents → tool or chat.retrieve → optional generate → `_naturalize_output` → response.

---

## 2. Module inventory (major)

| Module | Responsibility | Status |
|--------|----------------|--------|
| `orbit_ai.py` | Facade | Working |
| `agents.py` (~1.4k LOC) | Orchestrator + all agents | Working; large god-module |
| `thinking.py` | Classify/plan/act | Working; soft limits via state machine |
| `tools/base.py` | ToolRegistry + permissions | Working; levels expanded |
| `tools/*` | Concrete tools | Working; web often stub |
| `tools_legacy.py` | python_sandbox | Best-effort isolation only |
| `documents.py` | RAG | Working for text formats |
| `memory_store.py` | Vectors + SQLite | Working |
| `calculator.py` / `science_math.py` | Deterministic solvers | Working |
| `tinylm/` | Educational LM | Working as **toy** |
| `model/` | Product TinyLM | Working toy-scale |
| `api.py` | FastAPI | Working; **no auth** |
| `webui/index.html` | Chat UI | Working; uses `textContent` for messages |
| `orbit/models/` | ModelProvider | Working (echo/ollama/gguf/openai/tinylm) |
| `orbit/mcp/` | MCP adapter | Adapter only; no live MCP client |
| `evals/` | Smoke eval | Working; not model quality bench |

---

## 3. What is genuinely implemented vs described

| Claim | Reality |
|-------|---------|
| Multi-agent orchestration | **Yes** — rule/score routing + tools |
| Thinking loop | **Yes** — structured steps, not LLM CoT |
| Math/science | **Yes** — calculator + sympy paths |
| RAG | **Yes** for txt/md/csv/json; PDF/DOCX optional |
| TinyLM “AI chat” | **Toy** — persona retrieval carries quality; neural garble gated |
| Web research | **Partial** — DuckDuckGo or **honest stub** |
| Secure sandbox | **No** — subprocess + allowlist, not container; docs admit this |
| Auth API | **No** — bind 127.0.0.1 by default only |
| GGUF/Ollama | **Adapters present**; need local runtime/weights |
| Full GitHub tree | **No** — CI previously failed on missing `test_agents.py` |

---

## 4. Critical findings

### F1 — API has no authentication (confirmed)

**Evidence:** `api.py` exposes chat, documents, memory without Bearer/API key checks.  
**Impact:** If bound to `0.0.0.0`, any network client can use tools/memory.  
**Mitigation present:** Default host `127.0.0.1` in config/launcher.  
**Mitigation added:** Optional `ORBIT_API_KEY` (Bearer / X-API-Key); open when unset. Prefer bind 127.0.0.1.

### F2 — Sandbox is not a security boundary (confirmed, documented in code)

**Evidence:** `tools_legacy.py` comments state rlimits + import allowlist are best-effort; same host OS.  
**Probe:** `import os` blocked; `while True` times out (~5s).  
**Impact:** Do not treat as multi-tenant isolation.  
**Status:** Behavior matches documentation honesty — not a silent false claim.

### F3 — `agents.py` size / coupling (maintainability)

**Evidence:** ~1390 lines; Orchestrator + 12 agents + routing + naturalize in one file.  
**Impact:** Harder to test agents in isolation; circular risk with tools.  
**Recommendation:** Incremental extraction (not big-bang rewrite).

### F4 — Dual agent stacks

**Evidence:** `agents.py` Orchestrator vs `agent/ToolCallingAgent`.  
**Impact:** Two entry points; metrics may diverge.  
**Recommendation:** Prefer Orchestrator; keep `agent/` as secondary or thin wrapper.

### F5 — Web search quality

**Evidence:** Research can return irrelevant stub/live results for capability questions (mitigated by capability routing to chat).  
**Status:** Partially mitigated; still fragile for open web Q&A.

### F6 — GitHub CI vs local tree mismatch (confirmed)

**Evidence:** Remote lacked `test_agents.py`; CI fixed to skip if missing.  
**Impact:** Green CI does not mean full agent suite ran on GitHub.

---

## 5. Security review summary

| Area | Result |
|------|--------|
| Calculator div/0 | Controlled error |
| Missing tool | Structured failure |
| Tool exception | Caught → ToolResult |
| Max steps | `AgentStateMachine.should_stop()` |
| Memory session isolation (in-memory) | Separate Orchestrator instances isolated |
| RAG no docs | Honest message |
| Sandbox timeout | Stops (~2–5s) |
| Sandbox `import os` | Rejected |
| SAFE cannot run EXECUTION tools | Enforced |
| Web UI XSS | Message bodies via `textContent` (good) |
| API auth | **Absent** |
| Prompt injection | Tools gated by registry permissions, not model text |

**No confirmed sandbox escape demonstrated** in probes above; isolation remains host-level best-effort only.

---

## 6. Testing evidence (this audit)

```text
pytest test_agents.py tests/unit                 → 49 passed
pytest tests/security/test_edge_cases.py         → 10 passed
```

Hardware: Linux container, CPU, Python 3.12. No GPU claims.

Eval smoke (prior session): ~78% on expanded dataset — **tool/math success**, not language-model quality.

---

## 7. TinyLM classification

| Label | Applies? |
|-------|----------|
| Educational / toy architecture | **Yes** |
| Trained small checkpoint (persona) | **Yes** (optional ckpt) |
| Production chat model | **No** |
| Pretrained foundation model | **No** |

---

## 8. Recommended priorities (ordered)

1. Keep API default bind on localhost; optional `ORBIT_API_KEY` middleware.  
2. Upload full source to GitHub so CI runs agent tests.  
3. Split `agents.py` only when touching features (avoid rewrite).  
4. Do not market sandbox as multi-tenant secure.  
5. Expand eval for RAG/citation honesty cases.

---

## 9. Fixes / tests added this audit

- `tests/security/test_edge_cases.py` — Phase 5 edge cases (10 tests, all pass)  
- This document: `AUDIT/REPOSITORY_ANALYSIS.md`
