"""Inspect a trained BPE tokenizer: vocab size, special tokens, round-trips."""

from __future__ import annotations

import argparse
from pathlib import Path

from tokenizer import SPECIAL_TOKENS


SAMPLES = {
    "english": "The quick brown fox jumps over the lazy dog.",
    "unicode": "café 日本語 emoji 🚀 ñ",
    "filipino": "Magandang umaga! Kumusta ka na ba?",
    "python": "def hello(name: str) -> str:\n    return f'hi {name}'",
    "csharp": "public static int Add(int a, int b) => a + b;",
    "json": '{"ok": true, "n": 42}',
    "markdown": "# Title\n\n- item **bold**",
    "shell": "ls -la | grep '.py' && echo done",
}


def inspect(path: str) -> None:
    from bpe_tokenizer import BPETokenizer

    tok = BPETokenizer.load(path)
    vs = getattr(tok, "VOCAB_SIZE", None)
    print(f"Tokenizer: {path}")
    print(f"Vocab size: {vs}")
    print(f"Expected special tokens: {SPECIAL_TOKENS}")

    print("\nRound-trip tests:")
    for name, text in SAMPLES.items():
        ids = tok.encode(text, add_bos=False, add_eos=False)
        decoded = tok.decode(ids)
        ok = decoded == text or text in decoded or decoded in text
        # BPE may not be fully lossless depending on training corpus;
        # report both equality and length.
        status = "OK" if decoded == text else ("~" if ok else "DIFF")
        print(f"  [{status}] {name}: {len(text)} chars → {len(ids)} tokens")
        if decoded != text:
            print(f"       in : {text[:60]!r}")
            print(f"       out: {decoded[:60]!r}")


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("tokenizer", nargs="?", default="bpe_tokenizer.json")
    args = p.parse_args(argv)
    if not Path(args.tokenizer).exists():
        raise SystemExit(f"Not found: {args.tokenizer}")
    inspect(args.tokenizer)


if __name__ == "__main__":
    main()
