"""
Train a BPE tokenizer (ORBIT tokenizer V2 entry point).

Wraps the existing bpe_tokenizer.py training path and ensures the expanded
special-token set is present.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable, List, Optional

from tokenizer import SPECIAL_TOKENS


def collect_texts(paths: List[Path], max_chars: Optional[int] = None) -> str:
    chunks: List[str] = []
    total = 0
    for p in paths:
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.suffix.lower() in {
                    ".txt", ".md", ".py", ".json", ".jsonl", ".cs", ".js",
                    ".ts", ".html", ".css", ".sql", ".yaml", ".yml", ".xml",
                } and f.is_file():
                    try:
                        t = f.read_text(encoding="utf-8", errors="replace")
                    except Exception:
                        continue
                    chunks.append(t)
                    total += len(t)
                    if max_chars and total >= max_chars:
                        return "\n".join(chunks)[:max_chars]
        elif p.is_file():
            t = p.read_text(encoding="utf-8", errors="replace")
            chunks.append(t)
            total += len(t)
            if max_chars and total >= max_chars:
                return "\n".join(chunks)[:max_chars]
    return "\n".join(chunks)


def train(
    data_paths: List[str],
    vocab_size: int = 1500,
    out: str = "tokenizer/tokenizer.json",
    max_chars: Optional[int] = 2_000_000,
) -> str:
    from bpe_tokenizer import BPETokenizer

    paths = [Path(p) for p in data_paths]
    text = collect_texts(paths, max_chars=max_chars)
    if not text.strip():
        raise SystemExit("No training text found. Provide files or directories.")

    # Ensure special tokens appear in the corpus so they get ids
    text = "\n".join(SPECIAL_TOKENS) + "\n" + text

    tok = BPETokenizer()
    # Existing API variants
    if hasattr(tok, "train"):
        tok.train(text, vocab_size=vocab_size)
    elif hasattr(BPETokenizer, "train_from_text"):
        tok = BPETokenizer.train_from_text(text, vocab_size=vocab_size)
    else:
        # Fall back to module-level helpers if present
        import bpe_tokenizer as bt
        if hasattr(bt, "train_bpe"):
            tok = bt.train_bpe(text, vocab_size=vocab_size)
        else:
            raise RuntimeError("Could not find a train method on BPETokenizer")

    out_path = Path(out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if hasattr(tok, "save"):
        tok.save(str(out_path))
    else:
        # Some versions save via json dump of merges
        import json
        payload = {
            "vocab_size": getattr(tok, "VOCAB_SIZE", vocab_size),
            "special_tokens": SPECIAL_TOKENS,
        }
        if hasattr(tok, "merges"):
            payload["merges"] = list(tok.merges)
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    print(f"Saved tokenizer → {out_path}")
    print(f"Vocab size: {getattr(tok, 'VOCAB_SIZE', vocab_size)}")
    return str(out_path)


def main(argv=None):
    p = argparse.ArgumentParser(description="Train ORBIT BPE tokenizer")
    p.add_argument("data", nargs="+", help="Files or directories of training text")
    p.add_argument("--vocab-size", type=int, default=1500)
    p.add_argument("--out", default="tokenizer/tokenizer.json")
    p.add_argument("--max-chars", type=int, default=2_000_000)
    args = p.parse_args(argv)
    train(args.data, vocab_size=args.vocab_size, out=args.out, max_chars=args.max_chars)


if __name__ == "__main__":
    main()
