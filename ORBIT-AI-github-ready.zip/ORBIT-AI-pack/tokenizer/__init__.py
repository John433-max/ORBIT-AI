"""
ORBIT tokenizer package (v2).

Re-exports the working BPE tokenizer and defines the expanded special-token set.
"""

from bpe_tokenizer import BPETokenizer

SPECIAL_TOKENS = [
    "<pad>",
    "<unk>",
    "<bos>",
    "<eos>",
    "<system>",
    "<user>",
    "<assistant>",
    "<tool>",
    "<tool_result>",
]

__all__ = ["BPETokenizer", "SPECIAL_TOKENS"]
