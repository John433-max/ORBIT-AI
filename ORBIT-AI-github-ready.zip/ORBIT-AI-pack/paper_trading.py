"""
Paper-trading engine (spec Part 12). Simulated portfolio only — no broker
connection, no real order routing, no live-market data feed. Every trade
here is bookkeeping against a price series the caller supplies (historical
or synthetic). This intentionally does not implement Part 12's "if real
trading is later supported" branch — that requires broker auth, kill
switches, and explicit per-trade user authorization this prototype has no
business simulating away.
"""
import numpy as np


class PaperPortfolio:
    def __init__(self, starting_cash: float = 100_000.0, transaction_cost_bps: float = 5.0,
                 spread_bps: float = 0.0, slippage_bps: float = 0.0):
        self.cash = starting_cash
        self.starting_cash = starting_cash
        self.positions = {}   # symbol -> shares
        self.transaction_cost_bps = transaction_cost_bps
        self.spread_bps = spread_bps      # bid/ask spread paid on every trade
        self.slippage_bps = slippage_bps  # extra adverse move assumed on execution
        self.trade_log = []
        self._avg_cost = {}            # symbol -> volume-weighted average entry price
        self._closed_trade_pnls = []   # realized P&L per sell, for win-rate/profit-factor

    def _cost(self, notional: float) -> float:
        return abs(notional) * (self.transaction_cost_bps / 10_000.0)

    def _execution_price(self, price: float, side: str) -> float:
        """Apply spread + slippage: buys fill worse (higher), sells fill
        worse (lower) than the quoted mid price — the standard convention
        for modeling real fill costs beyond the flat commission."""
        adj_bps = (self.spread_bps / 2.0) + self.slippage_bps
        if side == "buy":
            return price * (1 + adj_bps / 10_000.0)
        return price * (1 - adj_bps / 10_000.0)

    def buy(self, symbol: str, price: float, shares: float):
        fill_price = self._execution_price(price, "buy")
        notional = fill_price * shares
        fee = self._cost(notional)
        total = notional + fee
        if total > self.cash:
            return {"ok": False, "error": "insufficient paper cash"}
        self.cash -= total
        prev_shares = self.positions.get(symbol, 0.0)
        prev_cost = self._avg_cost.get(symbol, 0.0)
        new_shares = prev_shares + shares
        # volume-weighted average cost basis, used later to compute realized P&L on sell
        self._avg_cost[symbol] = ((prev_cost * prev_shares) + (fill_price * shares)) / new_shares if new_shares else 0.0
        self.positions[symbol] = new_shares
        self.trade_log.append({"side": "buy", "symbol": symbol, "price": fill_price,
                                "shares": shares, "fee": fee})
        return {"ok": True, "cash": self.cash, "position": self.positions[symbol]}

    def sell(self, symbol: str, price: float, shares: float):
        held = self.positions.get(symbol, 0.0)
        if shares > held:
            return {"ok": False, "error": "insufficient paper position"}
        fill_price = self._execution_price(price, "sell")
        notional = fill_price * shares
        fee = self._cost(notional)
        self.cash += notional - fee
        self.positions[symbol] = held - shares
        realized_pnl = (fill_price - self._avg_cost.get(symbol, fill_price)) * shares - fee
        self._closed_trade_pnls.append(realized_pnl)
        self.trade_log.append({"side": "sell", "symbol": symbol, "price": fill_price,
                                "shares": shares, "fee": fee, "realized_pnl": realized_pnl})
        return {"ok": True, "cash": self.cash, "position": self.positions[symbol]}

    def mark_to_market(self, prices: dict) -> float:
        equity = self.cash
        for sym, shares in self.positions.items():
            equity += shares * prices.get(sym, 0.0)
        return equity

    def performance(self, prices: dict) -> dict:
        equity = self.mark_to_market(prices)
        pnl = equity - self.starting_cash
        wins = [t for t in self._closed_trade_pnls]
        n_wins = sum(1 for p in wins if p > 0)
        n_losses = sum(1 for p in wins if p <= 0)
        win_rate = n_wins / len(wins) if wins else None
        gross_profit = sum(p for p in wins if p > 0)
        gross_loss = -sum(p for p in wins if p < 0)
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (float("inf") if gross_profit > 0 else None)
        return {"equity": equity, "cash": self.cash, "pnl": pnl,
                "pnl_pct": 100.0 * pnl / self.starting_cash, "positions": dict(self.positions),
                "n_trades": len(self.trade_log), "win_rate": win_rate,
                "n_wins": n_wins, "n_losses": n_losses, "profit_factor": profit_factor}


def backtest_sma_crossover(prices: np.ndarray, fast: int = 5, slow: int = 20,
                            starting_cash: float = 100_000.0, symbol: str = "TOY",
                            spread_bps: float = 0.0, slippage_bps: float = 0.0,
                            stop_loss_pct: float = None, take_profit_pct: float = None):
    """
    A minimal, explicit out-of-sample-friendly backtest: SMA crossover on a
    supplied price array. This is the single most standard toy strategy in
    the literature, used here only to exercise the plumbing (position
    sizing, transaction costs, drawdown) — spec Part 12 requires every real
    strategy be validated out-of-sample, which a demo script cannot claim to
    have done for you.

    stop_loss_pct / take_profit_pct (e.g. 0.05 for 5%): if set, an open
    position is force-closed once it moves against/for the entry price by
    that fraction, checked every bar, ahead of the next SMA signal.

    KNOWN FILL-REALISM LIMITATION (spec Part 41's look-ahead-bias /
    unrealistic-fills audit, checked directly rather than assumed clean):
    the moving averages at bar t are computed from prices[t-window:t],
    which correctly EXCLUDES bar t itself -- verified directly, so there is
    no look-ahead bias in the signal calculation. However, the resulting
    trade is then executed at prices[t] -- that same bar's own price. That
    means the strategy is implicitly assumed to observe a signal built from
    data through bar t-1 and then transact AT bar t's price, which isn't
    achievable in live trading (you don't know bar t's price until it's
    already happened). This is a common simplification in toy/educational
    backtests, not unique to this one, but it's a real idealized-fill
    assumption worth being explicit about rather than silent on -- a more
    realistic version would execute at bar t+1's price instead. Not changed
    here because doing so would alter every existing result number in a way
    that needs its own verification pass, which is future work, not a
    same-session drive-by fix.
    """
    if len(prices) <= slow:
        raise ValueError("price series shorter than slow window")
    portfolio = PaperPortfolio(starting_cash, spread_bps=spread_bps, slippage_bps=slippage_bps)
    equity_curve = []
    position_open = False
    entry_price = None
    for t in range(slow, len(prices)):
        fast_ma = prices[t - fast:t].mean()
        slow_ma = prices[t - slow:t].mean()
        price = prices[t]

        if position_open and entry_price:
            change = (price - entry_price) / entry_price
            if (stop_loss_pct and change <= -stop_loss_pct) or (take_profit_pct and change >= take_profit_pct):
                portfolio.sell(symbol, price, portfolio.positions.get(symbol, 0.0))
                position_open, entry_price = False, None
                equity_curve.append(portfolio.mark_to_market({symbol: price}))
                continue

        if fast_ma > slow_ma and not position_open:
            shares = (portfolio.cash * 0.95) / price
            portfolio.buy(symbol, price, shares)
            position_open = True
            entry_price = price
        elif fast_ma < slow_ma and position_open:
            portfolio.sell(symbol, price, portfolio.positions.get(symbol, 0.0))
            position_open = False
            entry_price = None
        equity_curve.append(portfolio.mark_to_market({symbol: price}))

    equity_curve = np.array(equity_curve)
    running_max = np.maximum.accumulate(equity_curve)
    drawdown = (equity_curve - running_max) / running_max
    max_drawdown_pct = float(drawdown.min() * 100.0)
    perf = portfolio.performance({symbol: prices[-1]})
    perf["max_drawdown_pct"] = max_drawdown_pct
    perf["equity_curve"] = equity_curve.tolist()
    buy_hold_pnl_pct = 100.0 * (prices[-1] - prices[slow]) / prices[slow]
    perf["buy_and_hold_pnl_pct"] = buy_hold_pnl_pct

    # Sharpe ratio on per-bar equity returns (unannualized — this backtest's
    # bar spacing isn't tied to a real calendar frequency, so annualizing
    # would imply a precision the synthetic/demo data doesn't have).
    if len(equity_curve) > 1:
        rets = np.diff(equity_curve) / equity_curve[:-1]
        perf["sharpe_ratio"] = float(rets.mean() / rets.std()) if rets.std() > 0 else None
    else:
        perf["sharpe_ratio"] = None
    perf["fill_assumption"] = ("signals use only prior-bar data (no look-ahead), but trades execute "
                                "at the same bar's own price -- an idealized fill, see this function's "
                                "docstring")
    return perf
