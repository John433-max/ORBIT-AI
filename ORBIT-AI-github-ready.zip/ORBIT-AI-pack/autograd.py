"""
Minimal reverse-mode autograd engine, NumPy-only.

Why this exists: the sandbox this prototype was built in has ~2.8GB free disk
and no route to a CUDA-free PyTorch wheel (only pypi.org/files.pythonhosted.org
are reachable, and default `pip install torch` pulls multi-GB CUDA deps that
don't fit). Rather than fake a torch-based prototype that was never actually
run, this is a real, small, tested autograd engine — every op below has a
forward pass and a hand-derived backward pass, and gradients are checked
numerically in test_autograd.py. It is NOT meant to be a production training
stack. It's meant to make every operation in the model transparent and to
prove the training loop genuinely reduces loss end to end.

Supports: elementwise +, -, *, /, matmul (batched, broadcasting), reshape,
transpose, sum/mean along an axis, pow, sqrt, softmax, SiLU, embedding
lookup (gather + scatter-add), and cross-entropy.
"""
import numpy as np

class Tensor:
    __slots__ = ("data", "grad", "_backward", "_prev", "requires_grad")

    def __init__(self, data, _children=(), requires_grad=True):
        self.data = np.asarray(data, dtype=np.float64)
        self.grad = None
        self._backward = lambda: None
        self._prev = set(_children)
        self.requires_grad = requires_grad

    def _accum(self, g):
        if self.grad is None:
            self.grad = np.zeros_like(self.data)
        # sum-reduce any broadcast dims so grad shape matches data shape
        g = np.asarray(g, dtype=np.float64)
        while g.ndim > self.data.ndim:
            g = g.sum(axis=0)
        for ax, (dg, dd) in enumerate(zip(g.shape, self.data.shape)):
            if dd == 1 and dg != 1:
                g = g.sum(axis=ax, keepdims=True)
        self.grad += g

    def zero_grad(self):
        self.grad = None

    def backward(self):
        topo, visited = [], set()

        def build(v):
            if id(v) not in visited:
                visited.add(id(v))
                for p in v._prev:
                    build(p)
                topo.append(v)
        build(self)
        self.grad = np.ones_like(self.data)
        for v in reversed(topo):
            v._backward()
        # Break the self-referential cycle each node forms: `out._backward`
        # is a closure over `out` itself (it reads/writes out.grad via the
        # enclosing scope), and `out` holds a reference to that closure --
        # a genuine reference cycle that only Python's generational cyclic
        # GC can reclaim, not ordinary refcounting. Left alone, an entire
        # step's forward graph stays alive until cyclic GC happens to run,
        # which is allocation-count-triggered, not byte-size-triggered --
        # so a training loop building large arrays but relatively few
        # Tensor objects per step can balloon by hundreds of MB before GC
        # catches up (confirmed directly: unbounded growth per step without
        # this fix, constant memory with it). Clearing _backward/_prev here
        # lets ordinary refcounting free each step's entire graph the
        # instant the caller's local variables (loss, activations) go out
        # of scope, with no dependency on GC timing. Safe to do
        # unconditionally: gradients are already accumulated into .grad
        # (plain numpy arrays, untouched by this), and backward() is only
        # ever called once per freshly-built graph.
        for v in topo:
            v._backward = lambda: None
            v._prev = set()

    # ---- elementwise ----
    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = Tensor(self.data + other.data, (self, other))
        def _bw():
            self._accum(out.grad)
            other._accum(out.grad)
        out._backward = _bw
        return out

    def __neg__(self):
        return self * -1.0

    def __sub__(self, other):
        return self + (-(other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)))

    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = Tensor(self.data * other.data, (self, other))
        def _bw():
            self._accum(out.grad * other.data)
            other._accum(out.grad * self.data)
        out._backward = _bw
        return out
    __rmul__ = __mul__

    def __truediv__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        return self * other.pow(-1.0)

    def pow(self, p):
        out = Tensor(self.data ** p, (self,))
        def _bw():
            self._accum(out.grad * p * (self.data ** (p - 1)))
        out._backward = _bw
        return out

    def sqrt(self):
        return self.pow(0.5)

    # ---- shape ops ----
    def reshape(self, *shape):
        out = Tensor(self.data.reshape(*shape), (self,))
        orig_shape = self.data.shape
        def _bw():
            self._accum(out.grad.reshape(orig_shape))
        out._backward = _bw
        return out

    def transpose(self, *axes):
        out = Tensor(self.data.transpose(*axes), (self,))
        inv = np.argsort(axes)
        def _bw():
            self._accum(out.grad.transpose(*inv))
        out._backward = _bw
        return out

    def sum(self, axis=None, keepdims=False):
        out = Tensor(self.data.sum(axis=axis, keepdims=keepdims), (self,))
        shape = self.data.shape
        def _bw():
            g = out.grad
            if not keepdims and axis is not None:
                g = np.expand_dims(g, axis)
            self._accum(np.broadcast_to(g, shape))
        out._backward = _bw
        return out

    def mean(self, axis=None, keepdims=False):
        n = self.data.size if axis is None else self.data.shape[axis]
        return self.sum(axis=axis, keepdims=keepdims) * (1.0 / n)

    # ---- matmul (supports batched leading dims via broadcasting) ----
    def matmul(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = Tensor(np.matmul(self.data, other.data), (self, other))
        def _bw():
            a, b = self.data, other.data
            gA = np.matmul(out.grad, np.swapaxes(b, -1, -2))
            gB = np.matmul(np.swapaxes(a, -1, -2), out.grad)
            self._accum(gA)
            other._accum(gB)
        out._backward = _bw
        return out

    def __matmul__(self, other):
        return self.matmul(other)

    # ---- activations ----
    def silu(self):
        s = 1.0 / (1.0 + np.exp(-self.data))
        y = self.data * s
        out = Tensor(y, (self,))
        def _bw():
            dy = s * (1 + self.data * (1 - s))
            self._accum(out.grad * dy)
        out._backward = _bw
        return out

    def softmax(self, axis=-1):
        x = self.data - self.data.max(axis=axis, keepdims=True)
        e = np.exp(x)
        y = e / e.sum(axis=axis, keepdims=True)
        out = Tensor(y, (self,))
        def _bw():
            g = out.grad
            dot = (g * y).sum(axis=axis, keepdims=True)
            self._accum(y * (g - dot))
        out._backward = _bw
        return out

    def __repr__(self):
        return f"Tensor(shape={self.data.shape})"


def embedding_lookup(weight: Tensor, indices: np.ndarray) -> Tensor:
    """weight: (V, D) Tensor, indices: int array of any shape -> (*indices.shape, D)"""
    idx = np.asarray(indices)
    out = Tensor(weight.data[idx], (weight,))
    def _bw():
        g = np.zeros_like(weight.data)
        np.add.at(g, idx, out.grad)
        weight._accum(g)
    out._backward = _bw
    return out


def cross_entropy(logits: Tensor, targets: np.ndarray) -> Tensor:
    """logits: (N, V) Tensor, targets: (N,) int array. Returns scalar mean loss."""
    x = logits.data - logits.data.max(axis=-1, keepdims=True)
    e = np.exp(x)
    probs = e / e.sum(axis=-1, keepdims=True)
    n = logits.data.shape[0]
    nll = -np.log(np.clip(probs[np.arange(n), targets], 1e-12, None))
    loss_val = nll.mean()
    out = Tensor(loss_val, (logits,))
    def _bw():
        g = probs.copy()
        g[np.arange(n), targets] -= 1.0
        g /= n
        logits._accum(g * out.grad)
    out._backward = _bw
    return out
