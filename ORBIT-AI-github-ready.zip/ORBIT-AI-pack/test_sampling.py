"""Tests for sampling.py — confirms each generation parameter (Phase 8)
actually changes behavior rather than being accepted and ignored."""
import numpy as np
import pytest

from sampling import sample_next_token, find_stop_sequence


def test_top_k_restricts_candidates():
    logits = np.array([5.0, 4.9, 4.8, -10.0, -10.0])
    rng = np.random.default_rng(0)
    picks = {sample_next_token(logits, [], temperature=1.0, top_p=1.0, top_k=2,
                                 repetition_penalty=1.0, rng=rng) for _ in range(300)}
    assert picks <= {0, 1}


def test_top_k_zero_disables_filtering():
    logits = np.array([1.0, 1.0, 1.0, 1.0])
    rng = np.random.default_rng(0)
    picks = {sample_next_token(logits, [], temperature=1.0, top_p=1.0, top_k=0,
                                 repetition_penalty=1.0, rng=rng) for _ in range(300)}
    assert picks == {0, 1, 2, 3}  # uniform logits, top_k off -> everything reachable


def test_temperature_near_zero_is_near_greedy():
    logits = np.array([0.0, 5.0, 1.0])
    rng = np.random.default_rng(0)
    picks = [sample_next_token(logits, [], temperature=1e-4, top_p=1.0, top_k=0,
                                 repetition_penalty=1.0, rng=rng) for _ in range(20)]
    assert all(p == 1 for p in picks)  # index 1 has by far the highest logit


def test_top_p_excludes_low_probability_tail():
    logits = np.array([10.0, -10.0, -10.0, -10.0])  # one dominant token
    rng = np.random.default_rng(0)
    picks = {sample_next_token(logits, [], temperature=1.0, top_p=0.5, top_k=0,
                                 repetition_penalty=1.0, rng=rng) for _ in range(100)}
    assert picks == {0}


def test_repetition_penalty_reduces_repeat_probability():
    logits = np.array([5.0, 1.0, 1.0])
    rng1 = np.random.default_rng(0)
    rng2 = np.random.default_rng(0)
    no_penalty = [sample_next_token(logits, [0], temperature=1.0, top_p=1.0, top_k=0,
                                      repetition_penalty=1.0, rng=rng1) for _ in range(200)]
    with_penalty = [sample_next_token(logits, [0], temperature=1.0, top_p=1.0, top_k=0,
                                        repetition_penalty=3.0, rng=rng2) for _ in range(200)]
    assert no_penalty.count(0) > with_penalty.count(0)


def test_find_stop_sequence_locates_earliest():
    assert find_stop_sequence("hello world END more", ["END", "more"]) == 12


def test_find_stop_sequence_returns_minus_one_when_absent():
    assert find_stop_sequence("hello world", ["STOP"]) == -1


def test_find_stop_sequence_empty_list():
    assert find_stop_sequence("hello world", []) == -1


def test_sampling_never_returns_out_of_range_index():
    rng = np.random.default_rng(0)
    logits = np.random.default_rng(1).normal(size=50)
    for _ in range(50):
        idx = sample_next_token(logits, [], temperature=0.8, top_p=0.9, top_k=10,
                                  repetition_penalty=1.3, rng=rng)
        assert 0 <= idx < 50
