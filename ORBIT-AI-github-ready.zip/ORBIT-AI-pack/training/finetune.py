"""
Instruction tuning entry point.

Supports:
  {"instruction", "input", "output"}   (Alpaca-style)
  {"messages": [{"role","content"}, ...]}

Does not overwrite the base checkpoint; writes under checkpoints/instruct/.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Union

import numpy as np

from chat.template import ChatTemplate, apply_chat_template
from model import TinyLM, get_preset, OrbitConfig
from training.checkpoint import ensure_dirs, save_numpy_checkpoint
from training.trainer import Trainer, SimpleAdam


def load_instruction_records(path: Union[str, Path]) -> List[Dict[str, Any]]:
    path = Path(path)
    rows: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def record_to_messages(row: Dict[str, Any]) -> List[Dict[str, str]]:
    if "messages" in row:
        return list(row["messages"])
    # Alpaca-style
    inst = row.get("instruction", "")
    inp = row.get("input", "")
    out = row.get("output", "")
    user = inst if not inp else f"{inst}\n\n{inp}"
    return [
        {"role": "user", "content": user},
        {"role": "assistant", "content": out},
    ]


def records_to_text(rows: List[Dict[str, Any]], template: Optional[ChatTemplate] = None) -> str:
    tpl = template or ChatTemplate()
    chunks = []
    for row in rows:
        msgs = record_to_messages(row)
        chunks.append(tpl.format(msgs, add_generation_prompt=False))
        chunks.append(tpl.special.get("eos", "<eos>"))
    return "\n".join(chunks)


def finetune(
    data_path: str,
    base_checkpoint: Optional[str] = None,
    preset: str = "development",
    steps: int = 100,
    out_dir: str = "checkpoints/instruct",
) -> Dict[str, Any]:
    """
    Light instruction fine-tune on top of a base model (or from scratch).
    """
    from bpe_tokenizer import BPETokenizer

    rows = load_instruction_records(data_path)
    if not rows:
        raise ValueError(f"No instruction records in {data_path}")

    text = records_to_text(rows)
    # Also fold in persona_chat if present
    persona = Path("persona_chat.jsonl")
    if persona.exists():
        text += "\n" + records_to_text(load_instruction_records(persona))

    cfg = get_preset(preset)
    tok_path = Path("bpe_tokenizer.json")
    if tok_path.exists():
        tok = BPETokenizer.load(str(tok_path))
    else:
        tok = BPETokenizer().train(text, vocab_size=min(cfg.model.vocab_size, 700), min_frequency=1)

    ids = np.array(tok.encode(text, add_bos=False, add_eos=False), dtype=np.int64)
    cfg.model.vocab_size = getattr(tok, "VOCAB_SIZE", cfg.model.vocab_size)

    # Build / load model
    model = TinyLM.from_config(cfg.model)
    if base_checkpoint and Path(base_checkpoint).exists():
        try:
            from train import load_into
            load_into(model, base_checkpoint)
            print(f"Loaded base checkpoint {base_checkpoint}")
        except Exception as e:
            print(f"Could not load base checkpoint ({e}); training from scratch weights")

    n = len(ids)
    split = max(int(n * 0.9), 1)
    trainer = Trainer(cfg, ids[:split], ids[split:] if split < n else ids[:split])
    trainer.model = model  # use loaded weights
    # rebuild optimizer for current params
    betas = tuple(cfg.training.betas or [0.9, 0.95])
    trainer.opt = SimpleAdam(
        model.params(),
        lr=cfg.training.learning_rate * 0.5,  # gentler LR for finetune
        betas=betas,
        eps=cfg.training.eps,
        wd=cfg.training.weight_decay,
    )

    result = trainer.train(steps=steps)

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    save_numpy_checkpoint(
        trainer.model,
        out / "model.npz",
        metadata={
            **result,
            "kind": "instruct",
            "data_path": str(data_path),
            "n_records": len(rows),
            "config": cfg.model.to_dict(),
        },
    )
    print(f"Instruct checkpoint → {out / 'model.npz'}")
    return result


def main(argv=None):
    import argparse
    p = argparse.ArgumentParser(description="ORBIT instruction fine-tuning")
    p.add_argument("--data", default="datasets/instruction/sample_alpaca.jsonl")
    p.add_argument("--base", default=None, help="Base checkpoint .npz")
    p.add_argument("--preset", default="development")
    p.add_argument("--steps", type=int, default=50)
    p.add_argument("--out", default="checkpoints/instruct")
    args = p.parse_args(argv)
    finetune(args.data, base_checkpoint=args.base, preset=args.preset, steps=args.steps, out_dir=args.out)


if __name__ == "__main__":
    main()
