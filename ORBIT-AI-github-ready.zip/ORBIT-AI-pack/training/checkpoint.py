"""
Checkpoint V2 helpers.

Directory layout:
  checkpoints/
    latest/
    best/
    archives/

A checkpoint contains:
  model state, optimizer state (optional), scheduler state (optional),
  step, epoch, configuration, tokenizer version, dataset info,
  training metrics, random seed.
"""

from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from typing import Any, Dict, Optional, Union

import numpy as np


CHECKPOINT_ROOT = Path("checkpoints")


def ensure_dirs() -> None:
    for sub in ("latest", "best", "archives"):
        (CHECKPOINT_ROOT / sub).mkdir(parents=True, exist_ok=True)


def _meta_path(stem: Path) -> Path:
    return stem.with_suffix(".json")


def save_numpy_checkpoint(
    model,
    path: Union[str, Path],
    metadata: Optional[Dict[str, Any]] = None,
    optimizer_state: Optional[Dict] = None,
) -> Path:
    """
    Save model weights as .npz + metadata sidecar .json.
    Compatible with existing train.py load_into / save_checkpoint patterns.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    # Collect params
    if hasattr(model, "params"):
        params = model.params()
        arrays = {}
        for i, p in enumerate(params):
            data = p.data if hasattr(p, "data") else np.asarray(p)
            arrays[f"p{i}"] = data
    else:
        raise TypeError("model has no params() method")

    np.savez_compressed(str(path), **arrays)

    meta = {
        "saved_at": time.time(),
        "n_tensors": len(arrays),
        "format": "orbit-numpy-v2",
    }
    if metadata:
        meta.update(metadata)
    if optimizer_state is not None:
        meta["has_optimizer_state"] = True
        # store optimizer in a sibling file if provided as arrays
        opt_path = path.with_suffix(".opt.npz")
        if isinstance(optimizer_state, dict) and all(
            isinstance(v, np.ndarray) for v in optimizer_state.values()
        ):
            np.savez_compressed(str(opt_path), **optimizer_state)
            meta["optimizer_path"] = str(opt_path.name)

    with open(_meta_path(path), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, default=str)

    return path


def load_numpy_checkpoint(model, path: Union[str, Path]) -> Dict[str, Any]:
    """Load weights into model; return metadata dict."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)

    # Prefer existing train.load_into when available
    try:
        from train import load_into
        load_into(model, str(path))
    except Exception:
        data = np.load(str(path))
        params = model.params()
        for i, p in enumerate(params):
            key = f"p{i}"
            if key in data:
                p.data[...] = data[key]

    meta_file = _meta_path(path)
    if meta_file.exists():
        with open(meta_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def promote_to_latest(path: Union[str, Path], name: str = "checkpoint") -> Path:
    ensure_dirs()
    path = Path(path)
    dest = CHECKPOINT_ROOT / "latest" / f"{name}.npz"
    shutil.copy2(path, dest)
    meta = _meta_path(path)
    if meta.exists():
        shutil.copy2(meta, _meta_path(dest))
    return dest


def promote_to_best(path: Union[str, Path], name: str = "checkpoint") -> Path:
    ensure_dirs()
    path = Path(path)
    dest = CHECKPOINT_ROOT / "best" / f"{name}.npz"
    shutil.copy2(path, dest)
    meta = _meta_path(path)
    if meta.exists():
        shutil.copy2(meta, _meta_path(dest))
    return dest


def archive_checkpoint(path: Union[str, Path], tag: Optional[str] = None) -> Path:
    ensure_dirs()
    path = Path(path)
    tag = tag or time.strftime("%Y%m%d_%H%M%S")
    dest = CHECKPOINT_ROOT / "archives" / f"{path.stem}_{tag}.npz"
    shutil.copy2(path, dest)
    meta = _meta_path(path)
    if meta.exists():
        shutil.copy2(meta, _meta_path(dest))
    return dest
