"""
Config-driven trainer (ORBIT v2).

Uses OrbitConfig / YAML presets. Does not replace train.py; it provides a
cleaner entry point that respects the expanded parameter set.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from model import TinyLM, OrbitConfig, get_preset
from training.checkpoint import (
    save_numpy_checkpoint,
    promote_to_latest,
    promote_to_best,
    ensure_dirs,
)


def _clip_grad_norm(params, max_norm: float) -> float:
    total_sq = 0.0
    for p in params:
        if p.grad is not None:
            total_sq += float(np.sum(p.grad ** 2))
    total_norm = float(np.sqrt(total_sq + 1e-12))
    if total_norm > max_norm and total_norm > 0:
        scale = max_norm / (total_norm + 1e-6)
        for p in params:
            if p.grad is not None:
                p.grad *= scale
    return total_norm


def _lr_at_step(step: int, base_lr: float, warmup: int, max_steps: int, min_ratio: float) -> float:
    if step < warmup:
        return base_lr * (step + 1) / max(warmup, 1)
    progress = (step - warmup) / max(max_steps - warmup, 1)
    progress = min(1.0, max(0.0, progress))
    # cosine
    return base_lr * (min_ratio + 0.5 * (1 - min_ratio) * (1 + np.cos(np.pi * progress)))


class SimpleAdam:
    def __init__(self, params, lr=3e-4, betas=(0.9, 0.95), eps=1e-8, wd=0.1):
        self.params = list(params)
        self.lr = lr
        self.b1, self.b2 = betas
        self.eps = eps
        self.wd = wd
        self.m = [np.zeros_like(p.data) for p in self.params]
        self.v = [np.zeros_like(p.data) for p in self.params]
        self.t = 0

    def zero_grad(self):
        for p in self.params:
            p.grad = None

    def step(self, lr: Optional[float] = None):
        lr = self.lr if lr is None else lr
        self.t += 1
        for i, p in enumerate(self.params):
            if p.grad is None:
                continue
            g = p.grad
            if self.wd:
                g = g + self.wd * p.data
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * (g * g)
            mhat = self.m[i] / (1 - self.b1 ** self.t)
            vhat = self.v[i] / (1 - self.b2 ** self.t)
            p.data -= lr * mhat / (np.sqrt(vhat) + self.eps)


def make_batches(ids: np.ndarray, seq_len: int, batch_size: int, rng: np.random.Generator):
    n = len(ids) - seq_len - 1
    if n <= 0:
        return
    while True:
        starts = rng.integers(0, n, size=batch_size)
        x = np.stack([ids[s : s + seq_len] for s in starts])
        y = np.stack([ids[s + 1 : s + seq_len + 1] for s in starts])
        yield x, y


def eval_loss(model, ids: np.ndarray, seq_len: int, n_windows: int = 8) -> Tuple[float, float]:
    from autograd import cross_entropy

    if len(ids) < seq_len + 1:
        return float("nan"), float("nan")
    losses = []
    for i in range(n_windows):
        start = (i * seq_len) % max(len(ids) - seq_len - 1, 1)
        x = ids[start : start + seq_len][None, :]
        y = ids[start + 1 : start + seq_len + 1][None, :]
        logits = model(x)
        # logits may be (B,T,V) or Tensor
        data = logits.data if hasattr(logits, "data") else logits
        # cross_entropy expects Tensor usually
        try:
            loss = cross_entropy(logits, y.reshape(-1))
            losses.append(float(loss.data if hasattr(loss, "data") else loss))
        except Exception:
            # fallback manual
            from scipy.special import log_softmax  # may not exist
            break
    if not losses:
        return float("nan"), float("nan")
    mean = float(np.mean(losses))
    ppl = float(np.exp(min(mean, 20)))
    return mean, ppl


class Trainer:
    def __init__(self, config: OrbitConfig, train_ids: np.ndarray, val_ids: Optional[np.ndarray] = None):
        self.config = config
        self.train_ids = train_ids
        self.val_ids = val_ids if val_ids is not None else train_ids
        self.model = TinyLM.from_config(config.model)
        betas = tuple(config.training.betas or [0.9, 0.95])
        self.opt = SimpleAdam(
            self.model.params(),
            lr=config.training.learning_rate,
            betas=betas,
            eps=config.training.eps,
            wd=config.training.weight_decay,
        )
        self.step = 0
        self.best_val = float("inf")
        self.history: List[Dict[str, Any]] = []
        ensure_dirs()

    def train(self, steps: Optional[int] = None) -> Dict[str, Any]:
        from autograd import cross_entropy

        tc = self.config.training
        mc = self.config.model
        steps = steps or tc.max_steps
        seq_len = tc.seq_len or min(mc.context_length, 64)
        batch_size = tc.batch_size
        rng = np.random.default_rng(tc.seed)
        batches = make_batches(self.train_ids, seq_len, batch_size, rng)

        t0 = time.time()
        tokens_seen = 0
        for step in range(steps):
            self.step = step
            lr = _lr_at_step(step, tc.learning_rate, tc.warmup_steps, steps, tc.min_lr_ratio)
            self.opt.zero_grad()
            loss_acc = 0.0
            for _ in range(max(1, tc.gradient_accumulation)):
                x, y = next(batches)
                logits = self.model(x)
                loss = cross_entropy(logits, y.reshape(-1))
                loss.backward()
                loss_acc += float(loss.data)
                tokens_seen += x.size
            loss_acc /= max(1, tc.gradient_accumulation)
            gn = _clip_grad_norm(self.model.params(), tc.grad_clip)
            self.opt.step(lr=lr)

            record = {"step": step, "loss": loss_acc, "lr": lr, "grad_norm": gn}
            if step % max(1, tc.log_interval) == 0:
                print(f"  step {step:5d}/{steps}  loss={loss_acc:.4f}  lr={lr:.2e}  gn={gn:.3f}")
            if step > 0 and step % max(1, tc.eval_interval) == 0:
                val_loss, val_ppl = eval_loss(self.model, self.val_ids, seq_len)
                record["val_loss"] = val_loss
                record["val_ppl"] = val_ppl
                print(f"    val_loss={val_loss:.4f}  val_ppl={val_ppl:.2f}")
                if val_loss < self.best_val:
                    self.best_val = val_loss
                    path = save_numpy_checkpoint(
                        self.model,
                        "checkpoints/best/model.npz",
                        metadata={
                            "step": step,
                            "val_loss": val_loss,
                            "val_ppl": val_ppl,
                            "config": self.config.model.to_dict(),
                            "seed": tc.seed,
                            "n_params": self.model.param_count(),
                        },
                    )
                    promote_to_best(path)
            if step > 0 and step % max(1, tc.save_interval) == 0:
                path = save_numpy_checkpoint(
                    self.model,
                    "checkpoints/latest/model.npz",
                    metadata={
                        "step": step,
                        "loss": loss_acc,
                        "config": self.config.model.to_dict(),
                        "seed": tc.seed,
                        "n_params": self.model.param_count(),
                    },
                )
                promote_to_latest(path)
            self.history.append(record)

        elapsed = time.time() - t0
        tps = tokens_seen / max(elapsed, 1e-6)
        final_val, final_ppl = eval_loss(self.model, self.val_ids, seq_len)
        result = {
            "steps": steps,
            "elapsed_s": elapsed,
            "tokens_seen": tokens_seen,
            "tokens_per_sec": tps,
            "final_train_loss": self.history[-1]["loss"] if self.history else None,
            "final_val_loss": final_val,
            "final_val_ppl": final_ppl,
            "best_val_loss": self.best_val,
            "n_params": self.model.param_count(),
        }
        # final save
        save_numpy_checkpoint(
            self.model,
            "checkpoints/latest/model.npz",
            metadata={**result, "config": self.config.model.to_dict()},
        )
        Path("logs").mkdir(exist_ok=True)
        with open("logs/metrics.json", "w", encoding="utf-8") as f:
            json.dump({"result": result, "history": self.history[-200:]}, f, indent=2)
        print(f"Done. {tps:.0f} tok/s  val_ppl={final_ppl:.2f}  params={result['n_params']:,}")
        return result


def train_from_preset(
    preset: str = "development",
    text: Optional[str] = None,
    steps: Optional[int] = None,
) -> Dict[str, Any]:
    """Convenience: train a preset on provided text or a tiny built-in sample."""
    from bpe_tokenizer import BPETokenizer

    cfg = get_preset(preset)
    if text is None:
        text = (
            "ORBIT is a modular from-scratch language model and agent platform. "
            "It includes a tokenizer, transformer, training loop, memory, RAG, and tools. "
        ) * 50
    tok = BPETokenizer()
    if hasattr(tok, "train"):
        tok = tok.train(text, vocab_size=min(cfg.model.vocab_size, 700), min_frequency=1)
    ids = np.array(tok.encode(text, add_bos=False, add_eos=False), dtype=np.int64)
    # shrink vocab to actual for this quick path
    cfg.model.vocab_size = getattr(tok, "VOCAB_SIZE", cfg.model.vocab_size)
    n = len(ids)
    split = max(int(n * 0.9), 1)
    trainer = Trainer(cfg, ids[:split], ids[split:] if split < n else ids[:split])
    return trainer.train(steps=steps or min(cfg.training.max_steps, 100))
