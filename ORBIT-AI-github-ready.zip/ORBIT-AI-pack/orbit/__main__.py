"""
ORBIT command-line interface.

Usage:
  python -m orbit chat
  python -m orbit generate --prompt "hello"
  python -m orbit train --config tiny
  python -m orbit evaluate
  python -m orbit agent --message "2+2"
  python -m orbit server
  python -m orbit version
"""

from __future__ import annotations

import argparse
import sys


def cmd_version(_args):
    from orbit import __version__
    print(f"ORBIT {__version__}")


def cmd_agent(args):
    from agent import ToolCallingAgent
    agent = ToolCallingAgent(permission_level=args.permission)
    result = agent.run(args.message)
    print(result.get("content", result))


def cmd_generate(args):
    try:
        from generate import main as gen_main  # if it has main
    except Exception:
        pass
    print("Generation: use the existing generate.py script for full control.")
    print(f"Prompt would be: {args.prompt!r}")
    # Minimal path using current stack
    try:
        from bpe_tokenizer import BPETokenizer
        from model import TinyLM, get_preset
        from sampling import sample_next_token
        import numpy as np
        from pathlib import Path

        tok_path = Path("bpe_tokenizer.json")
        if not tok_path.exists():
            print("No bpe_tokenizer.json found. Run train.py first.")
            return
        tok = BPETokenizer.load(str(tok_path))
        cfg = get_preset(args.config)
        # Prefer matching vocab if possible
        model = TinyLM.from_config(cfg.model, vocab_size=tok.VOCAB_SIZE)
        ckpt = Path("checkpoint_base.npz")
        if ckpt.exists():
            from train import load_into
            load_into(model, str(ckpt))
            print(f"Loaded {ckpt}")
        else:
            print("No checkpoint_base.npz — generating with random weights (noise).")

        ids = tok.encode(args.prompt, add_bos=False, add_eos=False)
        rng = np.random.default_rng(args.seed)
        for _ in range(args.max_tokens):
            # Simple forward; no KV cache yet
            import numpy as np
            logits = model(np.array([ids[-model.max_seq_len:]]))
            # logits shape depends on implementation
            row = logits.data[0, -1] if logits.data.ndim == 3 else logits.data[-1]
            nxt = sample_next_token(row, ids, temperature=args.temperature, rng=rng)
            ids.append(int(nxt))
        print(tok.decode(ids))
    except Exception as e:
        print(f"generate failed: {e}")
        raise


def cmd_train(args):
    print(f"Training with config={args.config}. Delegating to train.py ...")
    import runpy
    sys.argv = ["train.py"]  # keep train.py's own argparse if any
    # train.py currently runs on import/main; call its main path carefully
    import train
    if hasattr(train, "main"):
        train.main()
    else:
        print("train.py has no main(); run `python train.py` directly for the full loop.")


def cmd_server(args):
    import uvicorn
    print(f"Starting API on {args.host}:{args.port}")
    uvicorn.run("api:app", host=args.host, port=args.port, reload=args.reload)




def cmd_search(args):
    from tools import default_registry, ToolCall
    reg = default_registry("SAFE")
    r = reg.execute(ToolCall(tool="web.search", arguments={"query": args.query, "max_results": args.max_results}))
    print(r.content if r.ok else (r.error or r.content))
    return 0 if r.ok else 1

def cmd_finetune(args):
    from training.finetune import finetune
    finetune(args.data, base_checkpoint=args.base, preset=args.preset, steps=args.steps, out_dir=args.out)

def cmd_chat(args):
    print("Interactive chat (type 'quit' to exit). Uses ToolCallingAgent.")
    from agent import ToolCallingAgent
    agent = ToolCallingAgent(permission_level=args.permission)
    while True:
        try:
            msg = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not msg or msg.lower() in ("quit", "exit"):
            break
        result = agent.run(msg)
        print("orbit>", result.get("content", result))


def main(argv=None):
    parser = argparse.ArgumentParser(prog="orbit", description="ORBIT LLM + Agent platform")
    sub = parser.add_subparsers(dest="command")

    p_ver = sub.add_parser("version", help="Print version")
    p_ver.set_defaults(func=cmd_version)

    p_agent = sub.add_parser("agent", help="Run structured tool-calling agent")
    p_agent.add_argument("--message", "-m", required=True)
    p_agent.add_argument("--permission", default="SAFE", choices=["SAFE", "LIMITED", "FULL"])
    p_agent.set_defaults(func=cmd_agent)

    p_gen = sub.add_parser("generate", help="Generate text")
    p_gen.add_argument("--prompt", "-p", default="the quick brown")
    p_gen.add_argument("--config", default="tiny")
    p_gen.add_argument("--max-tokens", type=int, default=32)
    p_gen.add_argument("--temperature", type=float, default=0.8)
    p_gen.add_argument("--seed", type=int, default=0)
    p_gen.set_defaults(func=cmd_generate)

    p_train = sub.add_parser("train", help="Train a model")
    p_train.add_argument("--config", default="tiny")
    p_train.set_defaults(func=cmd_train)

    p_srv = sub.add_parser("server", help="Start FastAPI server")
    p_srv.add_argument("--host", default="127.0.0.1")
    p_srv.add_argument("--port", type=int, default=8000)
    p_srv.add_argument("--reload", action="store_true")
    p_srv.set_defaults(func=cmd_server)

    p_search = sub.add_parser("search", help="Web search (DuckDuckGo)")
    p_search.add_argument("query", nargs="+", help="Search query")
    p_search.add_argument("--max-results", type=int, default=5)
    def _run_search(a):
        a.query = " ".join(a.query) if isinstance(a.query, list) else a.query
        return cmd_search(a)
    p_search.set_defaults(func=_run_search)

    p_ft = sub.add_parser("finetune", help="Instruction fine-tune")
    p_ft.add_argument("--data", default="datasets/instruction/sample_alpaca.jsonl")
    p_ft.add_argument("--base", default=None)
    p_ft.add_argument("--preset", default="development")
    p_ft.add_argument("--steps", type=int, default=50)
    p_ft.add_argument("--out", default="checkpoints/instruct")
    p_ft.set_defaults(func=cmd_finetune)

    p_chat = sub.add_parser("chat", help="Interactive chat")
    p_chat.add_argument("--permission", default="SAFE", choices=["SAFE", "LIMITED", "FULL"])
    p_chat.set_defaults(func=cmd_chat)

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 1
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
