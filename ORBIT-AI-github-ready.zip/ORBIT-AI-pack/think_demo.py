#!/usr/bin/env python3
"""Show ORBIT thinking steps + answer."""
import json, sys
from orbit_ai import OrbitAI

ai = OrbitAI(persist=False, use_thinking=True)
msg = " ".join(sys.argv[1:]) or "what are the 4 elements"
r = ai.orch.think(msg)
print("THINKING:")
for t in r.get("thinking") or []:
    print(f"  [{t['kind']}] {t['text']}")
print("\nANSWER:")
print(r.get("content"))
