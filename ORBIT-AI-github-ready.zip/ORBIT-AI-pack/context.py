"""
Conversation context (Phase 8) and short-term/conversation storage (Phase 31
basics — save/load/search/delete/export).

Context assembly follows the spec's priority order exactly: system
instructions > relevant long-term memory > relevant document information >
recent conversation > current request. Everything is token-budgeted against
the model's actual max_seq_len using the real tokenizer (not a character
estimate), and truncation happens lowest-priority-first so the model never
silently receives a context that changes its own claimed shape guarantees
(model.py raises ValueError above max_seq_len — this module's whole job is
to make sure that never fires because of a runaway context).
"""
import time
import sqlite3
import threading
import json


def _locked(method):
    """Same rationale as memory_store.py's _locked: FastAPI runs sync
    endpoints in a worker thread pool, so a single long-lived sqlite3
    connection needs serialized access across threads."""
    def wrapper(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    wrapper.__name__ = method.__name__
    wrapper.__doc__ = method.__doc__
    return wrapper


class ConversationStore:
    """Persists conversation turns to SQLite. This is the 'short-term
    memory' data layer — retrieval of *recent* turns for context, plus
    Phase 31's save/load/search/delete/export operations."""

    def __init__(self, db_path: str = "orbit_conversations.db"):
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at REAL NOT NULL
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_conv_id ON messages(conversation_id)")
        self._conn.commit()

    @_locked
    def add_message(self, conversation_id: str, role: str, content: str) -> int:
        cur = self._conn.execute(
            "INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (conversation_id, role, content, time.time()),
        )
        self._conn.commit()
        return cur.lastrowid

    @_locked
    def get_recent(self, conversation_id: str, limit: int = 10) -> list:
        """Most recent `limit` turns, returned oldest-first (natural reading
        order) for easy inclusion in a prompt."""
        cur = self._conn.execute(
            "SELECT role, content, created_at FROM messages WHERE conversation_id = ? "
            "ORDER BY id DESC LIMIT ?",
            (conversation_id, limit),
        )
        rows = cur.fetchall()
        rows.reverse()
        return [{"role": r, "content": c, "created_at": t} for r, c, t in rows]

    @_locked
    def list_conversations(self) -> list:
        cur = self._conn.execute(
            "SELECT conversation_id, COUNT(*), MIN(created_at), MAX(created_at) "
            "FROM messages GROUP BY conversation_id ORDER BY MAX(created_at) DESC"
        )
        return [{"conversation_id": r[0], "n_messages": r[1], "started_at": r[2], "last_at": r[3]}
                for r in cur.fetchall()]

    @_locked
    def search(self, query: str, conversation_id: str = None) -> list:
        """Simple substring search over message content (Phase 31's
        'search conversation'). Not semantic — this is the honest baseline;
        semantic search over conversation history would need the same
        embedding infrastructure as memory_store/documents and isn't
        implemented here."""
        like = f"%{query}%"
        if conversation_id:
            cur = self._conn.execute(
                "SELECT conversation_id, role, content, created_at FROM messages "
                "WHERE conversation_id = ? AND content LIKE ? ORDER BY id", (conversation_id, like))
        else:
            cur = self._conn.execute(
                "SELECT conversation_id, role, content, created_at FROM messages "
                "WHERE content LIKE ? ORDER BY id", (like,))
        return [{"conversation_id": r[0], "role": r[1], "content": r[2], "created_at": r[3]}
                for r in cur.fetchall()]

    @_locked
    def delete_conversation(self, conversation_id: str) -> int:
        cur = self._conn.execute("DELETE FROM messages WHERE conversation_id = ?", (conversation_id,))
        self._conn.commit()
        return cur.rowcount

    @_locked
    def export_conversation(self, conversation_id: str, fmt: str = "json") -> str:
        messages = self.get_recent(conversation_id, limit=10_000)
        if fmt == "json":
            return json.dumps(messages, indent=2)
        if fmt == "txt":
            return "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        if fmt in ("md", "markdown"):
            lines = [f"# Conversation: {conversation_id}\n"]
            for m in messages:
                lines.append(f"**{m['role']}**: {m['content']}\n")
            return "\n".join(lines)
        raise ValueError(f"unsupported export format: {fmt!r} (use json, txt, or md)")

    @_locked
    def close(self):
        self._conn.close()


DEFAULT_SYSTEM_MESSAGE = (
    "You are ORBIT, a small local research-prototype assistant. Be direct and "
    "honest about your limitations."
)


def build_context(tokenizer, current_message: str, conversation_id: str = None,
                   conversation_store: ConversationStore = None, memory_hits: list = None,
                   document_hits: list = None, system_message: str = DEFAULT_SYSTEM_MESSAGE,
                   max_tokens: int = 256, recent_turn_limit: int = 20) -> dict:
    """
    Assemble a prompt string within `max_tokens`, in priority order:
    system > long-term memory > document info > recent conversation > current
    message. Returns {"prompt": str, "token_count": int, "included": {...}}
    so callers/tests can see what survived truncation and what didn't.

    `max_tokens` should be set from the model's max_seq_len (with headroom
    left for the actual generation) — this function keeps memory/document/
    conversation content within budget on a best-effort basis. System
    instructions and the current message are both always included even if
    together they exceed `max_tokens` (dropping either is worse than a
    prompt that's slightly over budget) — callers with a hard max_seq_len
    ceiling should keep `system_message`/`current_message` short relative
    to `max_tokens` to avoid this case in practice.
    """
    def count_tokens(text):
        return len(tokenizer.encode(text, add_bos=False, add_eos=False))

    included = {"system": False, "memory": [], "documents": [], "conversation_turns": 0}

    # Reserve budget for the two mandatory blocks (system, current message)
    # up front, rather than fitting everything greedily and popping later —
    # popping-after-the-fact is what causes `included` to silently drift out
    # of sync with the actual returned prompt, which is its own small
    # hallucination (reporting content as included that got trimmed out).
    sys_block = f"[system]\n{system_message}"
    current_block = f"[current message]\nuser: {current_message}"
    sys_tokens = count_tokens(sys_block)
    current_tokens = count_tokens(current_block)

    parts = []
    parts.append(sys_block)
    included["system"] = True
    budget = max(0, max_tokens - sys_tokens - current_tokens)

    # 2. relevant long-term memory
    if memory_hits:
        for hit in memory_hits:
            line = f"- {hit['text']}" if isinstance(hit, dict) else f"- {hit}"
            t = count_tokens(line)
            if t <= budget:
                if not any(p.startswith("[memory]") for p in parts):
                    header_t = count_tokens("[memory]")
                    if header_t <= budget:
                        parts.append("[memory]")
                        budget -= header_t
                parts.append(line)
                budget -= t
                included["memory"].append(line)
            else:
                break

    # 3. relevant document information (with citation, per Phase 5 — never
    # included without the source that backs it)
    if document_hits:
        for hit in document_hits:
            loc = hit.get("location") or (f"page {hit['page']}" if hit.get("page") else "")
            cite = f"[{hit.get('filename', 'unknown')}{', ' + loc if loc else ''}]"
            block = f"- {hit['text']} {cite}"
            t = count_tokens(block)
            if t <= budget:
                if not any(p.startswith("[documents]") for p in parts):
                    header_t = count_tokens("[documents]")
                    if header_t <= budget:
                        parts.append("[documents]")
                        budget -= header_t
                parts.append(block)
                budget -= t
                included["documents"].append(cite)
            else:
                break

    # 4. recent conversation (most-recent-first for inclusion priority, then
    # reordered chronologically for the final prompt — if we have to
    # truncate, we keep the most recent turns, not the oldest)
    conv_block_lines = []
    if conversation_id and conversation_store:
        recent = conversation_store.get_recent(conversation_id, limit=recent_turn_limit)
        kept = []
        for turn in reversed(recent):  # newest first for the greedy fit
            line = f"{turn['role']}: {turn['content']}"
            t = count_tokens(line)
            if t <= budget:
                kept.append(line)
                budget -= t
            else:
                break
        conv_block_lines = list(reversed(kept))  # back to chronological order
    if conv_block_lines:
        parts.append("[recent conversation]")
        parts.extend(conv_block_lines)
        included["conversation_turns"] = len(conv_block_lines)

    # 5. current user request — budget for it was reserved up front, so it
    # always fits unless it alone exceeds max_tokens (nothing left to trim
    # for in that case; the caller's max_tokens is simply too small).
    parts.append(current_block)

    prompt = "\n".join(parts)
    return {"prompt": prompt, "token_count": count_tokens(prompt), "included": included}
