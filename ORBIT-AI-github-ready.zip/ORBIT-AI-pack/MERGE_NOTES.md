# Merge notes — orbit_v2.zip + improved TinyLM

**Date:** 2026-09-18

## Layout after merge

```
artifacts/orbit/                 # full orbit_v2 platform
  agent/, agents.py, api.py, api_routes/
  chat/, tools/, rag/, memory/, webui/
  model/, tokenizer/, training/, checkpoints/
  generate.py, train.py, ...
  tinylm/                        # educational TinyLM package (post-cycle improvements)
    config.py, numpy_model.py, torch_model.py, quantize.py, cli.py, ...
  tests/tinylm/                  # TinyLM pytest suite (~60 tests)
  docs/tinylm/                   # TinyLM architecture notes
```

## Two stacks (do not confuse)

| Path | Role |
|------|------|
| Root package (`model/`, `agents.py`, `api.py`, …) | Full ORBIT v2: BPE, agents, tools, RAG, FastAPI, webui, checkpoints |
| `tinylm/` | Isolated educational lab: NumPy+Torch TinyLM, quant, CLI, regression |

## How to run

**v2 platform** (from `artifacts/orbit/`):

```bash
pip install -r requirements.txt
python -m pytest -q          # v2 tests at repo root
uvicorn api:app --port 8000  # OpenAI-compatible API + webui
```

**TinyLM lab:**

```bash
cd artifacts/orbit
PYTHONPATH=. python -m pytest tests/tinylm -q
PYTHONPATH=. python -m tinylm.cli regression
PYTHONPATH=. python -m tinylm.cli bench --preset modern
```

## What was preserved

- All v2 files from the zip (agents, API, tools, webui, checkpoints, BPE, …)
- All TinyLM cycle work (GQA, SwiGLU, INT4 mmap, sampling, CLI, dropout, …)
- Project research notes remain at `artifacts/research/`

## Not automatic

- TinyLM is **not** yet the default backend for `api.py` / agents (v2 still uses its own `model/`).
- Wiring TinyLM into the API is a future integration step.
