"""
Byte-level tokenizer.

DESIGN.md Part 4 specifies a trained BPE/Unigram vocabulary (~100-128k merges)
for the production system, because raw bytes make sequences ~4x longer than a
trained subword vocabulary for English/code and don't compress repeated
multi-byte sequences (whole words, common code tokens) at all. This byte-level
version is the honest toy-scale stand-in: it needs zero training data or
external deps, every string round-trips losslessly (which a half-trained toy
BPE would not guarantee), and it is in fact the same fallback layer GPT-2/GPT-4
style byte-level BPE tokenizers bottom out on for unseen bytes. It is not a
substitute for Part 4's real tokenizer training stage.
"""

class ByteTokenizer:
    BOS, EOS, PAD = 256, 257, 258
    VOCAB_SIZE = 259

    def encode(self, text: str, add_bos=True, add_eos=True):
        ids = list(text.encode("utf-8", errors="replace"))
        if add_bos:
            ids = [self.BOS] + ids
        if add_eos:
            ids = ids + [self.EOS]
        return ids

    def decode(self, ids):
        byte_ids = [i for i in ids if i < 256]
        return bytes(byte_ids).decode("utf-8", errors="replace")
